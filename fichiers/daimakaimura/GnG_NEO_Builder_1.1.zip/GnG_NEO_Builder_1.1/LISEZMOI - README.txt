===========================================================================
 GHOULS'N GHOSTS NEO - constructeur de ROM / ROM builder
 Portage de fan sur Neo Geo - Neo Geo fan port
===========================================================================

[FR] -----------------------------------------------------------------------

Cet outil construit le portage Neo Geo de Ghouls'n Ghosts a partir de VOTRE
propre romset MAME du jeu arcade original. Il ne contient AUCUNE donnee du
jeu original (ni code, ni graphismes, ni musique) : seulement le travail du
portage (modifications, couche de traduction, pilote son, logo) et les
informations necessaires pour reconstruire le reste chez vous.

Ce qu'il faut :
  - Windows, et Python 3.9 ou plus (https://www.python.org/downloads/,
    cocher "Add python.exe to PATH" a l'installation) ;
  - MAME (version 0.250 ou plus recente ; teste avec 0.289) ;
  - la romset MAME "ghouls" (Ghouls'n Ghosts, World) : ghouls.zip.

Utilisation :
  1. Placez ghouls.zip dans ce dossier (sinon l'outil demandera son chemin).
  2. Double-cliquez sur "Construire - Build.bat".
     Si MAME n'est pas dans C:\MAME, l'outil demande le chemin de mame.exe.
  3. Patientez (environ 5 a 15 minutes : les sons sont enregistres dans
     MAME a partir du jeu original, puis encodes pour la Neo Geo).

Resultat, dans le dossier "output" :
  - neosd_mister.zip : fichier .neo pour NeoSD et MiSTer (core Neo Geo)
  - darksoft.zip     : cartouche Darksoft
  - backbit.zip      : BackBit Platinum MVS
  - mame\ghoulsneo   : ROMs pour MAME (romset "ghoulsneo", liste logicielle
                       neogeo : voir backbit.zip\ghoulsneo\neogeo.xml)

L'outil verifie chaque ROM construite (empreinte SHA-1). Si votre version de
MAME n'est pas la meme que la mienne, le son peut differer tres legerement :
c'est signale, et le jeu reste jouable.

Ligne de commande (autres systemes, ou options) :
  python builder.py --romset chemin\ghouls.zip --mame chemin\mame.exe

Mentions : projet de fan non commercial, sans lien avec Capcom. Ghouls'n
Ghosts / Daimakaimura (c) Capcom. Les ROMs produites sont pour votre usage
personnel : ne les distribuez pas, ne vendez pas de repros.
adpcmtool.py : ngdevkit (c) Damien Ciabrini, licence LGPL-3 (lib\).

[EN] -----------------------------------------------------------------------

This tool builds the Neo Geo port of Ghouls'n Ghosts from YOUR OWN MAME
romset of the original arcade game. It contains NO data from the original
game (no code, graphics or music): only the port's own work (changes,
translation layer, sound driver, logo) and the information needed to rebuild
the rest on your computer.

You need:
  - Windows, and Python 3.9 or newer (https://www.python.org/downloads/,
    tick "Add python.exe to PATH" during setup);
  - MAME (0.250 or newer; tested with 0.289);
  - the MAME "ghouls" romset (Ghouls'n Ghosts, World): ghouls.zip.

How to use:
  1. Put ghouls.zip in this folder (otherwise the tool asks for its path).
  2. Double-click "Construire - Build.bat".
     If MAME is not in C:\MAME, the tool asks for the path to mame.exe.
  3. Wait (about 5 to 15 minutes: sounds are recorded in MAME from the
     original game, then encoded for the Neo Geo).

Output, in the "output" folder:
  - neosd_mister.zip : .neo file for NeoSD and MiSTer (Neo Geo core)
  - darksoft.zip     : Darksoft cartridge
  - backbit.zip      : BackBit Platinum MVS
  - mame\ghoulsneo   : ROMs for MAME ("ghoulsneo" set, neogeo software list:
                       see backbit.zip\ghoulsneo\neogeo.xml)

The tool checks every ROM it builds (SHA-1). If your MAME version differs
from mine, the sound may differ very slightly: this is reported and the
game remains playable.

Command line (other systems, or options):
  python builder.py --romset path/to/ghouls.zip --mame path/to/mame

Notice: non-commercial fan project, not affiliated with Capcom. Ghouls'n
Ghosts / Daimakaimura (c) Capcom. The ROMs you build are for your personal
use: do not distribute them or sell repros.
adpcmtool.py: ngdevkit (c) Damien Ciabrini, LGPL-3 license (lib/).
