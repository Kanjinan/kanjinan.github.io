"""Genere le fichier .neo (format TerraOnion NeoSD, aussi lu par le core MiSTer).

Format : en-tete de 4096 octets ('NEO' 0x01, tailles P/S/M/V1/V2/C, annee,
genre, capture, NGH, nom, editeur), puis les ROMs P, S, M, V1, V2, C.
P = ROM P1 telle que pour MAME ; C = C1/C2 entrelacees mot par mot puis
octets du milieu de chaque long echanges (variante validee sur MiSTer avec
Warrior Man).

Usage : python tools/build_neo.py <dossier_build> <sortie.neo>
"""

from __future__ import annotations

import os
import struct
import sys

GAME = "ghoulsneo"
NAME = "Ghouls n Ghosts"
MANUFACTURER = "HOMEBREW"
YEAR = 2026
# NGH hors de la plage des jeux SNK pour eviter les correctifs de compatibilite
NGH = 0x0778
HEADER_FORMAT = "<4B10I33s17s418x3584x"


def c_string(text: str, size: int) -> bytes:
    data = text.encode("ascii")[:size - 1]
    return data + b"\0" * (size - len(data))


def sprites(c1: bytes, c2: bytes) -> bytes:
    if len(c1) != len(c2):
        raise SystemExit("C1 et C2 de tailles differentes")
    out = bytearray(len(c1) * 2)
    for i in range(0, len(c1), 2):
        o = i * 2
        # entrelacement C1/C2 par mot, puis echange des octets du milieu
        out[o], out[o + 1], out[o + 2], out[o + 3] = c1[i], c2[i], c1[i + 1], c2[i + 1]
    return bytes(out)


def main() -> int:
    return main_args(sys.argv[1], sys.argv[2])


def main_args(build: str, out_path: str) -> int:
    rom =lambda suffix: open(os.path.join(build, f"{GAME}-{suffix}"), "rb").read()
    p, s, m, v1 = rom("p1.p1"), rom("s1.s1"), rom("m1.m1"), rom("v1.v1")
    c = sprites(rom("c1.c1"), rom("c2.c2"))
    header = struct.pack(HEADER_FORMAT, ord("N"), ord("E"), ord("O"), 1,
                         len(p), len(s), len(m), len(v1), 0, len(c),
                         YEAR, 0, 0, NGH, c_string(NAME, 33), c_string(MANUFACTURER, 17))
    assert len(header) == 4096
    with open(out_path, "wb") as f:
        for part in (header, p, s, m, v1, c):
            f.write(part)
    print(f"  -> {out_path} ({os.path.getsize(out_path)} octets)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
