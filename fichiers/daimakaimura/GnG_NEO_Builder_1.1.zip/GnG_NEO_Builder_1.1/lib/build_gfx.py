"""ROMs graphiques Neo Geo (C1/C2) et table de conversion des couleurs.

C ROM :
- tuiles 0-0x5FFF : element 16x16 n de la region graphique CPS1 (le runtime
  applique le gfx bank mapper DM620, cf. src/rt/rt.c) ;
- tuiles S3_BASE + 4 e + 2 h + v : element 32x32 e (scroll3, e < 0x1400),
  moitie h (0 gauche, 1 droite), rangee v (0 haut, 1 bas) ;
- tuiles RAIN_TILE + k (k = 16 r + c, 0-63) : pluie de la seconde page de
  scroll1 (codes $2200 + 16 r + c, texture de 16 x 4 cases repetee), cases
  (r, c), (r, c + 1), (r + 1, c), (r + 1, c + 1) modulo la texture, moitie
  c & 1 de chaque code ; RAIN_TILE + 64 : vide (cf. s1b_code, hooks.S) ;
- tuiles FLAME_TILE + 48 f + 8 s + t : grosse flamme de la parade de fin
  (blocs scroll1 $57118 / $5741C / $57720, 12 x 16 cases dessinees en
  colonne 18, rangee 12 ; cf. hook_s1blk, hooks.S), image f, colonne de
  sprite s (cases 2 s, 2 s + 1), tuile t (rangees 2 t, 2 t + 1) ;
- tuiles FIRE_TILE + 12 f + 2 s + t : feu du sol du niveau 1 (blocs scroll1
  $56AAC + $C4 f, 12 x 4 cases, colonnes 2 / 14 / 26 / 38, rangee 26),
  image f, paire de colonnes s, paire de rangees t ; FIRE_TILE + 72 + 2 f
  + t : bord gauche (blocs $56F52 + $24 f, 2 x 4 cases, colonne 0) ;
  FIRE_TILE + 84 + 2 f + t : second bord ($57038 + $24 f) ;
- tuiles NK_TILE + 13 c + r : logo logo_NK.png (ecran affiche avant le menu
  d'options, menu.c), colonne c, rangee r, une palette de 15 couleurs par
  tuile (NK_PAL0 + 13 c + r) ; build/logo_nk.h : palettes et placement.
Couleur CPS1 c ->
couleur Neo Geo (c + 1) & 15 : la transparente passe de 15 a 0, les palettes
sont decalees de la meme facon par le runtime.

S ROM : tuile fix 2 (c - 0x2000) + m = moitie m (0 gauche, 1 droite) du code
scroll1 c, pour c dans 0x2000-0x27FF (les seuls codes que le jeu ecrit dans
scroll1, releves dans MAME). Le code 0x202C (espace) donne la tuile vide 0x58.
Exception : tuiles de codes entierement vides jamais ecrits par le jeu
remplacees par les variantes retournees en X des codes FLIP_FIRST-FLIP_END
(visage du demon) ; s1_flip.bin : 4096 mots, tuile -> tuile retournee
(cf. build_fix_flips, s1b_store dans hooks.S).

pal_lut.bin : 65536 mots, couleur CPS1 (luminosite + RGB 4 bits) -> couleur
Neo Geo (big endian, inclus dans la P ROM).

Usage : python build_gfx.py <dossier build>
"""

from __future__ import annotations

import os
import sys

import numpy as np

import cps1

GAME = "ghoulsneo"
CROM_SIZE = 0x400000   # par puce
S3_BASE = 0x6000       # premiere tuile des elements 32x32
S3_COUNT = 0x1400      # elements 32x32 atteignables par le mapper DM620
RAIN_TILE = S3_BASE + 4 * S3_COUNT   # 0xB000 : pluie de la seconde page de scroll1
FLAME_TILE = RAIN_TILE + 65          # 0xB041 : grosse flamme (parade de fin)
FLAME_DATA = (0x57118, 0x5741C, 0x57720)
FLAME_COL0 = 18                       # colonne scroll1 du bloc (parite des moities)
FIRE_TILE = FLAME_TILE + 48 * 3       # 0xB0D1 : feu du sol (cf. fire_update, rt.c)
FIRE_FLOOR, FIRE_FLOOR_STEP = 0x56AAC, 0xC4   # 6 images, 12 x 4 cases
FIRE_EDGE, FIRE_EDGE_STEP = 0x56F52, 0x24     # 6 images, 2 x 4 cases
FIRE_EDGE2 = 0x57038                           # second bord, 6 images, 2 x 4 cases
FIRE_COUNT = 6 * 12 + 6 * 2 + 6 * 2
NK_TILE = FIRE_TILE + FIRE_COUNT      # 0xB131 : logo NK (cf. build_nk_logo)
NK_PAL0 = 16                          # palettes Neo Geo du logo (avant le jeu)
EDGE_W = 16                           # masque : tuile entierement noire (cf. edge_mask)
S1_FIRST, S1_COUNT = 0x2000, 0x800   # codes scroll1 -> S ROM (4096 tuiles)
# Visage du demon (seconde page de scroll1, intro et THE END) : moitie gauche
# = codes $2483-$24FC retournes horizontalement (releve dans MAME ghouls). Le
# fix ne retourne pas : variantes retournees de toute la plage ecrites a la
# place de codes entierement vides que le jeu n'ecrit jamais (releve sur
# demo + intro + partie : seuls $202C et $2420 le sont ; $2400-$247F : texte
# du portage, menu.c / rt.c).
FLIP_FIRST, FLIP_END = 0x2480, 0x2500
FLIP_KEEP = {0x202C, 0x2420}


def build_fix_flips(fix: np.ndarray) -> tuple[np.ndarray, int]:
    """Ajoute a fix (modifiee sur place) les tuiles retournees en X des codes
    FLIP_FIRST-FLIP_END ; rend (table tuile -> tuile retournee, identite
    ailleurs, nombre de tuiles ajoutees)."""
    def blank(c: int) -> bool:
        s = 2 * (c - S1_FIRST)
        return not fix[s].any() and not fix[s + 1].any()
    free = [2 * (c - S1_FIRST) + h
            for c in range(S1_FIRST + S1_COUNT - 1, S1_FIRST - 1, -1)
            if blank(c) and c not in FLIP_KEEP and not 0x2400 <= c < 0x2480
            for h in (0, 1)]
    freeset = set(free)
    known: dict[bytes, int] = {}
    for i in range(len(fix) - 1, -1, -1):
        if i not in freeset:
            known[fix[i].tobytes()] = i
    known[fix[0x58].tobytes()] = 0x58
    tab = np.arange(len(fix), dtype=np.uint16)
    added = 0
    for s in range(2 * (FLIP_FIRST - S1_FIRST), 2 * (FLIP_END - S1_FIRST)):
        t = np.ascontiguousarray(fix[s][:, ::-1])
        k = t.tobytes()
        if k not in known:
            if not free:
                raise SystemExit("S ROM : plus de place pour les tuiles retournees")
            n = free.pop(0)
            fix[n] = t
            known[k] = n
            added += 1
        tab[s] = known[k]
    return tab, added


def encode_tiles(px: np.ndarray) -> tuple[bytes, bytes]:
    """px : (n, 16, 16) couleurs Neo Geo -> (C1, C2).

    Blocs 8x8 dans l'ordre droite-haut, droite-bas, gauche-haut, gauche-bas ;
    par rangee, C1 recoit les plans 0/1 et C2 les plans 2/3, pixel de gauche
    dans le bit 0."""
    n = px.shape[0]
    blocks = [px[:, 0:8, 8:16], px[:, 8:16, 8:16], px[:, 0:8, 0:8], px[:, 8:16, 0:8]]
    b = np.stack(blocks, axis=1)  # (n, 4, 8, 8)
    weights = (1 << np.arange(8, dtype=np.uint16))
    planes = [((((b >> k) & 1).astype(np.uint16)) * weights).sum(axis=-1).astype(np.uint8) for k in range(4)]
    # planes[k] : (n, 4, 8) octets
    c1 = np.stack([planes[0], planes[1]], axis=-1).reshape(n, 64)
    c2 = np.stack([planes[2], planes[3]], axis=-1).reshape(n, 64)
    return c1.tobytes(), c2.tobytes()


def encode_fix(px: np.ndarray) -> bytes:
    """px : (n, 8, 8) couleurs Neo Geo -> tuiles fix de 32 octets : octets
    $10-$17 colonnes 0-1, $18 2-3, $00 4-5, $08 6-7, une rangee par octet,
    pixel de gauche dans le quartet bas."""
    n = px.shape[0]
    out = np.zeros((n, 32), dtype=np.uint8)
    for i, base in enumerate((0x10, 0x18, 0x00, 0x08)):
        out[:, base:base + 8] = px[:, :, 2 * i] | (px[:, :, 2 * i + 1] << 4)
    return out.tobytes()


def neo_color(rgb: tuple[int, int, int]) -> int:
    """RGB 8 bits -> couleur Neo Geo (5 bits par composante, bit sombre a 0)."""
    r, g, b = rgb
    word = ((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4)
    word |= (((r >> 3) & 1) << 14) | (((g >> 3) & 1) << 13) | (((b >> 3) & 1) << 12)
    return word


def build_nk_logo(build: str) -> np.ndarray:
    """logo_NK.png (racine du projet) -> tuiles Neo Geo deja converties
    (colonne par colonne) et build/logo_nk.h (palettes, position, taille).
    L'image est placee en haut a gauche d'un canevas de tuiles 16x16 ; le
    reste est transparent. Chaque tuile a sa palette (couleur 0 :
    transparente, 1-15 : quantification mediane de la tuile)."""
    from PIL import Image

    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    im = Image.open(os.path.join(root, "logo_NK.png")).convert("RGBA")
    w, h = im.size
    cols, rows = (w + 15) // 16, (h + 15) // 16
    tiles = np.zeros((cols * rows, 16, 16), dtype=np.uint8)
    pals = []
    for c in range(cols):
        for r in range(rows):
            box = im.crop((16 * c, 16 * r, 16 * c + 16, 16 * r + 16))   # hors image : (0,0,0,0)
            a = np.asarray(box)
            opaque = a[:, :, 3] >= 128
            rgb = Image.fromarray(np.ascontiguousarray(a[:, :, :3]))
            q = rgb.quantize(colors=15, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
            idx = np.asarray(q).astype(np.uint8)
            qp = q.getpalette()
            pal = [0x8000] * 16
            for i in range(15):
                pal[i + 1] = neo_color(tuple(qp[3 * i:3 * i + 3])) if qp and 3 * i + 2 < len(qp) else 0x8000
            tiles[c * rows + r] = np.where(opaque, idx + 1, 0)
            pals.append(pal)
    with open(os.path.join(build, "logo_nk.h"), "w", newline="\n") as f:
        f.write("/* Genere par tools/build_gfx.py (logo_NK.png) : ne pas modifier */\n")
        f.write("#define NK_TILE 0x%X\n#define NK_PAL0 %d\n#define NK_COLS %d\n#define NK_ROWS %d\n"
                "#define NK_W %d\n#define NK_H %d\n#define NK_BLANK_TILE 0x%X\n"
                % (NK_TILE, NK_PAL0, cols, rows, w, h, RAIN_TILE + 64))
        f.write("static const u16 nk_pal[NK_COLS * NK_ROWS][16] = {\n")
        for p in pals:
            f.write("    {" + ", ".join("0x%04x" % x for x in p) + "},\n")
        f.write("};\n")
    assert NK_PAL0 + len(pals) <= 255
    return tiles


# Priorite de scroll2 (calque de premier plan, cf. ovl_* dans tilemap.c) :
# sur CPS1, chaque case a un groupe (attribut bits 7-8) ; les couleurs du
# masque de son groupe (registres $800168-$80016E) passent devant les
# sprites quand scroll2 est dessinee juste sous eux. Masques fixes par
# niveau : table du jeu en $54386 (4 mots par niveau, $543DE), seuls les
# niveaux 0-3 en ont. Cases de scroll2 : blocs de 16 x 24 cases longues
# (code - $2000 : attribut) en $A1088 + $600 (b - 1), carte de 128 x 8
# blocs (2 octets par entree, numero de bloc dans le premier) en $8C508 +
# mot 2 de l'en-tete du niveau ($89B58 + 8 n).
PRIO_MASKS = 0x54386
PRIO_LEVELS = 4
LEVEL_HDR = 0x89B58
LEVEL_MAPS = 0x8C508
S2_BLOCKS = 0xA1088


def build_prio(prg: bytes, t16: np.ndarray, first_tile: int) -> tuple[np.ndarray, bytes, int]:
    """Variantes de tuiles du calque de premier plan.

    Pour chaque niveau 0-3, toutes les tuiles des blocs de sa carte, avec
    chaque groupe de masque non nul (les animations des decors changent les
    cases : toutes les combinaisons du niveau, pas seulement celles des
    blocs). Tuile du calque : 0 (rien devant), la tuile elle-meme (toutes
    ses couleurs devant) ou une variante ne gardant que les couleurs du
    masque (ajoutee a partir de first_tile, dedoublonnee).

    Rend (pixels CPS1 des variantes, tables, nombre de codes K) ; tables :
    prio_idx (16384 mots : 8 k pour le code k de la liste, 0 : aucun),
    ovl_masks (4 niveaux x 4 mots, pour reconnaitre le niveau a partir des
    registres), ovl_lv (4 niveaux x (K + 1) x 4 groupes : tuile Neo Geo,
    0 : rien)."""
    w = lambda a: int.from_bytes(prg[a:a + 2], "big")
    masks = [[w(PRIO_MASKS + 8 * lv + 2 * g) & 0x7FFF for g in range(4)] for lv in range(PRIO_LEVELS)]
    level_codes = []
    for lv in range(PRIO_LEVELS):
        mp = LEVEL_MAPS + w(LEVEL_HDR + 8 * lv + 2)
        blocks = {max(prg[mp + 2 * i] - 1, 0) for i in range(128 * 8)}
        codes = set()
        for b in blocks:
            base = S2_BLOCKS + b * 0x600
            for k in range(384):
                codes.add((w(base + 4 * k) + 0x2000) & 0x3FFF)
        level_codes.append(codes)
    allcodes = sorted(set().union(*[level_codes[lv] for lv in range(PRIO_LEVELS) if any(masks[lv])]))
    kof = {c: i + 1 for i, c in enumerate(allcodes)}
    nk = len(allcodes) + 1
    ovl = np.zeros((PRIO_LEVELS, nk, 4), dtype=np.uint32)
    variants: list[np.ndarray] = []
    known: dict[bytes, int] = {}
    for lv in range(PRIO_LEVELS):
        for g in range(4):
            m = masks[lv][g]
            if not m:
                continue
            fgp = np.array([bool((m >> p) & 1) for p in range(15)] + [False])
            for c in level_codes[lv]:
                tile = t16[c]
                f = fgp[tile]
                if not f.any():
                    continue
                if not ((tile != 15) & ~f).any():
                    ovl[lv, kof[c], g] = c
                    continue
                v = np.where(f, tile, 15).astype(t16.dtype)
                key = v.tobytes()
                if key not in known:
                    known[key] = first_tile + len(variants)
                    variants.append(v)
                ovl[lv, kof[c], g] = known[key]
    if ovl.max() > 0xFFFF:
        raise SystemExit("calque de premier plan : tuiles au-dela de $FFFF")
    idx = np.zeros(0x4000, dtype=">u2")
    for c, k in kof.items():
        idx[c] = 8 * k
    if 8 * nk > 0x7FFF:
        raise SystemExit("calque de premier plan : trop de codes")
    tabs = (idx.tobytes() + np.array(masks, dtype=">u2").tobytes()
            + ovl.astype(">u2").tobytes())
    px = np.stack(variants) if variants else np.zeros((0, 16, 16), dtype=t16.dtype)
    return px, tabs, nk


def build_pal_lut() -> bytes:
    out = bytearray(0x20000)
    for c in range(0x10000):
        w = neo_color(cps1.cps_rgb(c))
        out[c * 2] = w >> 8
        out[c * 2 + 1] = w & 0xFF
    return bytes(out)


def main() -> int:
    build = sys.argv[1]
    gfx = cps1.load_gfx()
    t16 = cps1.decode_16x16(gfx)
    t32 = cps1.decode_32x32(gfx)[:S3_COUNT]
    # elements 32x32 -> 4 tuiles (h, v) dans l'ordre 2 h + v
    q = t32.reshape(S3_COUNT, 2, 16, 2, 16).transpose(0, 3, 1, 2, 4).reshape(-1, 16, 16)
    assert len(t16) == S3_BASE
    t8 = cps1.decode_8x8(gfx)   # (n, 2, 8, 8)

    def cell(r: int, c: int) -> np.ndarray:
        r &= 3
        c &= 15
        return t8[cps1.map_scroll1(0x2200 + 16 * r + c)][c & 1]

    rain = np.full((65, 16, 16), 15, dtype=t16.dtype)   # 15 : transparente
    for k in range(64):
        r, c = k >> 4, k & 15
        rain[k, 0:8, 0:8] = cell(r, c)
        rain[k, 0:8, 8:16] = cell(r, c + 1)
        rain[k, 8:16, 0:8] = cell(r + 1, c)
        rain[k, 8:16, 8:16] = cell(r + 1, c + 1)
    prg = open(os.path.join(build, "prg.bin"), "rb").read()
    flame = np.full((48 * len(FLAME_DATA), 16, 16), 15, dtype=t16.dtype)
    for f, a in enumerate(FLAME_DATA):
        assert prg[a + 1] == 0x10 and prg[a + 2] == 11 and prg[a + 3] == 15, hex(a)
        cells = [int.from_bytes(prg[a + 4 + 4 * i:a + 8 + 4 * i], "big") for i in range(12 * 16)]
        for j in range(12):
            for i in range(16):
                v = cells[j * 16 + i]
                assert v & 0xFFFF == 0x000D, hex(v)   # palette 13, sans retournement
                code = (v >> 16) + 0x2000
                px = t8[cps1.map_scroll1(code)][(FLAME_COL0 + j) & 1]
                k = 48 * f + 8 * (j // 2) + i // 2
                flame[k, 8 * (i & 1):8 * (i & 1) + 8, 8 * (j & 1):8 * (j & 1) + 8] = px
    # feu du sol (niveau 1, maisons en feu) : blocs scroll1 de 12 x 4 cases
    # (FIRE_FLOOR, 6 images) et bord gauche de 2 x 4 cases (FIRE_EDGE),
    # colonnes paires : tuile = cases (2 s, 2 s + 1) x rangees (2 t, 2 t + 1)
    fire = np.full((FIRE_COUNT, 16, 16), 15, dtype=t16.dtype)

    def fire_block(a: int, ncols: int, k0: int) -> None:
        assert prg[a:a + 4] == bytes([0x05, 0x06, ncols - 1, 0x00]), hex(a)
        cells = [int.from_bytes(prg[a + 4 + 4 * n:a + 8 + 4 * n], "big") for n in range(ncols * 4)]
        for j in range(ncols):
            for i in range(4):
                v = cells[j * 4 + i]
                assert v & 0xFFFF == 0, hex(v)          # palette 0, sans retournement
                px = t8[cps1.map_scroll1((v >> 16) + 0x2000)][j & 1]
                k = k0 + 2 * (j // 2) + i // 2
                fire[k, 8 * (i & 1):8 * (i & 1) + 8, 8 * (j & 1):8 * (j & 1) + 8] = px

    for f in range(6):
        fire_block(FIRE_FLOOR + FIRE_FLOOR_STEP * f, 12, 12 * f)
        fire_block(FIRE_EDGE + FIRE_EDGE_STEP * f, 2, 72 + 2 * f)
        fire_block(FIRE_EDGE2 + FIRE_EDGE_STEP * f, 2, 84 + 2 * f)
    tiles = np.concatenate([t16, q, rain, flame, fire])
    assert len(tiles) == FIRE_TILE + FIRE_COUNT
    neo = ((tiles.astype(np.int16) + 1) & 15).astype(np.uint8)
    neo = np.concatenate([neo, build_nk_logo(build)])
    assert len(neo) - len(tiles) + NK_TILE == len(neo)
    # Masque du bord gauche (cf. edge_mask, rt.c) : EDGE_W colonnes de
    # gauche en couleur 1 (noire, palette EDGE_PAL), le reste transparent
    edge = np.zeros((1, 16, 16), dtype=np.uint8)
    edge[0, :, 0:EDGE_W] = 1
    edge_tile = len(neo)
    neo = np.concatenate([neo, edge])
    with open(os.path.join(build, "edge_tile.h"), "w", newline="\n") as f:
        f.write("/* Genere par tools/build_gfx.py : ne pas modifier */\n")
        f.write("#define EDGE_TILE 0x%X\n#define EDGE_W %d\n" % (edge_tile, EDGE_W))
    # calque de premier plan (priorite de scroll2) : variantes apres le masque
    prio_px, prio_tabs, prio_k = build_prio(prg, t16, len(neo))
    neo = np.concatenate([neo, ((prio_px.astype(np.int16) + 1) & 15).astype(np.uint8)])
    open(os.path.join(build, "prio_tab.bin"), "wb").write(prio_tabs)
    with open(os.path.join(build, "prio_tab.h"), "w", newline="\n") as f:
        f.write("/* Genere par tools/build_gfx.py : ne pas modifier */\n")
        f.write("#define OVL_K %d\n" % prio_k)
    print(f"  calque de premier plan : {len(prio_px)} variantes, {prio_k - 1} codes")
    c1, c2 = encode_tiles(neo)
    if len(c1) > CROM_SIZE:
        raise SystemExit("C ROM trop petite")
    c1 += b"\0" * (CROM_SIZE - len(c1))
    c2 += b"\0" * (CROM_SIZE - len(c2))
    open(os.path.join(build, f"{GAME}-c1.c1"), "wb").write(c1)
    open(os.path.join(build, f"{GAME}-c2.c2"), "wb").write(c2)
    open(os.path.join(build, "pal_lut.bin"), "wb").write(build_pal_lut())

    fix = t8[[cps1.map_scroll1(c) for c in range(S1_FIRST, S1_FIRST + S1_COUNT)]].reshape(-1, 8, 8)
    fix = ((fix.astype(np.int16) + 1) & 15).astype(np.uint8)
    if fix[0x58].any() or fix[0x59].any():
        raise SystemExit("le code scroll1 0x202C n'est pas vide")
    flip_tab, nflip = build_fix_flips(fix)
    open(os.path.join(build, f"{GAME}-s1.s1"), "wb").write(encode_fix(fix))
    open(os.path.join(build, "s1_flip.bin"), "wb").write(flip_tab.astype(">u2").tobytes())
    print(f"  S ROM : {nflip} tuiles retournees (codes {FLIP_FIRST:04X}-{FLIP_END - 1:04X}) dans des codes vides")
    print(f"  {len(tiles)} tuiles ({len(t16)} 16x16 + {S3_COUNT} elements 32x32 + 65 pluie + {48 * len(FLAME_DATA)} flamme) -> C1/C2 ({CROM_SIZE // 1024} Ko chacune)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
