-- Enregistrement d'une commande son du jeu CPS1 original (mame ghouls).
--   GNG_CMD    : commande (decimal), envoyee au latch son ($800180)
--   GNG_FRAMES : duree d'enregistrement apres la commande (trames)
-- La commande part a la trame 120, pendant l'autotest (le 68000 n'envoie
-- alors aucune commande), puis $FF a la trame suivante comme le fait le jeu.
-- MAME doit etre lance avec -wavwrite : tools/render_sounds.py coupe le
-- debut du fichier.

local sp = manager.machine.devices[":maincpu"].spaces["program"]
local cmd = tonumber(os.getenv("GNG_CMD"))
local dur = tonumber(os.getenv("GNG_FRAMES") or "600")
frames = 0
emu.register_frame_done(function()
  frames = frames + 1
  if frames == 120 then sp:write_u16(0x800180, cmd) end
  if frames == 121 then
    sp:write_u16(0x800180, 0xff)
    -- 68000 fige (bra sur lui-meme en $716, interruptions masquees) : sinon,
    -- a la fin de l'autotest (~20 s), le jeu demarre et envoie ses propres
    -- commandes (arret, musique de demonstration)
    local cpu = manager.machine.devices[":maincpu"]
    cpu.state["SR"].value = 0x2700
    cpu.state["PC"].value = 0x716
  end
  if frames >= 120 + dur then manager.machine:exit() end
end)
