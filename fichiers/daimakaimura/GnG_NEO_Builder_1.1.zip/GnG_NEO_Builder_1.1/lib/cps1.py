"""Chargement des ROMs CPS1 de Ghouls'n Ghosts et decodage des graphismes.

Les regions sont reconstruites comme dans MAME (driver cps1, jeu "ghouls") ;
l'entrelacement des puces a ete verifie octet par octet contre un dump des
regions fait par MAME 0.289.

Graphismes (cf. MAME cps1_v.cpp / cps1.cpp) :
- tuile 16x16 = 128 octets : 16 rangees de 8 octets, pixels 0-7 dans les
  octets 0-3, pixels 8-15 dans les octets 4-7 ; dans chaque groupe de 4
  octets, l'octet k porte le plan k (bit 7 = pixel de gauche) ;
- tuile 8x8 = 64 octets : 8 rangees de 8 octets, moitie gauche (octets 0-3)
  pour les colonnes paires du tilemap, moitie droite (4-7) pour les impaires ;
- tuile 32x32 = 512 octets : 32 rangees de 16 octets (4 groupes de 8 px).
Couleur 15 = transparente.

Gfx bank mapper DM620 (unites de 64 octets) : scroll3 0x8000-0xBFFF -> banque 1
(base 0x8000), sprites 0x2000-0x3FFF -> banque 2 (base 0xA000), sinon banque 0.
"""

from __future__ import annotations

import os

import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ROM_DIR = os.path.join(ROOT, "original", "ghouls")

PRG_SIZE = 0x100000
GFX_SIZE = 0x300000

# (fichier, offset, pas, largeur) : octets "largeur" tous les "pas" octets
PRG_ROMS = [
    ("dme_29.10h", 0x00000, 2, 1), ("dme_30.10j", 0x00001, 2, 1),
    ("dme_27.9h", 0x40000, 2, 1), ("dme_28.9j", 0x40001, 2, 1),
    ("dm-17.7j", 0x80000, 2, 2),
]
GFX_ROMS = [
    ("dm-05.3a", 0x000000, 8, 2), ("dm-07.3f", 0x000002, 8, 2),
    ("dm-06.3c", 0x000004, 8, 2), ("dm-08.3g", 0x000006, 8, 2),
    ("09.4a", 0x200000, 8, 1), ("18.7a", 0x200001, 8, 1),
    ("13.4e", 0x200002, 8, 1), ("22.7e", 0x200003, 8, 1),
    ("11.4c", 0x200004, 8, 1), ("20.7c", 0x200005, 8, 1),
    ("15.4g", 0x200006, 8, 1), ("24.7g", 0x200007, 8, 1),
    ("10.4b", 0x280000, 8, 1), ("19.7b", 0x280001, 8, 1),
    ("14.4f", 0x280002, 8, 1), ("23.7f", 0x280003, 8, 1),
    ("12.4d", 0x280004, 8, 1), ("21.7d", 0x280005, 8, 1),
    ("16.4h", 0x280006, 8, 1), ("25.7h", 0x280007, 8, 1),
]
AUDIO_ROM = "26.10a"


def _load(roms, size: int) -> bytes:
    out = np.zeros(size, dtype=np.uint8)
    for name, offset, step, width in roms:
        data = np.frombuffer(open(os.path.join(ROM_DIR, name), "rb").read(), dtype=np.uint8)
        n = len(data) // width
        for k in range(width):
            out[offset + k: offset + k + n * step: step] = data[k::width]
    return out.tobytes()


def load_program() -> bytes:
    return _load(PRG_ROMS, PRG_SIZE)


def load_gfx() -> bytes:
    return _load(GFX_ROMS, GFX_SIZE)


def load_audio() -> bytes:
    return open(os.path.join(ROM_DIR, AUDIO_ROM), "rb").read()


# ---------------------------------------------------------------------------
# Decodage en tableaux numpy d'indices de couleur 0-15 (couleur CPS1)

def _rows_to_pixels(rows: np.ndarray) -> np.ndarray:
    """rows : (..., 4) octets d'un groupe de 8 pixels (octet k = plan k)
    -> (..., 8) indices de couleur."""
    bits = np.unpackbits(rows[..., :, None], axis=-1)  # (..., 4, 8), bit 7 en premier
    weights = np.array([1, 2, 4, 8], dtype=np.uint8)[:, None]
    return (bits * weights).sum(axis=-2).astype(np.uint8)


def decode_16x16(gfx: bytes) -> np.ndarray:
    """-> (n, 16, 16) pour toutes les tuiles 16x16 de la region."""
    g = np.frombuffer(gfx, dtype=np.uint8).reshape(-1, 16, 2, 4)  # tuile, rangee, moitie, plan
    px = _rows_to_pixels(g)  # (n, 16, 2, 8)
    return px.reshape(-1, 16, 16)


def decode_8x8(gfx: bytes) -> np.ndarray:
    """-> (n, 2, 8, 8) : tuile 8x8 de 64 octets, moitie gauche [0] et droite [1]."""
    g = np.frombuffer(gfx, dtype=np.uint8).reshape(-1, 8, 2, 4)
    px = _rows_to_pixels(g)  # (n, 8, 2, 8)
    return px.transpose(0, 2, 1, 3)


def decode_32x32(gfx: bytes) -> np.ndarray:
    """-> (n, 32, 32)."""
    g = np.frombuffer(gfx, dtype=np.uint8).reshape(-1, 32, 4, 4)
    px = _rows_to_pixels(g)  # (n, 32, 4, 8)
    return px.reshape(-1, 32, 32)


# ---------------------------------------------------------------------------
# Gfx bank mapper DM620 : code -> numero d'element dans la region

def map_sprite(code: int) -> int:
    u = (code << 1) & 0x1FFFF
    if 0x2000 <= u <= 0x3FFF:
        return (0xA000 + (u & 0x1FFF)) >> 1
    return (u & 0x7FFF) >> 1


def map_scroll1(code: int) -> int:
    return code & 0x7FFF


def map_scroll2(code: int) -> int:
    return ((code << 1) & 0x7FFF) >> 1


def map_scroll3(code: int) -> int:
    u = ((code & 0x3FFF) << 3)
    if 0x8000 <= u <= 0xBFFF:
        return (0x8000 + (u & 0x1FFF)) >> 3
    return (u & 0x7FFF) >> 3


# ---------------------------------------------------------------------------
# Palette : 4 bits de luminosite + RGB 4 bits (MAME cps1_build_palette)

def cps_rgb(color: int) -> tuple[int, int, int]:
    bright = 0x0F + ((color >> 12) << 1)
    return tuple(((color >> s) & 0x0F) * 0x11 * bright // 0x2D for s in (8, 4, 0))


if __name__ == "__main__":
    import sys
    # python cps1.py --program <sortie> : programme 68000 reconstitue
    # python cps1.py <maincpu.bin> <gfx.bin> : verification contre un dump MAME
    if len(sys.argv) == 3 and sys.argv[1] == "--program":
        open(sys.argv[2], "wb").write(load_program())
        sys.exit(0)
    prg, gfx = load_program(), load_gfx()
    if len(sys.argv) == 3:
        print("programme", "OK" if open(sys.argv[1], "rb").read()[:PRG_SIZE] == prg else "DIFFERENT")
        print("graphismes", "OK" if open(sys.argv[2], "rb").read() == gfx else "DIFFERENT")
