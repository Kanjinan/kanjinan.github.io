"""Metal Slug Enhanced - outil de patch / patcher

Construit Metal Slug Enhanced à partir de VOTRE romset MAME mslug.zip.
Builds Metal Slug Enhanced from YOUR OWN MAME romset mslug.zip.

Aucune donnée du jeu original n'est fournie avec cet outil : seulement les
patchs IPS (code et tuiles du hack).
No data from the original game is included with this tool: only the IPS
patches (the hack's own code and tiles).

Usage :
  python patcher.py [--romset mslug.zip] [--out output]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
import zipfile
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
GAME = "mslugenh"                      # nom de jeu pour BackBit / Darksoft
NEO_NAME = "METAL SLUG ENHANCED"


def say(fr: str, en: str = "") -> None:
    print(fr if not en else f"{fr}  /  {en}", flush=True)


def fail(fr: str, en: str) -> None:
    say(f"[ERREUR] {fr}", f"[ERROR] {en}")
    sys.exit(1)


def sha1(d: bytes) -> str:
    return hashlib.sha1(d).hexdigest()


# --- Romset ------------------------------------------------------------------

def find_romset(arg: str | None) -> Path:
    for c in (arg, ROOT / "mslug.zip", ROOT.parent / "mslug.zip"):
        if c and Path(c).is_file():
            return Path(c)
    p = input("Chemin de votre romset mslug.zip ? / Path to your mslug.zip romset?\n> ").strip().strip('"')
    if not Path(p).is_file():
        fail("mslug.zip introuvable", "mslug.zip not found")
    return Path(p)


def read_romset(zpath: Path, manifest: dict) -> dict[str, bytes]:
    """Lit les ROM du romset et vérifie leur CRC32 (accepte un zip ou un dossier)."""
    wanted = manifest["romset"]
    files: dict[str, bytes] = {}
    if zpath.is_dir():
        found = {p.name.lower(): p for p in zpath.iterdir() if p.is_file()}
        for name in wanted:
            if name.lower() in found:
                files[name] = found[name.lower()].read_bytes()
    else:
        with zipfile.ZipFile(zpath) as z:
            by_crc = {i.CRC: i for i in z.infolist()}
            by_name = {Path(i.filename).name.lower(): i for i in z.infolist()}
            for name, crc in wanted.items():
                i = by_name.get(name.lower()) or by_crc.get(int(crc, 16))
                if i:
                    files[name] = z.read(i)
    bad = []
    for name, crc in wanted.items():
        d = files.get(name)
        if d is None:
            bad.append(f"  {name} : absent / missing")
        elif f"{zlib.crc32(d):08x}" != crc:
            bad.append(f"  {name} : CRC {zlib.crc32(d):08x}, attendu / expected {crc}")
    if bad:
        print("\n".join(bad))
        fail("le romset ne correspond pas au Metal Slug MAME (mslug, NGH 0201).",
             "the romset does not match MAME's Metal Slug (mslug, NGH 0201).")
    return files


# --- IPS ---------------------------------------------------------------------

def apply_ips(data: bytes, patch: bytes) -> bytes:
    if not patch.startswith(b"PATCH"):
        raise ValueError("patch IPS invalide")
    out, i = bytearray(data), 5
    while patch[i:i + 3] != b"EOF":
        off = int.from_bytes(patch[i:i + 3], "big")
        size = int.from_bytes(patch[i + 3:i + 5], "big")
        i += 5
        if size:
            chunk = patch[i:i + size]
            i += size
        else:                                          # enregistrement RLE
            n = int.from_bytes(patch[i:i + 2], "big")
            chunk = patch[i + 2:i + 3] * n
            i += 3
        if off + len(chunk) > len(out):
            out.extend(b"\0" * (off + len(chunk) - len(out)))
        out[off:off + len(chunk)] = chunk
    return bytes(out)


# --- Formats de sortie --------------------------------------------------------

def interleave_bytes(a: bytes, b: bytes) -> bytes:
    out = bytearray(len(a) * 2)
    out[0::2], out[1::2] = a, b
    return bytes(out)


def interleave_words(a: bytes, b: bytes) -> bytes:
    out = bytearray(len(a) * 2)
    out[0::4], out[1::4], out[2::4], out[3::4] = a[0::2], a[1::2], b[0::2], b[1::2]
    return bytes(out)


def neo_file(r: dict[str, bytes]) -> bytes:
    """Format .neo (NeoSD / MiSTer). La P-ROM MAME a la banque d'abord : on remet la zone fixe en tête."""
    import struct
    p = r["201-p1.p1"][0x100000:] + r["201-p1.p1"][:0x100000]
    s, m = r["201-s1.s1"], r["201-m1.m1"]
    v = r["201-v1.v1"] + r["201-v2.v2"]
    c = interleave_bytes(r["201-c1.c1"], r["201-c2.c2"]) + interleave_bytes(r["201-c3.c3"], r["201-c4.c4"])

    def cstr(t: str, n: int) -> bytes:
        d = t.encode("ascii")[: n - 1]
        return d + b"\0" * (n - len(d))
    head = struct.pack("<4B10I33s17s418x3584x", 0x4E, 0x45, 0x4F, 0x01,
                       len(p), len(s), len(m), len(v), 0, len(c),
                       1996, 0, 0, 0x0201, cstr(NEO_NAME, 33), cstr("SNK", 17))
    return head + p + s + m + v + c


def softlist(files: dict[str, bytes]) -> str:
    T = "    "

    def rom(key: str, offset: int, flag: str = "") -> str:
        d = files[key]
        f = f'loadflag="{flag}" ' if flag else ""
        return (f'{T * 4}<rom {f}name="{GAME}-{key}.{key}" offset="0x{offset:06x}" size="0x{len(d):06x}" '
                f'crc="{zlib.crc32(d):08x}" sha1="{sha1(d)}" />')

    def area(attrs: str, roms: list[str]) -> list[str]:
        return [f"{T * 3}<dataarea {attrs}>", *roms, f"{T * 3}</dataarea>"]

    c = len(files["c1"])
    lines = [
        '<softwarelist name="neogeo" description="SNK Neo-Geo cartridges">',
        f'{T}<software name="{GAME}">',
        f"{T * 2}<description>Metal Slug Enhanced (hack)</description>",
        f"{T * 2}<year>1996</year>",
        f"{T * 2}<publisher>Nazca / SNK (hack)</publisher>",
        f'{T * 2}<sharedfeat name="release" value="MVS,AES" />',
        f'{T * 2}<sharedfeat name="compatibility" value="MVS,AES" />',
        f'{T * 2}<part name="cart" interface="neo_cart">',
        *area('name="maincpu" width="16" endianness="big" size="0x200000"',
              [rom("p1", 0, "load16_word_swap"), rom("p2", 0x100000, "load16_word_swap")]),
        *area('name="fixed" size="0x040000"', [rom("s1", 0)]),
        *area('name="audiocpu" size="0x020000"', [rom("m1", 0)]),
        *area(f'name="ymsnd:adpcma" size="0x{len(files["v1"]) * 2:06x}"',
              [rom("v1", 0), rom("v2", len(files["v1"]))]),
        *area(f'name="sprites" size="0x{c * 4:06x}"',
              [rom("c1", 0, "load16_byte"), rom("c2", 1, "load16_byte"),
               rom("c3", c * 2, "load16_byte"), rom("c4", c * 2 + 1, "load16_byte")]),
        f"{T * 2}</part>",
        f"{T}</software>",
        "</softwarelist>",
    ]
    return "\n".join(lines) + "\n"


def write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def main() -> int:
    ap = argparse.ArgumentParser(description="Metal Slug Enhanced patcher")
    ap.add_argument("--romset", help="mslug.zip (ou dossier / or folder)")
    ap.add_argument("--out", default=str(ROOT / "output"))
    a = ap.parse_args()

    manifest = json.loads((DATA / "manifest.json").read_text(encoding="utf-8"))
    say(f"Metal Slug Enhanced {manifest['version']}")
    zpath = find_romset(a.romset)
    say(f"Romset : {zpath}")
    r = read_romset(zpath, manifest)
    say("Romset vérifié (CRC32)", "romset checked (CRC32)")

    for rom, ips in manifest["patches"].items():
        r[rom] = apply_ips(r[rom], (DATA / ips).read_bytes())
        if sha1(r[rom]) != manifest["result"][rom]:
            fail(f"{rom} patchée incorrecte (SHA-1)", f"patched {rom} is wrong (SHA-1)")
    say("Patchs appliqués et vérifiés (SHA-1)", "patches applied and checked (SHA-1)")

    out = Path(a.out)
    if out.exists():
        shutil.rmtree(out)

    # NeoSD / MiSTer
    neo = neo_file(r)
    if sha1(neo) != manifest["result"]["neo"]:
        fail("fichier .neo incorrect (SHA-1)", "wrong .neo file (SHA-1)")
    write(out / "neosd_mister" / f"{NEO_NAME}.neo", neo)

    # MAME : romset mslug complet, P-ROM et S-ROM patchées
    for name, d in r.items():
        write(out / "mame" / "mslug" / name, d)

    # Darksoft
    p = r["201-p1.p1"]
    p_lin = p[0x100000:] + p[:0x100000]                      # zone fixe puis banque
    ds = out / "darksoft" / GAME
    write(ds / "prom", p_lin)
    write(ds / "crom0", interleave_words(r["201-c1.c1"], r["201-c2.c2"])
          + interleave_words(r["201-c3.c3"], r["201-c4.c4"]))
    write(ds / "srom", r["201-s1.s1"])
    write(ds / "m1rom", r["201-m1.m1"])
    write(ds / "vroma0", r["201-v1.v1"] + r["201-v2.v2"])
    write(ds / "fpga", b"10")

    # BackBit Platinum MVS : ROM au format MAME non zippées + neogeo.xml
    bb = {"p1": p[0x100000:], "p2": p[:0x100000], "s1": r["201-s1.s1"], "m1": r["201-m1.m1"],
          "v1": r["201-v1.v1"], "v2": r["201-v2.v2"],
          "c1": r["201-c1.c1"], "c2": r["201-c2.c2"], "c3": r["201-c3.c3"], "c4": r["201-c4.c4"]}
    for k, d in bb.items():
        write(out / "backbit" / GAME / f"{GAME}-{k}.{k}", d)
    (out / "backbit" / GAME / "neogeo.xml").write_text(softlist(bb), encoding="utf-8")

    print()
    say("Terminé ! Fichiers dans :", "Done! Files in:")
    print(f"  {out}")
    print(f"  neosd_mister\\{NEO_NAME}.neo   NeoSD, MiSTer")
    print(f"  mame\\mslug\\                     MAME")
    print(f"  darksoft\\{GAME}\\                 Darksoft")
    print(f"  backbit\\{GAME}\\                  BackBit Platinum MVS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
