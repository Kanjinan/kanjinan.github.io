===========================================================================
 METAL SLUG ENHANCED 1.0 - outil de patch / patcher
 ROM hack de Metal Slug (Nazca / SNK, 1996) pour Neo Geo
===========================================================================

[FR] -----------------------------------------------------------------------

Cet outil construit Metal Slug Enhanced a partir de VOTRE propre romset MAME
du jeu original. Il ne contient AUCUNE donnee du jeu original : seulement les
patchs IPS du hack (dossier data).

Ce qu'il faut :
  - Windows, et Python 3.9 ou plus (https://www.python.org/downloads/,
    cocher "Add python.exe to PATH" a l'installation) ;
  - la romset MAME "mslug" (Metal Slug - Super Vehicle-001, NGH 0201) :
    mslug.zip. Elle est verifiee fichier par fichier (CRC32).

Utilisation :
  1. Placez mslug.zip dans ce dossier (sinon l'outil demandera son chemin).
  2. Double-cliquez sur "Construire - Build.bat". C'est fait en quelques
     secondes.

Resultat, dans le dossier "output" :
  - neosd_mister\METAL SLUG ENHANCED.neo : NeoSD et MiSTer (core Neo Geo).
    Sur MiSTer, copiez-le dans games\NeoGeo de la carte SD.
  - mame\mslug : romset pour MAME. Lancez par exemple :
      mame mslug -rompath "chemin\output\mame;C:\MAME\roms"
    (le dossier output\mame doit etre en premier ; MAME signale des sommes
    de controle incorrectes : c'est normal, le jeu est modifie).
  - darksoft\mslugenh : cartouche Darksoft.
  - backbit\mslugenh  : BackBit Platinum MVS (avec neogeo.xml).

Chaque fichier construit est verifie (empreinte SHA-1).

Jouer :
  - Au lancement d'une partie, un ecran START / OPTION apparait, en arcade
    comme sur console. OPTION ouvre le menu des reglages du hack.
  - Haut/Bas : choisir la ligne. Gauche/Droite : changer la valeur.
    A sur EXIT : valider et revenir a l'ecran titre.
  - Sur MVS (et dans MAME), les reglages sont
    sauvegardes. Sur AES, ils sont gardes jusqu'a l'extinction.
  - Avec les reglages par defaut, le jeu est identique a l'original.

Autres systemes : python3 patcher.py --romset chemin/mslug.zip
Ou appliquez vous-meme data\mslug_p1.ips a 201-p1.p1 et data\mslug_s1.ips a
201-s1.s1 avec n'importe quel outil IPS (Floating IPS, Lunar IPS...).

Mentions : projet de fan non commercial, sans lien avec SNK. Metal Slug
(c) SNK. Les ROMs produites sont pour votre usage personnel : ne les
distribuez pas, ne vendez pas de repros.

[EN] -----------------------------------------------------------------------

This tool builds Metal Slug Enhanced from YOUR OWN MAME romset of the
original game. It contains NO data from the original game: only the hack's
IPS patches (data folder).

You need:
  - Windows, and Python 3.9 or newer (https://www.python.org/downloads/,
    tick "Add python.exe to PATH" during setup);
  - the MAME "mslug" romset (Metal Slug - Super Vehicle-001, NGH 0201):
    mslug.zip. Every file is checked (CRC32).

How to use:
  1. Put mslug.zip in this folder (otherwise the tool asks for its path).
  2. Double-click "Construire - Build.bat". It takes a few seconds.

Output, in the "output" folder:
  - neosd_mister\METAL SLUG ENHANCED.neo : NeoSD and MiSTer (Neo Geo core).
    On MiSTer, copy it to games\NeoGeo on the SD card.
  - mame\mslug : romset for MAME. Run for example:
      mame mslug -rompath "path\output\mame;C:\MAME\roms"
    (output\mame must come first; MAME reports wrong checksums: this is
    expected, the game is modified).
  - darksoft\mslugenh : Darksoft cartridge.
  - backbit\mslugenh  : BackBit Platinum MVS (with neogeo.xml).

Every file built is checked (SHA-1).

Playing:
  - When a game starts, a START / OPTION screen appears, on arcade as on
    console. OPTION opens the hack's settings menu.
  - Up/Down: pick a line. Left/Right: change the value.
    A on EXIT: confirm and go back to the title screen.
  - On MVS (and in MAME), settings are saved. On AES,
    they are kept until power-off.
  - With the default settings, the game is identical to the original.

Other systems: python3 patcher.py --romset path/to/mslug.zip
Or apply data/mslug_p1.ips to 201-p1.p1 and data/mslug_s1.ips to
201-s1.s1 yourself with any IPS tool (Floating IPS, Lunar IPS...).

Notice: non-commercial fan project, not affiliated with SNK. Metal Slug
(c) SNK. The ROMs you build are for your personal use: do not distribute
them or sell repros.
