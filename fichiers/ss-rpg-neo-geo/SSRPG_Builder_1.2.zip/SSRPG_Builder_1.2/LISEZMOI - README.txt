===========================================================================
 SAMURAI SPIRITS RPG 1.2 - constructeur de ROM / ROM builder
 Shinsetsu Samurai Spirits: Bushidou Retsuden en cartouche Neo Geo
 (japonais, francais, anglais, espagnol)
===========================================================================

[FR] -----------------------------------------------------------------------

Cet outil construit le portage cartouche de Shinsetsu Samurai Spirits:
Bushidou Retsuden (Neo Geo CD, 1997), traduit en francais, anglais et
espagnol, a partir de VOTRE PROPRE image du CD. Il ne contient AUCUNE donnee
du jeu original : seulement mon travail (le code du portage, les
traductions, la police, les icones et les tables de la cartouche). Tout le
reste est recopie depuis votre CD au moment de la construction.

Ce qu'il faut :
  - Windows, et Python 3.9 ou plus en 64 bits (https://www.python.org/downloads/,
    cocher "Add python.exe to PATH" a l'installation). Au premier lancement,
    l'outil installe numpy (connexion Internet requise) ;
  - environ 1 Go de memoire libre ;
  - l'image du CD japonais au format Redump, decompressee :
      Shinsetsu Samurai Spirits - Bushidou Retsuden (Japan).cue
      + ses 32 fichiers "(Track 01).bin" a "(Track 32).bin"
    Les pistes sont verifiees (SHA-1). Un seul .bin (fusionne) convient
    aussi, s'il contient exactement les memes pistes. Une image .chd doit
    d'abord etre extraite (chdman).

Utilisation :
  1. Placez le .cue et ses .bin dans ce dossier, ou dans un sous-dossier
     (sinon l'outil demandera ou ils sont).
  2. Double-cliquez sur "Construire - Build.bat".
  3. Patientez environ 1 minute (la musique des pistes audio est convertie
     pour la Neo Geo).

Resultat, dans le dossier "output" :
  Shinsetsu Samurai Spirits - Bushidou Retsuden (JP-FR-EN-ES).neo
  (environ 96 Mo). Sur MiSTer, copiez-le dans games\NeoGeo de la carte SD.

Configuration requise pour jouer :
  - MiSTer FPGA avec le core Neo Geo et un module SDRAM de 128 Mo.
  - Neo SD Pro : la ROM fait maintenant 765 Mbit, sous la limite estimee de
    768 Mbit par jeu, mais elle n'a pas encore ete testee sur cette cartouche.
  - La ROM utilise 16 banques de programme : elle ne tourne pas dans MAME
    (8 banques au plus).

Jouer :
  - A l'allumage, choisissez la langue avec Haut/Bas, puis A ou START.
  - En jeu, le bouton D ouvre le menu.
  - Sauvegardes sur carte memoire.

Nouveau dans la version 1.2 :
  - ROM ramenee de 909 a 765 Mbit (sprites ranges plus efficacement), pour
    tenir dans une cartouche Neo SD Pro ;
  - plus de graphismes parasites en haut de l'ecran de demarrage UniBIOS ;
  - pour gagner de la place, la musique des pistes CD est convertie a
    9,6 kHz au lieu de 12,7 kHz : le son est un peu plus etouffe ;
  - ecran titre : signature NK V1.2.
  - correctif du 25/11/2026 : en anglais et en espagnol, les textes de
    combat et le "Enter?" de la carte s'affichaient mal (premiere
    edition de la 1.2) ; couleurs des sprites de combat corrigees.

Version 1.1 :
  - la musique du 2e scenario se lance enfin (elle restait muette) ;
  - les boutiques ne se figent plus (on peut acheter, vendre et sortir) ;
  - repliques des marchands raccourcies pour tenir dans leur bulle ;
  - menu Achat / Vente / Fin et noms des boutiques lisibles ;
  - plus de pictogrammes parasites devant les prix ni de kanji apres la
    quantite dans la liste d'achat.

Chaque section de la ROM est verifiee (SHA-1). Si votre version de numpy
n'est pas la meme que la mienne, la musique peut differer tres legerement :
c'est signale, et le jeu reste jouable.

Ligne de commande : python builder.py --cue "chemin\jeu.cue" [--out dossier]

Mentions : projet de fan non commercial, sans lien avec SNK ni approuve par
SNK. Samurai Spirits et Samurai Shodown sont (c) SNK. Les ROMs produites
sont pour votre usage personnel : ne les distribuez pas, ne vendez pas de
repros.

[EN] -----------------------------------------------------------------------

This tool builds the cartridge port of Shinsetsu Samurai Spirits: Bushidou
Retsuden (Neo Geo CD, 1997), translated into French, English and Spanish,
from YOUR OWN image of the CD. It contains NO data from the original game:
only my own work (the port's code, the translations, the font, the icons and
the cartridge tables). Everything else is copied from your CD during the
build.

You need:
  - Windows, and 64-bit Python 3.9 or newer (https://www.python.org/downloads/,
    tick "Add python.exe to PATH" during setup). On first run, the tool
    installs numpy (Internet connection required);
  - about 1 GB of free memory;
  - the Japanese CD image as a Redump dump, uncompressed:
      Shinsetsu Samurai Spirits - Bushidou Retsuden (Japan).cue
      + its 32 files "(Track 01).bin" to "(Track 32).bin"
    The tracks are checked (SHA-1). A single (merged) .bin also works if it
    holds exactly the same tracks. A .chd image must be extracted first
    (chdman).

How to use:
  1. Put the .cue and its .bin files in this folder, or in a subfolder
     (otherwise the tool asks where they are).
  2. Double-click "Construire - Build.bat".
  3. Wait about 1 minute (the music from the audio tracks is converted for
     the Neo Geo).

Output, in the "output" folder:
  Shinsetsu Samurai Spirits - Bushidou Retsuden (JP-FR-EN-ES).neo
  (about 96 MB). On MiSTer, copy it to games\NeoGeo on the SD card.

Requirements to play:
  - MiSTer FPGA with the Neo Geo core and a 128 MB SDRAM module.
  - Neo SD Pro: the ROM is now 765 Mbit, under the estimated 768 Mbit
    per-game limit, but it has not been tested on that cart yet.
  - The ROM uses 16 program banks: it does not run in MAME (8 banks at
    most).

Playing:
  - At power-on, pick the language with Up/Down, then A or START.
  - In game, button D opens the menu.
  - Saves go to the memory card.

New in version 1.2:
  - ROM reduced from 909 to 765 Mbit (sprites stored more efficiently), to
    fit a Neo SD Pro cart;
  - no more graphics garbage at the top of the UniBIOS boot screen;
  - to save space, the CD track music is converted at 9.6 kHz instead of
    12.7 kHz: it sounds a bit more muffled;
  - title screen: NK V1.2 signature.
  - fix of 25 Nov 2026: in English and Spanish, battle texts and the
    map's "Enter?" were garbled (first release of 1.2); battle sprite
    colours fixed.

Version 1.1:
  - the 2nd story's music now plays (it stayed silent);
  - shops no longer freeze (you can buy, sell and leave);
  - shopkeeper lines shortened to fit their box;
  - readable Buy / Sell / Exit menu and shop names;
  - no more stray icons before prices or kanji after the quantity in the
    shop list.

Every section of the ROM is checked (SHA-1). If your numpy version differs
from mine, the music may differ very slightly: this is reported and the game
remains playable.

Command line: python builder.py --cue "path/to/game.cue" [--out folder]

Notice: non-commercial fan project, not affiliated with or endorsed by SNK.
Samurai Spirits and Samurai Shodown are (c) SNK. The ROMs you build are for
your personal use: do not distribute them or sell repros.
