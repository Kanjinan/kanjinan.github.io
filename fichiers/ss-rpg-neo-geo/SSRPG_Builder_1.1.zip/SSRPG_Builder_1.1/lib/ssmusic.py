"""Musique de la cartouche (ROM V2) : les 31 pistes audio du CD (pistes 2 a 32)
converties en ADPCM-B mono, comme cart_port/build_snd.py (build_music).

Music ROM (V2): the CD's 31 audio tracks (2 to 32) converted to mono ADPCM-B.
"""
from __future__ import annotations

VSIZE = 0x1000000
MUSIC_GAIN = 5.0
LIM_T = 24000.0
B1 = [1, 3, 5, 7, 9, 11, 13, 15, -1, -3, -5, -7, -9, -11, -13, -15]
B2 = [57, 57, 57, 57, 77, 102, 128, 153, 57, 57, 57, 57, 77, 102, 128, 153]


def adpcmb_encode(x):
    """x : entiers 16 bits -> octets ADPCM-B (quartet haut en premier), decodeur Yamaha."""
    acc, step = 0, 127
    out = bytearray((len(x) + 1) // 2)
    hi = True
    k = 0
    for v in x:
        d = v - acc
        if d < 0:
            n = 8
            d = -d
        else:
            n = 0
        q = (d * 4) // step
        n |= 7 if q > 7 else q
        t = B1[n] * step
        acc += t // 8 if t >= 0 else -((-t) // 8)
        if acc > 32767:
            acc = 32767
        elif acc < -32768:
            acc = -32768
        step = (step * B2[n]) // 64
        if step < 127:
            step = 127
        elif step > 24576:
            step = 24576
        if hi:
            out[k] = n << 4
        else:
            out[k] |= n
            k += 1
        hi = not hi
    return bytes(out)


def build_music(tracks: dict, progress=print) -> bytes:
    """tracks : {numero de piste (2-32): chemin du .bin ou objet (path, offset, size)}.
    Renvoie la ROM V2 (16 Mo)."""
    import numpy as np
    total = sum(_size(f) // 4 for f in tracks.values()) / 44100.0
    dn = int((VSIZE - len(tracks) * 512) * 2 / total / 55555 * 65536)
    rate = 55555.0 * dn / 65536
    v2 = bytearray()
    for n, f in sorted(tracks.items()):
        x = _pcm(f).reshape(-1, 2).astype(np.float64).mean(axis=1)
        fc = 0.45 * rate / 44100.0
        t = np.arange(-63, 64)
        h = 2 * fc * np.sinc(2 * fc * t) * np.hamming(len(t))
        x = np.convolve(x, h / h.sum(), mode="same")
        m = int(len(x) * rate / 44100.0)
        y = np.interp(np.arange(m) * (44100.0 / rate), np.arange(len(x)), x)
        y = y * MUSIC_GAIN
        a = np.abs(y)
        k = a > LIM_T
        y[k] = np.sign(y[k]) * (LIM_T + (32000 - LIM_T) * np.tanh((a[k] - LIM_T) / (32000 - LIM_T)))
        y = np.clip(np.round(y), -32768, 32767).astype(np.int64).tolist()
        enc = adpcmb_encode(y)
        enc += b"\x08" * ((-len(enc)) % 256)
        v2 += enc
        progress(f"  piste / track {n:02d} : {m / rate:.0f} s")
    assert len(v2) <= VSIZE
    return bytes(v2) + bytes(VSIZE - len(v2))


def _size(t) -> int:
    import os
    return t.size if hasattr(t, "size") else os.path.getsize(t)


def _pcm(t):
    import numpy as np
    if hasattr(t, "path"):
        return np.fromfile(t.path, dtype="<i2", count=t.size // 2, offset=t.offset)
    return np.fromfile(t, dtype="<i2")
