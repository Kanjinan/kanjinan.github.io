"""Patch du portage cartouche de Shinsetsu Samurai Spirits / cartridge port patch.

Le fichier .neo est decrit section par section (P, S, M, V1, V2, C) comme une suite
d'operations : COPY (recopier des octets de la source), INSERT (mon travail : code
du portage, traductions, police, icones...) et FILL (remplissage).

La source est reconstruite chez l'utilisateur a partir de SON CD :
  tous les fichiers du CD (piste 1, ISO 9660), tries par nom, mis bout a bout,
  puis la musique (pistes audio 2 a 32 converties en ADPCM-B, lib/ssmusic.py).
Le patch ne contient donc aucune donnee du jeu original.

Format (compresse lzma) : b"SSP1", puis pour chaque section :
  nom (4 octets), taille (u32), transformation (u8 : 0 aucune, 1 octets echanges
  par paires, 2 permutation des sprites), nombre d'octets d'operations (u32), operations :
  0x01 COPY varint(position) varint(longueur) ; 0x02 INSERT varint(longueur) octets ;
  0x03 FILL octet varint(longueur)
"""
from __future__ import annotations

import lzma
import struct

MAGIC = b"SSP1"
C_PERM = (2, 0, 3, 1)     # octet k d'un groupe de 4 (forme CD) = octet C_PERM[k] du .neo


def varint(n: int) -> bytes:
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        out.append(b | 0x80 if n else b)
        if not n:
            return bytes(out)


def _rv(d, i):
    n = shift = 0
    while True:
        b = d[i]
        i += 1
        n |= (b & 0x7F) << shift
        shift += 7
        if not b & 0x80:
            return n, i


def run_ops(source, ops: bytes, size: int) -> bytearray:
    out = bytearray(size)
    o = i = 0
    mv = memoryview(source)
    while i < len(ops):
        op = ops[i]
        i += 1
        if op == 1:
            p, i = _rv(ops, i)
            n, i = _rv(ops, i)
            if p + n > len(source):
                raise ValueError("source trop courte / source too short")
            out[o:o + n] = mv[p:p + n]
        elif op == 2:
            n, i = _rv(ops, i)
            out[o:o + n] = ops[i:i + n]
            i += n
        elif op == 3:
            b = ops[i]
            n, i = _rv(ops, i + 1)
            if b:
                out[o:o + n] = bytes([b]) * n
        else:
            raise ValueError("patch invalide / invalid patch")
        o += n
    if o != size:
        raise ValueError("taille inattendue / unexpected size")
    return out


def to_neo(data: bytearray, transform: int) -> bytearray:
    """Forme du patch (proche du CD) -> forme du fichier .neo."""
    if transform == 1:
        data[0::2], data[1::2] = data[1::2], data[0::2]
    elif transform == 2:
        import numpy as np
        a = np.frombuffer(bytes(data), dtype=np.uint8).reshape(-1, 4)
        out = np.empty_like(a)
        for k, src in enumerate(C_PERM):
            out[:, src] = a[:, k]
        data = bytearray(out.tobytes())
    return data


def from_neo(data: bytes, transform: int) -> bytes:
    """Forme du fichier .neo -> forme du patch."""
    if transform == 1:
        b = bytearray(data)
        b[0::2], b[1::2] = data[1::2], data[0::2]
        return bytes(b)
    if transform == 2:
        import numpy as np
        a = np.frombuffer(data, dtype=np.uint8).reshape(-1, 4)
        return a[:, list(C_PERM)].tobytes()
    return data


def apply(source, patch: bytes, progress=None):
    """-> liste de (nom, octets au format .neo)."""
    d = lzma.decompress(patch)
    if d[:4] != MAGIC:
        raise ValueError("patch invalide / invalid patch")
    i = 4
    out = []
    while i < len(d):
        name = d[i:i + 4].decode().strip()
        size, tr, nops = struct.unpack(">IBI", d[i + 4:i + 13])
        i += 13
        if progress:
            progress(name)
        out.append((name, to_neo(run_ops(source, d[i:i + nops], size), tr)))
        i += nops
    return out
