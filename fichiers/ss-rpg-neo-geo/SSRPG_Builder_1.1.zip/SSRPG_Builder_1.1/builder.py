"""Samurai Spirits RPG (cartouche Neo Geo) - constructeur de ROM / ROM builder

Construit le portage cartouche de Shinsetsu Samurai Spirits: Bushidou Retsuden
(4 langues : japonais, francais, anglais, espagnol) a partir de VOTRE image du CD
Neo Geo (dump Redump, .cue + .bin).
Builds the cartridge port (Japanese, French, English, Spanish) from YOUR OWN
Neo Geo CD image (Redump dump, .cue + .bin).

Aucune donnee du jeu original n'est fournie avec cet outil.
No data from the original game is included with this tool.

Usage :
  python builder.py [--cue chemin\\jeu.cue] [--out output]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import struct
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LIB = ROOT / "lib"
DATA = ROOT / "data"
sys.path.insert(0, str(LIB))

import sspatch  # noqa: E402
import ssmusic  # noqa: E402

SECTOR = 2352


def say(fr: str, en: str = "") -> None:
    print(fr if not en else f"{fr}  /  {en}", flush=True)


def fail(fr: str, en: str) -> None:
    say(f"\nERREUR : {fr}", f"ERROR: {en}")
    raise SystemExit(1)


def ask(fr: str, en: str) -> str:
    try:
        return input(f"{fr} / {en}\n> ").strip().strip('"')
    except EOFError:
        return ""


# ---------------------------------------------------------------------------
# Image du CD / CD image

class Track:
    def __init__(self, path: Path, offset: int, size: int):
        self.path, self.offset, self.size = path, offset, size

    def read(self) -> bytes:
        with open(self.path, "rb") as f:
            f.seek(self.offset)
            return f.read(self.size)

    def sha1(self) -> str:
        h = hashlib.sha1()
        with open(self.path, "rb") as f:
            f.seek(self.offset)
            left = self.size
            while left:
                b = f.read(min(left, 1 << 24))
                if not b:
                    break
                h.update(b)
                left -= len(b)
        return h.hexdigest()


def msf(s: str) -> int:
    m, sec, fr = (int(x) for x in s.split(":"))
    return (m * 60 + sec) * 75 + fr


def parse_cue(cue: Path) -> dict:
    """{numero de piste: Track} ; .bin separes (Redump) ou un seul .bin."""
    files = []          # [(chemin, [(piste, secteur de debut)])]
    for line in cue.read_text(encoding="latin1").splitlines():
        line = line.strip()
        m = re.match(r'FILE\s+"?(.*?)"?\s+BINARY$', line, re.I)
        if m:
            files.append((cue.parent / m.group(1), []))
            continue
        m = re.match(r"TRACK\s+(\d+)", line, re.I)
        if m and files:
            files[-1][1].append([int(m.group(1)), None])
            continue
        m = re.match(r"INDEX\s+(\d+)\s+(\d+:\d+:\d+)", line, re.I)
        if m and files and files[-1][1] and files[-1][1][-1][1] is None:
            files[-1][1][-1][1] = msf(m.group(2))     # premier INDEX (00 s'il existe)
    tracks = {}
    for path, tl in files:
        if not path.is_file():
            fail(f"fichier introuvable : {path}", f"file not found: {path}")
        size = path.stat().st_size
        for k, (n, start) in enumerate(tl):
            end = tl[k + 1][1] * SECTOR if k + 1 < len(tl) else size
            tracks[n] = Track(path, start * SECTOR, end - start * SECTOR)
    return tracks


def find_cue(arg: str | None) -> Path:
    if arg:
        p = Path(arg)
        if p.is_dir():
            cues = sorted(p.glob("*.cue"))
            if cues:
                return cues[0]
        if p.is_file():
            return p
        fail(f"{arg} : pas de fichier .cue", f"{arg}: no .cue file")
    for folder in (ROOT, *[d for d in sorted(ROOT.iterdir()) if d.is_dir() and d.name not in ("lib", "data", "output")],
                   ROOT.parent):
        cues = sorted(folder.glob("*.cue"))
        if cues:
            return cues[0]
    p = ask("Chemin du fichier .cue du CD (ou de son dossier) ? (Entree = annuler)",
            "Path to the CD's .cue file (or its folder)? (Enter = cancel)")
    if not p:
        raise SystemExit(1)
    return find_cue(p)


def read_iso(track: Track) -> bytes:
    """Tous les fichiers de la piste de donnees (ISO 9660), tries par nom, bout a bout."""
    with open(track.path, "rb") as f:
        def sec(lba, n=1):
            out = bytearray()
            for i in range(n):
                f.seek(track.offset + (lba + i) * SECTOR + 16)
                out += f.read(2048)
            return bytes(out)

        pvd = sec(16)
        if pvd[1:6] != b"CD001":
            fail("piste 1 : pas de systeme de fichiers ISO 9660", "track 1: no ISO 9660 file system")
        files = []

        def walk(lba, size, path):
            d = sec(lba, (size + 2047) // 2048)
            o = 0
            while o < len(d):
                n = d[o]
                if n == 0:
                    o = (o // 2048 + 1) * 2048
                    continue
                rl, rs = struct.unpack("<I", d[o + 2:o + 6])[0], struct.unpack("<I", d[o + 10:o + 14])[0]
                fl, nl = d[o + 25], d[o + 32]
                name = d[o + 33:o + 33 + nl]
                if name not in (b"\0", b"\1"):
                    nm = name.decode("latin1").split(";")[0]
                    if fl & 2:
                        walk(rl, rs, path + nm + "/")
                    else:
                        files.append((path + nm, rl, rs))
                o += n

        root = pvd[156:190]
        walk(struct.unpack("<I", root[2:6])[0], struct.unpack("<I", root[10:14])[0], "")
        out = bytearray()
        for _name, lba, size in sorted(files):
            out += sec(lba, (size + 2047) // 2048)[:size]
        return bytes(out)


# ---------------------------------------------------------------------------

def main() -> int:
    ap = argparse.ArgumentParser(description="Samurai Spirits RPG cartridge ROM builder")
    ap.add_argument("--cue", help="fichier .cue du CD / the CD's .cue file")
    ap.add_argument("--out", default=str(ROOT / "output"))
    args = ap.parse_args()

    man = json.loads((DATA / "manifest.json").read_text(encoding="utf-8"))
    t0 = time.time()
    say(f"Samurai Spirits RPG (cartouche) - version {man['version']}")

    say("\n[1/4] Verification du CD", "checking the CD")
    cue = find_cue(args.cue)
    say(f"CD : {cue}")
    tracks = parse_cue(cue)
    want = {int(k): v for k, v in man["tracks"].items()}
    bad = []
    for n, info in sorted(want.items()):
        t = tracks.get(n)
        if t is None or t.size != info["size"] or t.sha1() != info["sha1"]:
            bad.append(n)
    if bad:
        fail("CD incorrect ou incomplet (pistes " + ", ".join(map(str, bad)) + "). Il faut le dump Redump : "
             + man["cd_name"],
             "wrong or incomplete CD (tracks " + ", ".join(map(str, bad)) + "). The Redump dump is required: "
             + man["cd_name"])
    say("  OK (32 pistes / tracks)")

    say("\n[2/4] Lecture des fichiers du CD", "reading the CD files")
    source = read_iso(tracks[1])
    say(f"  {len(source) // 1048576} Mo")

    say("\n[3/4] Conversion de la musique (pistes audio 2 a 32, 1 a 3 min)",
        "converting the music (audio tracks 2 to 32, 1 to 3 min)")
    v2 = ssmusic.build_music({n: tracks[n] for n in range(2, 33)})
    source += v2

    say("\n[4/4] Construction de la ROM", "building the ROM")
    try:
        parts = sspatch.apply(source, (DATA / "neo.patch").read_bytes())
    except (ValueError, IndexError, MemoryError) as e:
        fail(f"application du patch impossible ({e})", f"cannot apply the patch ({e})")
    ok = True
    for name, data in parts:
        same = hashlib.sha1(data).hexdigest() == man["sha1"][name]
        if same:
            say(f"  {name:3s} : identique a la version de reference", "identical to the reference")
        elif name == "V2":
            say("  V2  : musique legerement differente de la version de reference (autre version de numpy ?)"
                " - jouable quand meme", "music slightly differs from the reference (other numpy version?)"
                " - still playable")
        else:
            say(f"  {name:3s} : ERREUR, differente de la version de reference", "ERROR")
            ok = False
    if not ok:
        return 1
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    neo = out / man["neo_name"]
    with open(neo, "wb") as f:
        for _name, data in parts:
            f.write(data)
    say(f"\nTermine en {int(time.time() - t0)} s.", f"done in {int(time.time() - t0)} s.")
    say(f"  {neo}")
    say("  MiSTer : copiez ce fichier dans games\\NeoGeo (core Neo Geo, module SDRAM de 128 Mo).",
        "MiSTer: copy this file to games\\NeoGeo (Neo Geo core, 128 MB SDRAM module).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
