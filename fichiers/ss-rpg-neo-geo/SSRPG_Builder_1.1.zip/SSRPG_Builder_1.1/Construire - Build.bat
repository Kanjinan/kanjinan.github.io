@echo off
rem Samurai Spirits RPG (cartouche) - constructeur de ROM / ROM builder
chcp 65001 >nul
set PYTHONUTF8=1
cd /d "%~dp0"

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY goto nopython
%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) and sys.maxsize > 2**32 else 1)" >nul 2>nul || goto nopython

%PY% -c "import numpy" >nul 2>nul
if errorlevel 1 (
    echo Installation de numpy / installing numpy...
    %PY% -m pip install --user numpy || goto end
)

%PY% builder.py %*
goto end

:nopython
echo Python 3.9 ou plus (64 bits) est necessaire / Python 3.9 or newer (64-bit) is required:
echo   https://www.python.org/downloads/
echo (cocher "Add python.exe to PATH" / tick "Add python.exe to PATH")

:end
echo.
pause
