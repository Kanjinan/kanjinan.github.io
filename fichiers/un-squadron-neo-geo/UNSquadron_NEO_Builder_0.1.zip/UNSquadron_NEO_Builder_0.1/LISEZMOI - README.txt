===========================================================================
 U.N. SQUADRON NEO - constructeur de ROM / ROM builder
 Portage de fan sur Neo Geo - Neo Geo fan port
===========================================================================

[FR] -----------------------------------------------------------------------

Cet outil construit le portage Neo Geo de U.N. Squadron a partir de VOTRE
propre romset MAME du jeu arcade original. Il ne contient AUCUNE donnee du
jeu original (ni code, ni graphismes, ni musique) : seulement le travail du
portage (modifications, couche de traduction, pilote son, traduction
francaise, logo) et les informations necessaires pour reconstruire le reste
chez vous.

Version de test : la premiere mission est verifiee de bout en bout ; les
missions suivantes tournent mais n'ont pas encore ete jouees jusqu'au bout.
Vos retours sont les bienvenus (blog ou itch.io).

Ce qu'il faut :
  - Windows, et Python 3.9 ou plus (https://www.python.org/downloads/,
    cocher "Add python.exe to PATH" a l'installation) ;
  - MAME (version 0.250 ou plus recente ; teste avec 0.289) ;
  - la romset MAME "unsquad" (U.N. Squadron, USA) : unsquad.zip.

Utilisation :
  1. Placez unsquad.zip dans ce dossier (sinon l'outil demandera son chemin).
  2. Double-cliquez sur "Construire - Build.bat".
     Si MAME n'est pas dans C:\MAME, l'outil demande le chemin de mame.exe.
  3. Patientez (quelques minutes : les sons sont enregistres dans MAME a
     partir du jeu original, puis encodes pour la Neo Geo).

Resultat, dans le dossier "output" :
  - neosd_mister.zip : fichier .neo pour NeoSD et MiSTer (core Neo Geo)
  - darksoft.zip     : cartouche Darksoft
  - backbit.zip      : BackBit Platinum MVS
  - mame\unsquadneo  : ROMs pour MAME (romset "unsquadneo", liste logicielle
                       neogeo : voir backbit.zip\unsquadneo\neogeo.xml)

Au demarrage, un ecran d'options permet de choisir la difficulte, les
degats, le continue, la partie gratuite, la mission de depart et la langue
(anglais ou francais). Sur AES, la partie gratuite est active par defaut.

L'outil verifie chaque ROM construite (empreinte SHA-1). Si votre version de
MAME n'est pas la meme que la mienne, le son peut differer tres legerement :
c'est signale, et le jeu reste jouable.

Ligne de commande (autres systemes, ou options) :
  python builder.py --romset chemin\unsquad.zip --mame chemin\mame.exe

Mentions : projet de fan non commercial, sans lien avec Capcom.
U.N. Squadron / Area 88 (c) Capcom ; Area 88 est tire du manga de Kaoru
Shintani. Les ROMs produites sont pour votre usage personnel : ne les
distribuez pas, ne vendez pas de repros.
adpcmtool.py : ngdevkit (c) Damien Ciabrini, licence LGPL-3 (lib\).

[EN] -----------------------------------------------------------------------

This tool builds the Neo Geo port of U.N. Squadron from YOUR OWN MAME
romset of the original arcade game. It contains NO data from the original
game (no code, graphics or music): only the port's own work (changes,
translation layer, sound driver, French translation, logo) and the
information needed to rebuild the rest on your computer.

Test version: the first mission has been checked from start to finish; the
later missions run but have not been played through yet. Feedback is
welcome (blog or itch.io).

You need:
  - Windows, and Python 3.9 or newer (https://www.python.org/downloads/,
    tick "Add python.exe to PATH" during setup);
  - MAME (0.250 or newer; tested with 0.289);
  - the MAME "unsquad" romset (U.N. Squadron, USA): unsquad.zip.

How to use:
  1. Put unsquad.zip in this folder (otherwise the tool asks for its path).
  2. Double-click "Construire - Build.bat".
     If MAME is not in C:\MAME, the tool asks for the path to mame.exe.
  3. Wait (a few minutes: sounds are recorded in MAME from the original
     game, then encoded for the Neo Geo).

Output, in the "output" folder:
  - neosd_mister.zip : .neo file for NeoSD and MiSTer (Neo Geo core)
  - darksoft.zip     : Darksoft cartridge
  - backbit.zip      : BackBit Platinum MVS
  - mame\unsquadneo  : ROMs for MAME ("unsquadneo" set, neogeo software
                       list: see backbit.zip\unsquadneo\neogeo.xml)

At boot, an options screen sets difficulty, damage, continue, free play,
the starting mission and the language (English or French). On AES, free
play is on by default.

The tool checks every ROM it builds (SHA-1). If your MAME version differs
from mine, the sound may differ very slightly: this is reported and the
game remains playable.

Command line (other systems, or options):
  python builder.py --romset path/to/unsquad.zip --mame path/to/mame

Notice: non-commercial fan project, not affiliated with Capcom.
U.N. Squadron / Area 88 (c) Capcom; Area 88 is based on the manga by Kaoru
Shintani. The ROMs you build are for your personal use: do not distribute
them or sell repros.
adpcmtool.py: ngdevkit (c) Damien Ciabrini, LGPL-3 license (lib/).
