"""Copies pour cartouches reelles (usage personnel, pas d'archive) :

  build/carts/neosd_mister/UN Squadron.neo   NeoSD / core MiSTer
  build/carts/backbit/unsquadneo/                 BackBit Platinum MVS (ROM
                                                 MAME non zippees + neogeo.xml)
  build/carts/darksoft/unsquadneo/                Darksoft (prom, crom0, srom,
                                                 m1rom, vroma0, fpga)

BackBit : elle ne lit pas les .neo mais les ROM au format MAME, non zippees,
dans un dossier par jeu (comme les sorties homebrew BB01-p1.p1, -c1.c1...).
P1 de 2 Mo decoupee au standard cartouche : p1 = $000000-$0FFFFF (fixe),
p2 = banque $200000 (1 Mo). C1/C2 en puissance de deux (4 Mo chacune).
Limites BackBit : C 512 Mbit, V A 128 Mbit, P 64 Mbit, S/M 4 Mbit.
Darksoft : comme NEO_GAME/export_darksoft.py ; prom = P1 telle quelle (2 Mo
lineaires : $000000-$0FFFFF puis la banque $200000, sans commutation),
crom0 = C1/C2 entrelacees par mots, fpga = "10" (mapping standard).

Usage : python tools/export_carts.py   (apres build.ps1 -NoRun)
"""
from __future__ import annotations

import hashlib
import shutil
import sys
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
BUILD = ROOT / "build"
GAME = "unsquadneo"
NEO = BUILD / "UN Squadron.neo"
FPGA_STANDARD = b"10"


def interleave_words(c1: bytes, c2: bytes) -> bytes:
    if len(c1) != len(c2) or len(c1) % 2:
        raise ValueError(f"C1/C2 de tailles incompatibles : {len(c1)} / {len(c2)}")
    out = bytearray(len(c1) * 2)
    out[0::4] = c1[0::2]
    out[1::4] = c1[1::2]
    out[2::4] = c2[0::2]
    out[3::4] = c2[1::2]
    return bytes(out)


def softlist_entry(files: dict[str, bytes]) -> str:
    T = "    "

    def rom(key: str, offset: int, flag: str = "") -> str:
        data = files[key]
        f = f'loadflag="{flag}" ' if flag else ""
        return (f'{T * 4}<rom {f}name="{GAME}-{key}.{key}" offset="0x{offset:06x}" '
                f'size="0x{len(data):06x}" crc="{zlib.crc32(data):08x}" '
                f'sha1="{hashlib.sha1(data).hexdigest()}" />')

    def area(attrs: str, roms: list[str]) -> list[str]:
        return [f"{T * 3}<dataarea {attrs}>", *roms, f"{T * 3}</dataarea>"]

    p_size = len(files["p1"]) + len(files["p2"])
    lines = [
        '<softwarelist name="neogeo" description="SNK Neo-Geo cartridges">',
        f'{T}<software name="{GAME}">',
        f"{T * 2}<description>U.N. Squadron (Neo Geo port)</description>",
        f"{T * 2}<year>2026</year>",
        f"{T * 2}<publisher>Homebrew</publisher>",
        f'{T * 2}<sharedfeat name="release" value="MVS,AES" />',
        f'{T * 2}<sharedfeat name="compatibility" value="MVS,AES" />',
        f'{T * 2}<part name="cart" interface="neo_cart">',
        *area(f'name="maincpu" width="16" endianness="big" size="0x{p_size:06x}"',
              [rom("p1", 0, "load16_word_swap"),
               rom("p2", len(files["p1"]), "load16_word_swap")]),
        *area('name="fixed" size="0x040000"', [rom("s1", 0)]),
        *area('name="audiocpu" size="0x020000"', [rom("m1", 0)]),
        *area(f'name="ymsnd:adpcma" size="0x{len(files["v1"]):06x}"', [rom("v1", 0)]),
        *area(f'name="sprites" size="0x{len(files["c1"]) * 2:06x}"',
              [rom("c1", 0, "load16_byte"), rom("c2", 1, "load16_byte")]),
        f"{T * 2}</part>",
        f"{T}</software>",
        "</softwarelist>",
    ]
    return "\n".join(lines) + "\n"


def export_backbit(rom: dict[str, bytes], out: Path) -> None:
    p = rom["p1"]
    if len(p) > 0x100000:
        if len(p) % 0x100000:
            raise ValueError(f"P1 {len(p)} octets : pas un multiple de 1 Mo")
        files = {"p1": p[:0x100000], "p2": p[0x100000:]}
    else:
        files = {"p1": p}
    files.update({k: rom[k] for k in ("s1", "m1", "v1", "c1", "c2")})
    limits = {"c": 64 << 20, "v": 16 << 20, "p": 8 << 20, "s1": 512 << 10, "m1": 512 << 10}
    if len(rom["c1"]) * 2 > limits["c"] or len(rom["v1"]) > limits["v"] or len(p) > limits["p"]             or len(rom["s1"]) > limits["s1"] or len(rom["m1"]) > limits["m1"]:
        raise ValueError("ROM hors des limites BackBit (C 512, VA 128, P 64, S/M 4 Mbit)")
    root = out / "backbit"
    if root.exists():
        shutil.rmtree(root)
    d = root / GAME
    d.mkdir(parents=True)
    for k, data in files.items():
        (d / f"{GAME}-{k}.{k}").write_bytes(data)
        print(f"  {GAME}-{k}.{k:3s} {len(data):>10d} octets")
    if "p2" in files:
        (d / "neogeo.xml").write_text(softlist_entry(files), encoding="utf-8")
    assert b"".join(files[k] for k in ("p1", "p2") if k in files) == p
    print(f"{d}")


def main() -> int:
    rom = {k: (BUILD / f"{GAME}-{k}.{k}").read_bytes() for k in ("p1", "s1", "m1", "v1", "c1", "c2")}
    if not NEO.exists():
        print(f"{NEO} introuvable : lancer build.ps1 -NoRun")
        return 1
    for k in ("c1", "c2"):
        n = len(rom[k])
        if n & (n - 1):
            raise ValueError(f"{k} : {n} octets, pas une puissance de deux (BackBit)")
    if len(rom["p1"]) > 8 << 20 or len(rom["v1"]) > 16 << 20:
        raise ValueError("P1 > 8 Mo ou V1 > 16 Mo : hors du format Darksoft simple")

    out = BUILD / "carts"
    for sub in ("neosd_mister",):
        d = out / sub
        d.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(NEO, d / NEO.name)
        print(f"{d / NEO.name}")

    export_backbit(rom, out)

    d = out / "darksoft" / GAME
    d.mkdir(parents=True, exist_ok=True)
    crom0 = interleave_words(rom["c1"], rom["c2"])
    assert crom0[0::4] == rom["c1"][0::2] and crom0[3::4] == rom["c2"][1::2]
    files = {"prom": rom["p1"], "crom0": crom0, "srom": rom["s1"], "m1rom": rom["m1"],
             "vroma0": rom["v1"], "fpga": FPGA_STANDARD}
    for name, data in files.items():
        (d / name).write_bytes(data)
        print(f"  {name:7s} {len(data):>10d} octets")
    print(f"{d}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
