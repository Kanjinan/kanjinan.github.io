"""Logo du titre (scroll3, palette $1E) reduit a la largeur du Neo Geo.

L'ecran CPS1 fait 384 px, le logo "U.N. SQUADRON" ~368 : il est recompose
a partir des elements 32x32 de scroll3 (grille LOGO_GRID, relevee dans la
VRAM de l'arcade, rangees 56-58, colonnes 0-11), reduit horizontalement a
LOGO_WIDTH px (hauteur conservee) en RGB, puis ramene aux couleurs de sa
palette (LOGO_PAL, relevee a l'ecran titre).

logo_pixels() -> (96, 16 * LOGO_COLS) indices CPS1 (15 : transparent).
python tools/logo.py <png> : apercu agrandi.
"""
from __future__ import annotations

import numpy as np

import cps1

# codes scroll3 (0xC00 : vide), rangees 56-58 x colonnes 0-11 ; la rangee 56
# n'est visible que sur ses 16 dernieres lignes (Y = $700 : tuile 56 a y = -16)
LOGO_GRID = [
    [0xDA3, 0xDA7, 0xDDA, 0xDDB] + [0xC00] * 8,
    [0xDA8, 0xDA9, 0xDAA, 0xDAB, 0xDB0, 0xDB1, 0xDB2, 0xDB3, 0xDB8, 0xDB9, 0xDBA, 0xDBB],
    [0xDAC, 0xDAD, 0xDAE, 0xDAF, 0xDB4, 0xDB5, 0xDB6, 0xDB7, 0xDBC, 0xDBD, 0xDBE, 0xDBF],
]
LOGO_PAL = 0x1E
# palette $1E de scroll3 a l'ecran titre (format CPS1)
LOGO_PAL_WORDS = [0xF111, 0xFC00, 0xFA00, 0xF06C, 0xF05A, 0xF008, 0xFDDE, 0xFBBC,
                  0xF88A, 0xFF76, 0xF800, 0xF666, 0xFD54, 0xFF89, 0xF000, 0xF000]
LOGO_COLS = 20          # sprites Neo Geo de 16 px
LOGO_WIDTH = 288        # largeur du contenu reduit (marges de 16 px : CRT)
LOGO_TOP = 16           # lignes de la rangee 56 cachees (y = -16)


def compose(gfx: bytes) -> np.ndarray:
    t32 = cps1.decode_32x32(gfx)
    img = np.full((96, 384), 15, dtype=np.uint8)
    for r, row in enumerate(LOGO_GRID):
        for c, code in enumerate(row):
            img[r * 32:(r + 1) * 32, c * 32:(c + 1) * 32] = t32[code]
    return img


def logo_pixels(gfx: bytes, pal_words: list[int] = LOGO_PAL_WORDS) -> np.ndarray:
    from PIL import Image
    src = compose(gfx)
    cols = [x for x in range(384) if (src[:, x] != 15).any()]
    x0, x1 = cols[0], cols[-1] + 1
    src = src[:, x0:x1]
    rgb = np.array([cps1.cps_rgb(w) for w in pal_words], dtype=np.float64)
    h, w = src.shape
    # RGBA premultiplie, reduction a LOGO_WIDTH (filtre de surface)
    a = (src != 15).astype(np.float64)
    planes = [rgb[src][:, :, k] * a for k in range(3)] + [a]
    out = []
    for p in planes:
        im = Image.fromarray(p.astype(np.float32), mode="F")
        out.append(np.asarray(im.resize((LOGO_WIDTH, h), Image.BOX), dtype=np.float64))
    alpha = out[3]
    res = np.full((h, LOGO_COLS * 16), 15, dtype=np.uint8)
    xoff = (LOGO_COLS * 16 - LOGO_WIDTH) // 2
    opaque = alpha >= 0.5
    col = np.stack(out[:3], axis=-1) / np.maximum(alpha, 1e-6)[:, :, None]
    used = sorted(set(int(v) for v in np.unique(src)) - {15})
    pr = rgb[used]
    d = ((col[:, :, None, :] - pr[None, None, :, :]) ** 2).sum(axis=-1)
    idx = np.array(used, dtype=np.uint8)[d.argmin(axis=-1)]
    res[:, xoff:xoff + LOGO_WIDTH] = np.where(opaque, idx, 15)
    return res


def palette_from_dump(path: str) -> list[int]:
    d = open(path, "rb").read()
    base = 0x14000 + 0xC00 + LOGO_PAL * 32
    return [(d[base + 2 * i] << 8) | d[base + 2 * i + 1] for i in range(16)]


if __name__ == "__main__":
    import sys
    from PIL import Image
    pal = palette_from_dump(sys.argv[2]) if len(sys.argv) > 2 else LOGO_PAL_WORDS
    print("palette :", " ".join(f"{w:04x}" for w in pal))
    gfx = cps1.load_gfx()
    big = compose(gfx)
    small = logo_pixels(gfx, pal)
    rgb = [cps1.cps_rgb(w) for w in pal]

    def show(px):
        o = np.zeros(px.shape + (3,), dtype=np.uint8)
        for i in range(15):
            o[px == i] = rgb[i]
        return o
    canvas = np.zeros((96 * 2 + 8, 384, 3), dtype=np.uint8)
    canvas[:96] = show(big)
    canvas[104:, :320] = show(small)
    canvas[104:, 320] = 255
    Image.fromarray(canvas).resize((384 * 3, (96 * 2 + 8) * 3), Image.NEAREST).save(sys.argv[1])
