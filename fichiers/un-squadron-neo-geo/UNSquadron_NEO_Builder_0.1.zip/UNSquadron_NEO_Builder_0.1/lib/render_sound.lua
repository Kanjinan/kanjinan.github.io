-- Enregistrement d'une commande son du jeu CPS1 original (mame unsquad).
--   SND_CMD    : commande (decimal), envoyee au latch son ($800181, second
--                latch $800189 a 0)
--   SND_FRAMES : duree d'enregistrement apres la commande (trames)
-- Le 68000 est fige a la trame 110 (bra sur lui-meme en $2B8A2,
-- interruptions masquees : il n'envoie plus rien), la commande part a la
-- trame 120, puis $FF a la trame suivante comme le fait le jeu ($5CC).
-- MAME doit etre lance avec -wavwrite : tools/render_sounds.py coupe le
-- debut du fichier.
local cpu = manager.machine.devices[":maincpu"]
local sp = cpu.spaces["program"]
local cmd = tonumber(os.getenv("SND_CMD"))
local dur = tonumber(os.getenv("SND_FRAMES") or "600")
frames = 0
emu.register_frame_done(function()
  frames = frames + 1
  if frames >= 110 and frames <= 120 then
    cpu.state["SR"].value = 0x2700
    cpu.state["PC"].value = 0x2b8a2
  end
  if frames == 120 then
    sp:write_u8(0x800189, 0)
    sp:write_u8(0x800181, cmd)
  end
  if frames == 121 then sp:write_u8(0x800181, 0xff) end
  if frames >= 120 + dur then manager.machine:exit() end
end)
