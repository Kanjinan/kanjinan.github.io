"""Outils communs au générateur (make_builder.py) et au constructeur (builder.py).

- P ROM : source = programme original + tables recalculées (build_gfx.py),
  patch = suites d'octets où la P ROM finale diffère de cette source.
- V ROM : plan figé (position et durée de chaque son), rejoué à partir
  d'enregistrements MAME du jeu original.
"""

from __future__ import annotations

import hashlib
import os
import struct
import subprocess
import sys
import wave
import zlib

import numpy as np

P_SIZE = 0x200000
PATCH_MAGIC = b"UNSQNEP1"


def sha1(data: bytes) -> str:
    return hashlib.sha1(data).hexdigest()


# ---------------------------------------------------------------------------
# P ROM

def make_source(prg: bytes, tables: dict[str, bytes], layout: dict[str, int]) -> bytes:
    """Source du patch, au format MAME (mots inversés) comme la P ROM."""
    s = bytearray(b"\xff" * P_SIZE)     # comme tools/build_prom.py
    s[:len(prg)] = prg
    for name, off in layout.items():
        t = tables[name]
        s[off:off + len(t)] = t
    s[0::2], s[1::2] = s[1::2], s[0::2]
    return bytes(s)


def render_recipe(prg: bytes, parts: list) -> bytes:
    """Copie de texte : [debut, fin] -> octets du programme, chaine -> hex."""
    out = bytearray()
    for p in parts:
        out += prg[p[0]:p[1]] if isinstance(p, list) else bytes.fromhex(p)
    return bytes(out)


def make_patch(source: bytes, target: bytes, gap: int = 16) -> bytes:
    """Suites (offset, longueur, octets) où target diffère de source."""
    assert len(source) == len(target)
    a = np.frombuffer(source, dtype=np.uint8)
    b = np.frombuffer(target, dtype=np.uint8)
    diff = np.nonzero(a != b)[0]
    runs = []
    if len(diff):
        start = prev = int(diff[0])
        for i in diff[1:]:
            i = int(i)
            if i - prev > gap:
                runs.append((start, prev + 1))
                start = i
            prev = i
        runs.append((start, prev + 1))
    out = bytearray(PATCH_MAGIC + struct.pack("<II", len(target), len(runs)))
    for s, e in runs:
        out += struct.pack("<II", s, e - s) + target[s:e]
    out += bytes.fromhex(sha1(target))
    return zlib.compress(bytes(out), 9)


def apply_patch(source: bytes, patch: bytes) -> bytes:
    raw = zlib.decompress(patch)
    if raw[:8] != PATCH_MAGIC:
        raise SystemExit("patch P1 invalide")
    size, n = struct.unpack_from("<II", raw, 8)
    if size != len(source):
        raise SystemExit("patch P1 : taille inattendue")
    out = bytearray(source)
    pos = 16
    for _ in range(n):
        off, ln = struct.unpack_from("<II", raw, pos)
        pos += 8
        out[off:off + ln] = raw[pos:pos + ln]
        pos += ln
    if sha1(bytes(out)) != raw[pos:pos + 20].hex():
        raise SystemExit("P1 reconstruite différente de l'originale (romset incorrecte ?)")
    return bytes(out)


def patch_payload(patch: bytes) -> list[bytes]:
    """Octets transportés par le patch (contrôle du générateur)."""
    raw = zlib.decompress(patch)
    _, n = struct.unpack_from("<II", raw, 8)
    pos, out = 16, []
    for _ in range(n):
        _, ln = struct.unpack_from("<II", raw, pos)
        out.append(raw[pos + 8:pos + 8 + ln])
        pos += 8 + ln
    return out


# ---------------------------------------------------------------------------
# Son

CPS_FPS = 59.637405
CMD_FRAME = 120
REC_RATE = 48000


def resample(x: np.ndarray, src: int, dst: int) -> np.ndarray:
    """Identique à tools/build_sound.py (FFT)."""
    n = int(round(len(x) * dst / src))
    if n <= 0:
        return np.zeros(0)
    spec = np.fft.rfft(x)
    keep = n // 2 + 1
    out = np.fft.irfft(spec[:keep] if keep <= len(spec) else np.pad(spec, (0, keep - len(spec))), n)
    return out * (n / len(x))


def write_wav(path: str, x: np.ndarray, rate: int) -> None:
    pcm = np.clip(np.round(x), -32768, 32767).astype(np.int16)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(rate)
        w.writeframes(pcm.tobytes())


def load_mono(path: str, cut: bool) -> tuple[np.ndarray, int]:
    """WAV -> mono float. cut : enregistrement MAME brut, on retire le début
    jusqu'à la commande (comme tools/render_sounds.py)."""
    with wave.open(path) as w:
        rate, n, ch = w.getframerate(), w.getnframes(), w.getnchannels()
        d = np.frombuffer(w.readframes(n), dtype=np.int16).reshape(-1, ch)
    if cut:
        d = d[int(CMD_FRAME / CPS_FPS * rate):]
    return d.mean(axis=1).astype(np.float64), rate


def encode_adpcm(adpcmtool: str, wav: str, kind: str) -> bytes:
    out = wav[:-4] + ".adpcm" + kind
    subprocess.run([sys.executable, adpcmtool, "-" + kind, "-e", wav, "-o", out], check=True,
                   stdout=subprocess.DEVNULL)
    data = open(out, "rb").read()
    return data + bytes((-len(data)) % 256)


def build_vrom(plan: dict, sources: dict[str, np.ndarray], workdir: str, adpcmtool: str,
               progress=print, workers: int = 1) -> bytes:
    """Assemble la V ROM selon le plan. sources : nom de l'enregistrement
    ("cmd_XX" / "long_XX") -> signal mono à REC_RATE."""
    from concurrent.futures import ThreadPoolExecutor, as_completed
    vrom = bytearray(plan["size"])
    segs = plan["segments"]

    def one(s):
        x = sources[s["src"]]
        seg = x[s["a"]:s["b"]]
        if len(seg) != s["b"] - s["a"]:
            raise SystemExit(f"enregistrement {s['src']} trop court / recording too short")
        wav = os.path.join(workdir, f"{s['name']}.wav")
        write_wav(wav, resample(seg, REC_RATE, s["rate"]), s["rate"])
        data = encode_adpcm(adpcmtool, wav, s["kind"])
        if len(data) != s["size"]:
            raise SystemExit(f"{s['name']} : {len(data)} octets au lieu de {s['size']}")
        return s, data

    with ThreadPoolExecutor(max_workers=workers) as ex:
        futs = [ex.submit(one, s) for s in segs]
        for i, f in enumerate(as_completed(futs), 1):
            s, data = f.result()
            vrom[s["start"]:s["start"] + len(data)] = data
            progress(f"  [{i:3d}/{len(segs)}] {s['name']}")
    return bytes(vrom)
