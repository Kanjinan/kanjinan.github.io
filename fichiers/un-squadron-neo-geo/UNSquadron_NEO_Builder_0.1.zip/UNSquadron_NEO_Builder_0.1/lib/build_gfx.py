"""ROMs graphiques Neo Geo (C1/C2, S1) et table de conversion des couleurs.

C ROM (tuiles 16x16) :
- tuiles 0-0x3FFF : element 16x16 n de la region graphique CPS1 (mapper
  AR24B, banque unique : code sprite c -> element c pour c < 0x1800, code
  scroll2 c -> element c pour 0x2000 <= c < 0x3000) ;
- tuiles S3_BASE + 4 (c - 0xC00) + 2 h + v : element 32x32 du code scroll3
  c (0xC00-0xFFF), moitie h (0 gauche, 1 droite), rangee v (0 haut, 1 bas) ;
- tuile BLANK_TILE : vide (codes hors plage du mapper) ;
- tuiles LOGO_BASE + 6 c + r : logo du titre reduit a 320 px (tools/logo.py),
  colonne de 16 px c (0-19), rangee de 16 lignes r (0-5) ;
- tuiles HI_BASE + $1000 m + e : element scroll2 $2000 + e reduit aux
  couleurs du masque de priorite HI_MASKS[m] : couche haute de scroll2,
  devant les sprites (rt.c, hi_update). Les masques ($80016A-$80016E,
  groupes 1-3) changent selon la mission (tools/mame/cps_prio.lua, missions
  1-10) ; $0000 (rien) et $7FFF / $FFFF (tuile entiere) n'ont pas de
  variante. Numeros de tuile au-dela de $FFFF : bits 4-7 de l'attribut SCB1.
Couleur CPS1 c -> couleur Neo Geo (c + 1) & 15 : la transparente passe de 15
a 0 ; les palettes sont decalees de la meme facon par le runtime.

S ROM (fix layer) : demi-tuiles 8x8 des codes scroll1 0x3000-0x3FFF
dedoublonnees (tuile 0 vide) ; s1_tab.bin : 8192 mots, tuile fix de la
moitie m (parite de la colonne) du code c a l'index 2 (c - 0x3000) + m.

pal_lut.bin : 65536 mots, couleur CPS1 (luminosite + RGB 4 bits) -> couleur
Neo Geo (big endian, inclus dans la P ROM).

Usage : python build_gfx.py <dossier build>
"""

from __future__ import annotations

import os
import sys

import numpy as np

import cps1
import logo

GAME = "unsquadneo"
CROM_SIZE = 0x800000          # par puce
S3_BASE = 0x4000
S3_FIRST, S3_COUNT = 0xC00, 0x400
BLANK_TILE = S3_BASE + 4 * S3_COUNT   # 0x5000
S1_FIRST, S1_COUNT = 0x3000, 0x1000
LOGO_BASE = BLANK_TILE + 1
HI_BASE = LOGO_BASE + 6 * 20
# masques de priorite releves sur l'arcade (missions 1-10), hors rien / tout
HI_MASKS = (0x007E, 0x7FC0, 0x3F00, 0x7E01, 0x01FE, 0x00FE, 0x7F00, 0x7F81,
            0x0001, 0x7EFE, 0x79FE, 0x7807, 0x1FF8)
SROM_SIZE = 0x20000           # 4096 tuiles fix


def encode_tiles(px: np.ndarray) -> tuple[bytes, bytes]:
    """px : (n, 16, 16) couleurs Neo Geo -> (C1, C2).

    Blocs 8x8 dans l'ordre droite-haut, droite-bas, gauche-haut, gauche-bas ;
    par rangee, C1 recoit les plans 0/1 et C2 les plans 2/3, pixel de gauche
    dans le bit 0."""
    n = px.shape[0]
    blocks = [px[:, 0:8, 8:16], px[:, 8:16, 8:16], px[:, 0:8, 0:8], px[:, 8:16, 0:8]]
    b = np.stack(blocks, axis=1)  # (n, 4, 8, 8)
    weights = (1 << np.arange(8, dtype=np.uint16))
    planes = [((((b >> k) & 1).astype(np.uint16)) * weights).sum(axis=-1).astype(np.uint8) for k in range(4)]
    c1 = np.stack([planes[0], planes[1]], axis=-1).reshape(n, 64)
    c2 = np.stack([planes[2], planes[3]], axis=-1).reshape(n, 64)
    return c1.tobytes(), c2.tobytes()


def encode_fix(px: np.ndarray) -> bytes:
    """px : (n, 8, 8) couleurs Neo Geo -> tuiles fix de 32 octets : octets
    $10-$17 colonnes 0-1, $18 2-3, $00 4-5, $08 6-7, une rangee par octet,
    pixel de gauche dans le quartet bas."""
    n = px.shape[0]
    out = np.zeros((n, 32), dtype=np.uint8)
    for i, base in enumerate((0x10, 0x18, 0x00, 0x08)):
        out[:, base:base + 8] = px[:, :, 2 * i] | (px[:, :, 2 * i + 1] << 4)
    return out.tobytes()


def neo_color(rgb: tuple[int, int, int]) -> int:
    """RGB 8 bits -> couleur Neo Geo (5 bits par composante, bit sombre a 0)."""
    r, g, b = rgb
    word = ((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4)
    word |= (((r >> 3) & 1) << 14) | (((g >> 3) & 1) << 13) | (((b >> 3) & 1) << 12)
    return word


def build_pal_lut() -> bytes:
    out = bytearray(0x20000)
    for c in range(0x10000):
        w = neo_color(cps1.cps_rgb(c))
        out[c * 2] = w >> 8
        out[c * 2 + 1] = w & 0xFF
    return bytes(out)


NK_PAL0 = 16                          # palettes Neo Geo du logo (avant le jeu)


def build_nk_logo(build: str, nk_tile: int) -> np.ndarray:
    """logo_NK.png (racine du projet) -> tuiles Neo Geo deja converties
    (colonne par colonne) et build/logo_nk.h (palettes, position, taille) ;
    affiche apres START GAME (src/rt/menu.c, nk_logo, comme Ghouls'n Ghosts
    NEO). L'image est placee en haut a gauche d'un canevas de tuiles 16x16 ;
    le reste est transparent. Chaque tuile a sa palette (couleur 0 :
    transparente, 1-15 : quantification mediane de la tuile)."""
    from PIL import Image

    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    im = Image.open(os.path.join(root, "logo_NK.png")).convert("RGBA")
    w, h = im.size
    cols, rows = (w + 15) // 16, (h + 15) // 16
    tiles = np.zeros((cols * rows, 16, 16), dtype=np.uint8)
    pals = []
    for c in range(cols):
        for r in range(rows):
            box = im.crop((16 * c, 16 * r, 16 * c + 16, 16 * r + 16))   # hors image : (0,0,0,0)
            a = np.asarray(box)
            opaque = a[:, :, 3] >= 128
            rgb = Image.fromarray(np.ascontiguousarray(a[:, :, :3]))
            q = rgb.quantize(colors=15, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
            idx = np.asarray(q).astype(np.uint8)
            qp = q.getpalette()
            pal = [0x8000] * 16
            for i in range(15):
                pal[i + 1] = neo_color(tuple(qp[3 * i:3 * i + 3])) if qp and 3 * i + 2 < len(qp) else 0x8000
            tiles[c * rows + r] = np.where(opaque, idx + 1, 0)
            pals.append(pal)
    with open(os.path.join(build, "logo_nk.h"), "w", newline="\n") as f:
        f.write("/* Genere par tools/build_gfx.py (logo_NK.png) : ne pas modifier */\n")
        f.write("#define NK_TILE 0x%XUL\n#define NK_PAL0 %d\n#define NK_COLS %d\n#define NK_ROWS %d\n"
                "#define NK_W %d\n#define NK_H %d\n#define NK_BLANK_TILE 0x%X\n"
                % (nk_tile, NK_PAL0, cols, rows, w, h, BLANK_TILE))
        f.write("static const u16 nk_pal[NK_COLS * NK_ROWS][16] = {\n")
        for p in pals:
            f.write("    {" + ", ".join("0x%04x" % x for x in p) + "},\n")
        f.write("};\n")
    assert NK_PAL0 + len(pals) <= 255
    return tiles


# Lettres accentuees du francais (option LANGUE, tools/text_unsq.py) dans des
# codes scroll1 dont le glyphe est vide et que le jeu n'affiche pas : code ->
# (lettre de base, accent). Les minuscules occupent les rangees 3-7 : accent
# en rangees 1-2 (2 : trait, 1 : ombre, comme la police) ; cedille : lettre
# remontee d'une rangee, crochet en rangee 7.
ACCENT_CODES = {0x5B: ("e", "aigu"), 0x5C: ("e", "grave"), 0x5D: ("e", "circ"),
                0x7F: ("a", "grave"), 0x10: ("a", "circ"), 0x18: ("c", "cedille")}
ACCENT_MARKS = {
    "aigu": ["....21..", "...21..."],
    "grave": ["..21....", "...21..."],
    "circ": ["...21...", "..21.21."],
}


def add_accents(t8: np.ndarray) -> None:
    """t8 : (n, 2, 8, 8) indices CPS1 (15 : transparent), code - 0x3000."""
    for code, (base, mark) in ACCENT_CODES.items():
        assert (t8[code] == 15).all(), f"code {code:#x} deja utilise"
        g = t8[ord(base)].copy()
        if mark == "cedille":
            g[:, 0:7] = g[:, 1:8]
            g[:, 7] = 15
            for x, ch in enumerate("...21..."):
                if ch != ".":
                    g[:, 7, x] = int(ch)
        else:
            for r, row in enumerate(ACCENT_MARKS[mark]):
                for x, ch in enumerate(row):
                    if ch != ".":
                        g[:, 1 + r, x] = int(ch)
        t8[code] = g


def to_neo(px: np.ndarray) -> np.ndarray:
    return ((px.astype(np.int16) + 1) & 15).astype(np.uint8)


def main() -> int:
    build = sys.argv[1]
    gfx = cps1.load_gfx()
    t16 = cps1.decode_16x16(gfx)                       # 0x4000 elements
    assert len(t16) == S3_BASE
    t32 = cps1.decode_32x32(gfx)[S3_FIRST:S3_FIRST + S3_COUNT]
    q = t32.reshape(S3_COUNT, 2, 16, 2, 16).transpose(0, 3, 1, 2, 4).reshape(-1, 16, 16)
    blank = np.full((1, 16, 16), 15, dtype=t16.dtype)
    lp = logo.logo_pixels(gfx)                         # (96, 320)
    lt = lp.reshape(6, 16, logo.LOGO_COLS, 16).transpose(2, 0, 1, 3).reshape(-1, 16, 16)
    assert LOGO_BASE + 6 * logo.LOGO_COLS == HI_BASE
    s2 = t16[0x2000:0x3000]
    hi = []
    for mask in HI_MASKS:
        keep = np.array([(mask >> p) & 1 for p in range(16)], dtype=bool)
        hi.append(np.where(keep[s2], s2, 15).astype(t16.dtype))

    # fix : demi-tuiles dedoublonnees, tuile 0 vide
    t8 = cps1.decode_8x8(gfx)[S1_FIRST:S1_FIRST + S1_COUNT].copy()   # (n, 2, 8, 8)
    add_accents(t8)
    halves = to_neo(t8.reshape(-1, 8, 8))
    known: dict[bytes, int] = {}
    fix = [np.zeros((8, 8), dtype=np.uint8)]
    known[fix[0].tobytes()] = 0
    tab = np.zeros(len(halves), dtype=">u2")
    for i, h in enumerate(halves):
        k = h.tobytes()
        if k not in known:
            known[k] = len(fix)
            fix.append(h)
        tab[i] = known[k]

    tiles = to_neo(np.concatenate([t16, q, blank, lt.astype(t16.dtype)] + hi))
    assert len(tiles) == HI_BASE + 0x1000 * len(HI_MASKS)
    # tuiles SFIX_BASE + f : tuile fix f (couleurs Neo Geo) en haut a gauche
    # d'une tuile 16x16 transparente (texte de scroll1 en sprites : histoire
    # de l'attract, qui defile au pixel, rt.c story_*)
    sfix = np.zeros((len(fix), 16, 16), dtype=np.uint8)
    sfix[:, 0:8, 0:8] = np.stack(fix)
    tiles = np.concatenate([tiles, sfix])
    sfix_base = HI_BASE + 0x1000 * len(HI_MASKS)
    # logo NK (couleurs Neo Geo deja converties : pas de to_neo)
    nk = build_nk_logo(build, len(tiles))
    tiles = np.concatenate([tiles, nk])
    c1, c2 = encode_tiles(tiles)
    if len(c1) > CROM_SIZE:
        raise SystemExit("C ROM trop petite")
    c1 += b"\0" * (CROM_SIZE - len(c1))
    c2 += b"\0" * (CROM_SIZE - len(c2))
    open(os.path.join(build, f"{GAME}-c1.c1"), "wb").write(c1)
    open(os.path.join(build, f"{GAME}-c2.c2"), "wb").write(c2)
    open(os.path.join(build, "pal_lut.bin"), "wb").write(build_pal_lut())

    if len(fix) > SROM_SIZE // 32:
        raise SystemExit(f"S ROM : {len(fix)} tuiles, trop pour {SROM_SIZE // 32}")
    srom = encode_fix(np.stack(fix))
    srom += b"\0" * (SROM_SIZE - len(srom))
    open(os.path.join(build, f"{GAME}-s1.s1"), "wb").write(srom)
    open(os.path.join(build, "s1_tab.bin"), "wb").write(tab.tobytes())
    with open(os.path.join(build, "gfx.h"), "w", newline="\n") as f:
        f.write("/* Genere par tools/build_gfx.py : ne pas modifier */\n")
        f.write(f"#define S3_BASE 0x{S3_BASE:X}\n#define BLANK_TILE 0x{BLANK_TILE:X}\n")
        f.write(f"#define FIX_TILES {len(fix)}\n")
        f.write(f"#define LOGO_BASE 0x{LOGO_BASE:X}\n#define LOGO_COLS {logo.LOGO_COLS}\n")
        f.write(f"#define HI_BASE 0x{HI_BASE:X}\n")
        f.write(f"#define SFIX_BASE 0x{sfix_base:X}UL\n")
        f.write("#define HI_NMASKS %d\n#define HI_MASKS_INIT {%s}\n"
                % (len(HI_MASKS), ", ".join(f"0x{m:04X}" for m in HI_MASKS)))
    print(f"  C ROM : {len(tiles)} tuiles ; S ROM : {len(fix)} tuiles fix")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
