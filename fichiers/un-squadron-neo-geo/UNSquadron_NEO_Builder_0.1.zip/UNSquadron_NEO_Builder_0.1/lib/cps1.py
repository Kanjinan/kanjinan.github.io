"""Chargement des ROMs CPS1 de U.N. Squadron et decodage des graphismes.

Les regions sont reconstruites comme dans MAME (driver cps1, jeu "unsquad") ;
l'entrelacement des puces a ete verifie octet par octet contre un dump des
regions fait par MAME 0.289.

Graphismes (cf. MAME cps1_v.cpp / cps1.cpp) :
- tuile 16x16 = 128 octets : 16 rangees de 8 octets, pixels 0-7 dans les
  octets 0-3, pixels 8-15 dans les octets 4-7 ; dans chaque groupe de 4
  octets, l'octet k porte le plan k (bit 7 = pixel de gauche) ;
- tuile 8x8 = 64 octets : 8 rangees de 8 octets, moitie gauche (octets 0-3)
  pour les colonnes paires du tilemap, moitie droite (4-7) pour les impaires ;
- tuile 32x32 = 512 octets : 32 rangees de 16 octets (4 groupes de 8 px).
Couleur 15 = transparente.

Gfx bank mapper AR24B (unites de 64 octets, banque unique de 2 Mo) :
sprites 0x0000-0x2FFF, scroll1 0x3000-0x3FFF, scroll2 0x4000-0x5FFF,
scroll3 0x6000-0x7FFF ; hors plage : rien n'est dessine.
"""

from __future__ import annotations

import os

import numpy as np

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ROM_DIR = os.path.join(ROOT, "original", "unsquad")

PRG_SIZE = 0x100000
GFX_SIZE = 0x200000

# (fichier, offset, pas, largeur) : octets "largeur" tous les "pas" octets
# (largeur negative : octets de chaque mot inverses, ROM_LOAD16_WORD_SWAP)
PRG_ROMS = [
    ("aru_30.11f", 0x00000, 2, 1), ("aru_35.11h", 0x00001, 2, 1),
    ("aru_31.12f", 0x40000, 2, 1), ("aru_36.12h", 0x40001, 2, 1),
    ("ar-32m.8h", 0x80000, 2, -2),  # ROM_LOAD16_WORD_SWAP
]
GFX_ROMS = [
    ("ar-5m.7a", 0x000000, 8, 2), ("ar-7m.9a", 0x000002, 8, 2),
    ("ar-1m.3a", 0x000004, 8, 2), ("ar-3m.5a", 0x000006, 8, 2),
]
AUDIO_ROM = "ar_09.12b"
OKI_ROM = "aru_18.11c"


def _load(roms, size: int) -> bytes:
    out = np.zeros(size, dtype=np.uint8)
    for name, offset, step, width in roms:
        data = np.frombuffer(open(os.path.join(ROM_DIR, name), "rb").read(), dtype=np.uint8)
        swap = width < 0
        width = abs(width)
        n = len(data) // width
        for k in range(width):
            src = (width - 1 - k) if swap else k
            out[offset + k: offset + k + n * step: step] = data[src::width]
    return out.tobytes()


def load_program() -> bytes:
    return _load(PRG_ROMS, PRG_SIZE)


def load_gfx() -> bytes:
    return _load(GFX_ROMS, GFX_SIZE)


def load_audio() -> bytes:
    """Region audiocpu de MAME (0x18000) : 0x0000-0x7FFF puis banque en 0x10000."""
    d = open(os.path.join(ROM_DIR, AUDIO_ROM), "rb").read()
    return d[:0x8000] + bytes(0x8000) + d[0x8000:]


def load_oki() -> bytes:
    return open(os.path.join(ROM_DIR, OKI_ROM), "rb").read() + bytes(0x20000)


# ---------------------------------------------------------------------------
# Decodage en tableaux numpy d'indices de couleur 0-15 (couleur CPS1)

def _rows_to_pixels(rows: np.ndarray) -> np.ndarray:
    """rows : (..., 4) octets d'un groupe de 8 pixels (octet k = plan k)
    -> (..., 8) indices de couleur."""
    bits = np.unpackbits(rows[..., :, None], axis=-1)  # (..., 4, 8), bit 7 en premier
    weights = np.array([1, 2, 4, 8], dtype=np.uint8)[:, None]
    return (bits * weights).sum(axis=-2).astype(np.uint8)


def decode_16x16(gfx: bytes) -> np.ndarray:
    """-> (n, 16, 16) pour toutes les tuiles 16x16 de la region."""
    g = np.frombuffer(gfx, dtype=np.uint8).reshape(-1, 16, 2, 4)  # tuile, rangee, moitie, plan
    px = _rows_to_pixels(g)  # (n, 16, 2, 8)
    return px.reshape(-1, 16, 16)


def decode_8x8(gfx: bytes) -> np.ndarray:
    """-> (n, 2, 8, 8) : tuile 8x8 de 64 octets, moitie gauche [0] et droite [1]."""
    g = np.frombuffer(gfx, dtype=np.uint8).reshape(-1, 8, 2, 4)
    px = _rows_to_pixels(g)  # (n, 8, 2, 8)
    return px.transpose(0, 2, 1, 3)


def decode_32x32(gfx: bytes) -> np.ndarray:
    """-> (n, 32, 32)."""
    g = np.frombuffer(gfx, dtype=np.uint8).reshape(-1, 32, 4, 4)
    px = _rows_to_pixels(g)  # (n, 32, 4, 8)
    return px.reshape(-1, 32, 32)


# ---------------------------------------------------------------------------
# Gfx bank mapper AR24B : code -> numero d'element dans la region
# (-1 : hors plage, le CPS-B ne dessine rien)

def _ar24b(u: int, lo: int, hi: int) -> int:
    return u if lo <= u <= hi else -1


def map_sprite(code: int) -> int:
    u = _ar24b((code << 1) & 0x1FFFF, 0x0000, 0x2FFF)
    return -1 if u < 0 else u >> 1


def map_scroll1(code: int) -> int:
    return _ar24b(code & 0xFFFF, 0x3000, 0x3FFF)


def map_scroll2(code: int) -> int:
    u = _ar24b((code << 1) & 0x1FFFF, 0x4000, 0x5FFF)
    return -1 if u < 0 else u >> 1


def map_scroll3(code: int) -> int:
    u = _ar24b((code << 3) & 0x7FFFF, 0x6000, 0x7FFF)
    return -1 if u < 0 else u >> 3


# ---------------------------------------------------------------------------
# Palette : 4 bits de luminosite + RGB 4 bits (MAME cps1_build_palette)

def cps_rgb(color: int) -> tuple[int, int, int]:
    bright = 0x0F + ((color >> 12) << 1)
    return tuple(((color >> s) & 0x0F) * 0x11 * bright // 0x2D for s in (8, 4, 0))


if __name__ == "__main__":
    import sys
    # python cps1.py --program <sortie> : programme 68000 reconstitue
    # python cps1.py <maincpu.bin> <gfx.bin> : verification contre un dump MAME
    if len(sys.argv) == 3 and sys.argv[1] == "--program":
        open(sys.argv[2], "wb").write(load_program())
        sys.exit(0)
    prg, gfx = load_program(), load_gfx()
    if len(sys.argv) == 3:
        print("programme", "OK" if open(sys.argv[1], "rb").read()[:PRG_SIZE] == prg else "DIFFERENT")
        print("graphismes", "OK" if open(sys.argv[2], "rb").read() == gfx else "DIFFERENT")
