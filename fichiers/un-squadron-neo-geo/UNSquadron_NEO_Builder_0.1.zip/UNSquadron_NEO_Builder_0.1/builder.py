"""U.N. Squadron NEO - constructeur de ROM / ROM builder

Construit le portage Neo Geo à partir de VOTRE romset MAME unsquad.zip.
Builds the Neo Geo port from YOUR OWN MAME romset unsquad.zip.

Aucune donnée du jeu original n'est fournie avec cet outil.
No data from the original game is included with this tool.

Usage :
  python builder.py [--romset unsquad.zip] [--mame C:\\MAME\\mame.exe] [--out output]
"""

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
import zipfile
import zlib
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LIB = ROOT / "lib"
DATA = ROOT / "data"
sys.path.insert(0, str(LIB))

try:
    import numpy as np
except ImportError:
    sys.exit("numpy manquant / numpy missing :  python -m pip install numpy")

import unsqlib as gnglib  # noqa: E402

GAME = "unsquadneo"
CPS_SET = "unsquad"


def say(fr: str, en: str = "") -> None:
    print(fr if not en else f"{fr}  /  {en}", flush=True)


def ask_path(fr: str, en: str) -> Path:
    p = input(f"{fr} / {en}\n> ").strip().strip('"')
    return Path(p)


def find_mame(arg: str | None) -> Path:
    cands = [arg, os.environ.get("MAME_PATH") and os.path.join(os.environ["MAME_PATH"], "mame.exe"),
             r"C:\MAME\mame.exe", shutil.which("mame"), shutil.which("mame64")]
    for c in cands:
        if c and Path(c).is_file():
            return Path(c)
    p = ask_path("Chemin de mame.exe ?", "Path to mame.exe?")
    if not p.is_file():
        sys.exit("MAME introuvable / MAME not found")
    return p


def find_romset(arg: str | None) -> Path:
    for c in (arg, ROOT / "unsquad.zip", ROOT.parent / "unsquad.zip"):
        if c and Path(c).is_file():
            return Path(c)
    p = ask_path("Chemin de votre romset unsquad.zip ?", "Path to your unsquad.zip romset?")
    if not p.is_file():
        sys.exit("unsquad.zip introuvable / not found")
    return p


def check_romset(zpath: Path, manifest: dict, dest: Path) -> None:
    """Vérifie les CRC32 et extrait les fichiers nécessaires."""
    dest.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zpath) as z:
        names = {Path(i.filename).name.lower(): i for i in z.infolist()}
        bad = []
        for name, crc in manifest["romset"].items():
            i = names.get(name.lower())
            if i is None or f"{i.CRC:08x}" != crc:
                bad.append(name)
                continue
            data = z.read(i)
            if f"{zlib.crc32(data):08x}" != crc:
                bad.append(name)
            (dest / name).write_bytes(data)
    if bad:
        sys.exit("Romset incorrecte (fichiers absents ou différents) / wrong romset (missing or bad files):\n  "
                 + ", ".join(bad) + "\nIl faut la romset MAME 'unsquad' (U.N. Squadron, USA) / "
                 "The MAME 'unsquad' set (U.N. Squadron, USA) is required.")


def record(mame: Path, romdir: Path, src: str, secs: float, wav: Path) -> None:
    cmd = int(src[-2:], 16)
    env = dict(os.environ, SND_CMD=str(cmd), SND_FRAMES=str(int(secs * gnglib.CPS_FPS)))
    subprocess.run([str(mame), CPS_SET, "-noreadconfig", "-rompath", str(romdir),
                    "-video", "none", "-nothrottle", "-skip_gameinfo", "-samplerate", str(gnglib.REC_RATE),
                    "-wavwrite", str(wav), "-autoboot_script", str(LIB / "render_sound.lua")],
                   cwd=str(mame.parent), env=env, check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def write_zip(zpath: Path, base: Path, folder: Path) -> None:
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(folder.rglob("*")):
            if f.is_file():
                z.write(f, f.relative_to(base).as_posix())


def main() -> int:
    ap = argparse.ArgumentParser(description="U.N. Squadron NEO ROM builder")
    ap.add_argument("--romset", help="unsquad.zip (romset MAME)")
    ap.add_argument("--mame", help="mame.exe")
    ap.add_argument("--out", default=str(ROOT / "output"))
    ap.add_argument("--jobs", type=int, default=max(1, min(8, (os.cpu_count() or 2) - 1)))
    args = ap.parse_args()

    manifest = json.loads((DATA / "manifest.json").read_text())
    plan = json.loads((DATA / "sound_plan.json").read_text())
    out = Path(args.out)
    work = out / "_work"
    t0 = time.time()
    say(f"U.N. Squadron NEO - version {manifest['version']}")

    romset = find_romset(args.romset)
    mame = find_mame(args.mame)
    say(f"Romset : {romset}")
    say(f"MAME   : {mame}")

    # ------------------------------------------------------------------
    say("\n[1/6] Vérification de la romset", "checking the romset")
    if work.exists():
        shutil.rmtree(work)
    romdir = work / "roms"
    check_romset(romset, manifest, romdir / CPS_SET)
    shutil.copyfile(romset, romdir / f"{CPS_SET}.zip")
    import cps1
    cps1.ROM_DIR = str(romdir / CPS_SET)
    prg = cps1.load_program()
    if gnglib.sha1(prg) != manifest["prg_sha1"]:
        sys.exit("Programme inattendu / unexpected program ROM")
    (work / "prg.bin").write_bytes(prg)
    say("  OK")

    # ------------------------------------------------------------------
    say("\n[2/6] Conversion des graphismes (C1, C2, S1)", "converting graphics")
    import build_gfx
    logo = np.frombuffer((DATA / "logo_tiles.bin").read_bytes(), dtype=np.uint8).reshape(-1, 16, 16)
    build_gfx.build_nk_logo = lambda build, nk_tile: logo.copy()
    sys.argv = ["build_gfx.py", str(work)]
    build_gfx.main()

    # ------------------------------------------------------------------
    say("\n[3/6] Programme (P1)", "program ROM")
    tables = {n: (work / f).read_bytes()
              for n, f in (("pal_lut", "pal_lut.bin"), ("s1_tab", "s1_tab.bin"))}
    for r in json.loads((DATA / "text_fr.json").read_text()):
        tables[r["name"]] = gnglib.render_recipe(prg, r["parts"])
    layout = {k: int(v) for k, v in manifest["layout"].items()}
    source = gnglib.make_source(prg, tables, layout)
    p1 = gnglib.apply_patch(source, (DATA / "p1.patch").read_bytes())
    (work / f"{GAME}-p1.p1").write_bytes(p1)
    (work / f"{GAME}-m1.m1").write_bytes((DATA / "m1.bin").read_bytes())
    say("  OK")

    # ------------------------------------------------------------------
    srcs = {}
    for s in plan["segments"]:
        srcs[s["src"]] = max(srcs.get(s["src"], 0), s["secs"])
    say(f"\n[4/6] Enregistrement des sons dans MAME ({len(srcs)} enregistrements, quelques minutes)",
        f"recording sounds in MAME ({len(srcs)} recordings, a few minutes)")
    recdir = work / "rec"
    recdir.mkdir()
    done = [0]

    def rec(item):
        src, secs = item
        record(mame, romdir, src, secs, recdir / f"{src}.wav")
        done[0] += 1
        print(f"  [{done[0]:3d}/{len(srcs)}] {src}", flush=True)

    with ThreadPoolExecutor(max_workers=args.jobs) as ex:
        list(ex.map(rec, sorted(srcs.items(), key=lambda kv: -kv[1])))
    class Sources(dict):
        """Enregistrements lus à la demande (170 s chacun : trop gros pour tout garder)."""
        def __missing__(self, src):
            return gnglib.load_mono(str(recdir / f"{src}.wav"), cut=True)[0]

    sources = Sources()

    say("\n[5/6] Encodage ADPCM (V1)", "ADPCM encoding")
    encdir = work / "enc"
    encdir.mkdir()
    v1 = gnglib.build_vrom(plan, sources, str(encdir), str(LIB / "adpcmtool.py"),
                           progress=lambda m: print(m, flush=True), workers=args.jobs)
    (work / f"{GAME}-v1.v1").write_bytes(v1)

    # ------------------------------------------------------------------
    say("\n[6/6] Contrôle et fichiers pour cartouches", "checking and exporting cartridge files")
    ok = True
    for k in ("p1", "c1", "c2", "s1", "m1", "v1"):
        same = gnglib.sha1((work / f"{GAME}-{k}.{k}").read_bytes()) == manifest["sha1"][k]
        if not same and k == "v1":
            say("  V1 : son légèrement différent de la version de référence (version de MAME différente ?) - "
                "jouable quand même", "V1 slightly differs from the reference (different MAME version?) - "
                "still playable")
        elif not same:
            say(f"  {k.upper()} : ERREUR, différente de la version de référence", f"{k.upper()}: ERROR")
            ok = False
        else:
            say(f"  {k.upper()} : identique à la version de référence", "identical to the reference")
    if not ok:
        return 1

    import build_neo
    import export_carts
    neo = work / "UN Squadron.neo"
    build_neo.main_args(str(work), str(neo))
    export_carts.BUILD = work
    export_carts.NEO = neo
    export_carts.main()
    carts = work / "carts"
    write_zip(out / "neosd_mister.zip", carts, carts / "neosd_mister")
    write_zip(out / "darksoft.zip", carts, carts / "darksoft")
    write_zip(out / "backbit.zip", carts / "backbit", carts / "backbit")
    mame_dir = out / "mame" / GAME
    mame_dir.mkdir(parents=True, exist_ok=True)
    for k in ("p1", "s1", "m1", "v1", "c1", "c2"):
        shutil.copyfile(work / f"{GAME}-{k}.{k}", mame_dir / f"{GAME}-{k}.{k}")
    shutil.rmtree(work)

    say(f"\nTerminé en {int(time.time() - t0)} s. Fichiers dans / files in : {out}")
    say("  neosd_mister.zip : NeoSD / MiSTer (.neo)")
    say("  darksoft.zip     : Darksoft")
    say("  backbit.zip      : BackBit Platinum MVS")
    say("  mame/unsquadneo  : MAME (voir LISEZMOI / see README)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
