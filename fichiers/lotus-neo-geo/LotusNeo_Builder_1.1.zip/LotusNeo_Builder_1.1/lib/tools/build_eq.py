"""VU-metre de l'autoradio (ecran SELECT A TRACK) : chronologie des notes des
morceaux CD1-CD6, rejouee par le 68000 en phase avec la musique ADPCM-B.

Dans le jeu, l'ecran (mode 21) detourne le lecteur de musique d1_027 a
l'octet $6B0 (lecture d'une ligne de motif, une fois par voie) : $6AA82 prend
le mot haut de la cellule (instrument haut | periode), barre = 856 / mot - 1
bornee a 0-7, puis $70AE6 ajoute 1, 4, 7, 4, 1 aux barres b-2 a b+2.

Les lignes sont parcourues comme dans tools/build_music.py (render_mod : memes
sauts, boucles, retards et coupure de fin), sans le rendu du son ; la duree
obtenue est comparee au WAV du cache. Sortie : <build>/eq_data.h.

Usage : python tools/build_eq.py <dossier_build>
"""

from __future__ import annotations

import glob
import os
import sys
import wave

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
MODS = os.path.join(ROOT, "extract", "l3", "mod")
RATE = 22050          # rendu de build_music.py
VBL_HZ = 59.1856      # VBlank Neo Geo
SONG_CDS = list(range(17, 23))


def row_events(data: bytes):
    """-> ([(echantillon, [barres])], echantillons au total)"""
    npat = max(data[952:952 + 128]) + 1
    song_len = data[950]
    order = data[952:952 + song_len]
    speed, tempo = 6, 125
    visited = set()
    pos, row = 0, 0
    pat_delay = 0
    loop_row = [0] * 4
    loop_count = [0] * 4
    empty = {p for p in range(npat) if not any(data[1084 + p * 1024:1084 + p * 1024 + 1024])}

    def last_note_row(p: int) -> int:
        last = -1
        for r in range(64):
            for c in range(4):
                b = data[1084 + p * 1024 + r * 16 + c * 4:1084 + p * 1024 + r * 16 + c * 4 + 4]
                if ((b[0] & 15) << 8) | b[1]:
                    last = r
        return last

    t = 0
    ev = []
    while pos < song_len:
        if row == 0 and order[pos] in empty:
            break
        if pos + 1 < song_len and order[pos + 1] in empty and row == ((last_note_row(order[pos]) + 8) & ~7):
            break
        key = (pos, row)
        if key in visited:
            break
        visited.add(key)
        base = 1084 + order[pos] * 1024 + row * 16
        jump = brk = loop_to = None
        bars = []
        for c in range(4):
            b0, b1, b2, b3 = data[base + 4 * c:base + 4 * c + 4]
            hw = (b0 << 8) | b1
            if hw:
                bars.append(max(0, min(7, 856 // hw - 1)))
            fx, prm = b2 & 0x0F, b3
            if fx == 0xF and prm:
                if prm < 32:
                    speed = prm
                else:
                    tempo = prm
            elif fx == 0xB:
                jump = prm
            elif fx == 0xD:
                brk = (prm >> 4) * 10 + (prm & 15)
            elif fx == 0xE:
                sub, v = prm >> 4, prm & 15
                if sub == 6:
                    if v == 0:
                        loop_row[c] = row
                    elif loop_count[c] == 0:
                        loop_count[c] = v
                        loop_to = loop_row[c]
                    else:
                        loop_count[c] -= 1
                        if loop_count[c]:
                            loop_to = loop_row[c]
                elif sub == 0xE:
                    pat_delay = v
        if bars:
            ev.append((t, bars))
        ticks = speed * (1 + pat_delay)
        pat_delay = 0
        t += ticks * int(RATE * 2.5 / tempo)
        if loop_to is not None:
            row = loop_to
            visited = {k for k in visited if k[0] != pos}
            continue
        if jump is not None:
            if jump <= pos and brk is None:
                break
            pos, row = jump, 0
            if brk is not None:
                row = brk
            continue
        if brk is not None:
            pos, row = pos + 1, brk
            continue
        row += 1
        if row >= 64:
            row, pos = 0, pos + 1
    return ev, t


def main() -> int:
    build = sys.argv[1]
    cache = os.path.join(build, "sound")
    lens, times, packed, firsts = [], [], [], []
    for sg in SONG_CDS:
        mod = glob.glob(os.path.join(MODS, f"{sg:02d}_*.mod"))[0]
        name = os.path.basename(mod)[:-4]
        ev, total = row_events(open(mod, "rb").read())
        wav = os.path.join(cache, name + ".wav")
        if os.path.exists(wav):
            with wave.open(wav) as w:
                if w.getnframes() != total:
                    raise SystemExit(f"{name} : {total} echantillons, WAV {w.getnframes()}")
        # boucle du Z80 : donnees ADPCM-B (2 echantillons par octet) bourrees a 256
        enc = os.path.join(cache, name + ".adpcmb")
        loop = (os.path.getsize(enc) + (-os.path.getsize(enc)) % 256) * 2 if os.path.exists(enc) else total
        firsts.append(len(times))
        for smp, bars in ev:
            v = 0xFFFF
            for k, b in enumerate(bars):
                v = (v & ~(0xF << (4 * k))) | (b << (4 * k))
            times.append(round(smp * VBL_HZ / RATE))
            packed.append(v)
        lens.append(round(loop * VBL_HZ / RATE))
        print(f"  {name} : {len(ev)} lignes, {total / RATE:.1f} s")
    firsts.append(len(times))

    def arr(t, n, v):
        rows = [", ".join(str(x) for x in v[i:i + 16]) for i in range(0, len(v), 16)]
        return f"static const {t} {n}[{len(v)}] = {{\n    " + ",\n    ".join(rows) + "\n};"

    h = ["/* Genere par tools/build_eq.py - ne pas modifier */", "#pragma once",
         "/* VU-metre de l'autoradio : par morceau CD1-CD6, lignes de motif portant",
         " * des notes (VBlank depuis le debut, 4 barres de 0-7 par quartet, F = rien) */",
         arr("u16", "eq_loop", lens), arr("u16", "eq_first", firsts),
         arr("u16", "eq_time", times), arr("u16", "eq_bars", packed)]
    open(os.path.join(build, "eq_data.h"), "w", encoding="ascii").write("\n".join(h) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
