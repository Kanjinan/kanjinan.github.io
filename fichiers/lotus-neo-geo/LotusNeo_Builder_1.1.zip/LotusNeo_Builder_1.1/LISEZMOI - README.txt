===========================================================================
 LOTUS NEO 1.1 - constructeur de ROM / ROM builder
 Jeu de course Neo Geo d'apres Lotus III (Amiga) - Neo Geo racing game
===========================================================================

[FR] -----------------------------------------------------------------------

Cet outil construit Lotus Neo a partir de VOS PROPRES disquettes Amiga de
Lotus III: The Ultimate Challenge. Il ne contient AUCUNE donnee du jeu
original (ni graphismes, ni musique, ni circuits, ni code) : seulement mon
travail (le programme Neo Geo, le pilote son et les scripts de conversion).
Tout le reste est reconstruit chez vous a partir des disquettes.

Ce qu'il faut :
  - Windows, et Python 3.9 ou plus (https://www.python.org/downloads/,
    cocher "Add python.exe to PATH" a l'installation). Au premier lancement,
    l'outil installe numpy, Pillow et unicorn (connexion Internet requise) ;
  - les 2 disquettes de Lotus III au format ADF (version TOSEC) :
      Lotus III - The Ultimate Challenge (1992)(Gremlin)(Disk 1 of 2)[cr FLT - Crack Inc].adf
      Lotus III - The Ultimate Challenge (1992)(Gremlin)(Disk 2 of 2)[cr FLT - Crack Inc].adf
    Elles sont reconnues a leur contenu (SHA-1), quel que soit leur nom,
    en .adf ou dans un .zip ;
  - le BIOS Neo Geo de MAME (neogeo.zip), pour la police du BIOS (sfix.sfix).
    S'il est dans C:\MAME\roms, il est trouve tout seul.

Utilisation :
  1. Placez les 2 disquettes (.adf ou .zip) et neogeo.zip dans ce dossier
     (sinon l'outil demandera ou ils sont).
  2. Double-cliquez sur "Construire - Build.bat".
  3. Patientez quelques minutes.

Resultat, dans le dossier "output" :
  - neosd_mister\Lotus Neo.neo : NeoSD et MiSTer (core Neo Geo). Sur MiSTer,
    copiez-le dans games\NeoGeo de la carte SD.
  - darksoft\lotusneo : cartouche Darksoft.
  - backbit\lotusneo  : BackBit Platinum MVS (avec neogeo.xml).
  - mame\lotusneo     : ROMs pour MAME (romset "lotusneo"). MAME doit
    connaitre le jeu : si MAME est dans C:\MAME, l'outil propose de
    l'installer (copie des ROMs et ajout de l'entree "lotusneo" dans
    hash\neogeo.xml, avec une sauvegarde neogeo.xml.bak_lotusneo). Sinon,
    copiez mame\lotusneo dans le dossier roms de MAME et ajoutez l'entree
    de mame\neogeo.xml dans hash\neogeo.xml, avant </softwarelist>.
    Lancez ensuite : mame neogeo lotusneo

Chaque ROM construite est verifiee (empreinte SHA-1). Si votre version de
numpy n'est pas la meme que la mienne, la musique peut differer tres
legerement : c'est signale, et le jeu reste jouable.

Commandes :
  - Croix : diriger. A : accelerer. B : freiner. START : pause.
  - C / D : monter / descendre un rapport (passe en boite manuelle).
  - Menus : A ou START pour valider, B pour revenir.
  - Options du menu principal : boite manuelle ou automatique (GEARS),
    accelerer au bouton A ou en poussant la croix vers le haut (ACCELERATE),
    1 ou 2 joueurs (ecran partage).

Ligne de commande (options) :
  python builder.py --disk1 D1.adf --disk2 D2.adf --bios neogeo.zip
  python builder.py --install-mame C:\MAME      (installer dans MAME)
  python builder.py --no-install                (ne rien proposer)

Mentions : projet de fan non commercial, sans lien avec Gremlin, Magnetic
Fields ni les ayants droit de Lotus III. Lotus III: The Ultimate Challenge
(c) 1992 Magnetic Fields / Gremlin Graphics. Lotus est une marque de son
proprietaire. Les ROMs produites sont pour votre usage personnel : ne les
distribuez pas, ne vendez pas de repros.
adpcmtool.py et le pilote son nullsound : ngdevkit (c) Damien Ciabrini,
licence LGPL-3 (lib\).

[EN] -----------------------------------------------------------------------

This tool builds Lotus Neo from YOUR OWN Amiga disks of Lotus III: The
Ultimate Challenge. It contains NO data from the original game (no graphics,
music, tracks or code): only my own work (the Neo Geo program, the sound
driver and the conversion scripts). Everything else is rebuilt on your
computer from the disks.

You need:
  - Windows, and Python 3.9 or newer (https://www.python.org/downloads/,
    tick "Add python.exe to PATH" during setup). On first run, the tool
    installs numpy, Pillow and unicorn (Internet connection required);
  - the 2 Lotus III disks as ADF files (TOSEC version):
      Lotus III - The Ultimate Challenge (1992)(Gremlin)(Disk 1 of 2)[cr FLT - Crack Inc].adf
      Lotus III - The Ultimate Challenge (1992)(Gremlin)(Disk 2 of 2)[cr FLT - Crack Inc].adf
    They are recognised by their content (SHA-1), whatever their name,
    as .adf or inside a .zip;
  - the MAME Neo Geo BIOS set (neogeo.zip), for the BIOS font (sfix.sfix).
    If it is in C:\MAME\roms, it is found automatically.

How to use:
  1. Put the 2 disks (.adf or .zip) and neogeo.zip in this folder
     (otherwise the tool asks where they are).
  2. Double-click "Construire - Build.bat".
  3. Wait a few minutes.

Output, in the "output" folder:
  - neosd_mister\Lotus Neo.neo : NeoSD and MiSTer (Neo Geo core). On MiSTer,
    copy it to games\NeoGeo on the SD card.
  - darksoft\lotusneo : Darksoft cartridge.
  - backbit\lotusneo  : BackBit Platinum MVS (with neogeo.xml).
  - mame\lotusneo     : ROMs for MAME ("lotusneo" set). MAME must know the
    game: if MAME is in C:\MAME, the tool offers to install it (copies the
    ROMs and adds the "lotusneo" entry to hash\neogeo.xml, with a backup
    neogeo.xml.bak_lotusneo). Otherwise, copy mame\lotusneo to MAME's roms
    folder and add the entry from mame\neogeo.xml to hash\neogeo.xml,
    before </softwarelist>. Then run: mame neogeo lotusneo

The tool checks every ROM it builds (SHA-1). If your numpy version differs
from mine, the music may differ very slightly: this is reported and the
game remains playable.

Controls:
  - D-pad: steer. A: accelerate. B: brake. START: pause.
  - C / D: shift up / down (switches to manual gears).
  - Menus: A or START to confirm, B to go back.
  - Main menu options: manual or automatic gears (GEARS), accelerate with
    button A or by pushing the D-pad up (ACCELERATE), 1 or 2 players
    (split screen).

Command line (options):
  python builder.py --disk1 D1.adf --disk2 D2.adf --bios neogeo.zip
  python builder.py --install-mame C:\MAME      (install into MAME)
  python builder.py --no-install                (don't offer it)

Notice: non-commercial fan project, not affiliated with Gremlin, Magnetic
Fields or the rights holders of Lotus III. Lotus III: The Ultimate
Challenge (c) 1992 Magnetic Fields / Gremlin Graphics. Lotus is a trademark
of its owner. The ROMs you build are for your personal use: do not
distribute them or sell repros.
adpcmtool.py and the nullsound sound driver: ngdevkit (c) Damien Ciabrini,
LGPL-3 license (lib/).
