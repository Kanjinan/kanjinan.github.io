@echo off
rem Lotus Neo - constructeur de ROM / ROM builder
chcp 65001 >nul
set PYTHONUTF8=1
cd /d "%~dp0"

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY goto nopython
%PY% -c "import sys; sys.exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>nul || goto nopython

%PY% -c "import numpy, PIL, unicorn" >nul 2>nul
if errorlevel 1 (
    echo Installation de numpy, Pillow et unicorn / installing numpy, Pillow and unicorn...
    %PY% -m pip install --user numpy pillow unicorn || goto end
)

%PY% builder.py %*
goto end

:nopython
echo Python 3.9 ou plus est necessaire / Python 3.9 or newer is required:
echo   https://www.python.org/downloads/
echo (cocher "Add python.exe to PATH" / tick "Add python.exe to PATH")

:end
echo.
pause
