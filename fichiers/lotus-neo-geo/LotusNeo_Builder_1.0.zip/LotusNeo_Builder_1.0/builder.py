"""Lotus Neo - constructeur de ROM / ROM builder

Construit Lotus Neo (Neo Geo) à partir de VOS disquettes Amiga de Lotus III
et du BIOS Neo Geo de MAME (neogeo.zip, pour la police du BIOS).
Builds Lotus Neo (Neo Geo) from YOUR OWN Lotus III Amiga disks and the MAME
Neo Geo BIOS set (neogeo.zip, for the BIOS font).

Aucune donnée du jeu original n'est fournie avec cet outil.
No data from the original game is included with this tool.

Usage :
  python builder.py [--disk1 D1.adf] [--disk2 D2.adf] [--bios neogeo.zip]
                    [--out output] [--install-mame C:\\MAME | --no-install]
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import zipfile
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LIB = ROOT / "lib"
DATA = ROOT / "data"
sys.path.insert(0, str(LIB))

import lnpatch  # noqa: E402

GAME = "lotusneo"
NEO_NAME = "Lotus Neo.neo"
ROMS = ("p1", "s1", "m1", "v1", "c1", "c2")


def say(fr: str, en: str = "") -> None:
    print(fr if not en else f"{fr}  /  {en}", flush=True)


def fail(fr: str, en: str) -> None:
    say(f"\nERREUR : {fr}", f"ERROR: {en}")
    raise SystemExit(1)


def ask(fr: str, en: str) -> str:
    try:
        return input(f"{fr} / {en}\n> ").strip().strip('"')
    except EOFError:
        return ""


def sha1(b: bytes) -> str:
    return hashlib.sha1(b).hexdigest()


# ---------------------------------------------------------------------------
# Fichiers d'entrée / input files

def candidates(folder: Path):
    """(nom, contenu) de chaque .adf du dossier, y compris dans les .zip."""
    if not folder.is_dir():
        return
    for f in sorted(folder.iterdir()):
        low = f.name.lower()
        try:
            if low.endswith(".adf") and f.stat().st_size == 901120:
                yield f.name, f.read_bytes()
            elif low.endswith(".zip") and f.stat().st_size < 4 << 20:
                with zipfile.ZipFile(f) as z:
                    for i in z.infolist():
                        if i.filename.lower().endswith(".adf") and i.file_size == 901120:
                            yield f"{f.name}:{i.filename}", z.read(i)
        except (OSError, zipfile.BadZipFile):
            continue


def find_disks(manifest: dict, args) -> dict:
    want = {manifest["disks"][k]["sha1"]: k for k in ("1", "2")}
    found = {}
    for k, p in (("1", args.disk1), ("2", args.disk2)):
        if p:
            b = Path(p).read_bytes()
            if sha1(b) != manifest["disks"][k]["sha1"]:
                fail(f"{p} n'est pas le disque {k} attendu", f"{p} is not the expected disk {k}")
            found[k] = (p, b)
    folders = [ROOT, ROOT / "disks", ROOT.parent]
    while len(found) < 2:
        for folder in folders:
            for name, b in candidates(folder):
                k = want.get(sha1(b))
                if k and k not in found:
                    found[k] = (str(folder / name) if ":" not in name else name, b)
        if len(found) == 2:
            break
        missing = [k for k in ("1", "2") if k not in found]
        say("\nDisquette(s) introuvable(s) : " + ", ".join(manifest["disks"][k]["name"] for k in missing),
            "disk(s) not found")
        p = ask("Dossier contenant les disquettes (.adf ou .zip) ? (Entrée = annuler)",
                "Folder with the disks (.adf or .zip)? (Enter = cancel)")
        if not p:
            raise SystemExit(1)
        p = Path(p)
        folders = [p.parent if p.is_file() else p]
    return found


def find_sfix(manifest: dict, args) -> bytes:
    crc = manifest["sfix_crc32"]

    def from_path(p: Path):
        try:
            if p.suffix.lower() == ".zip":
                with zipfile.ZipFile(p) as z:
                    for i in z.infolist():
                        if f"{i.CRC:08x}" == crc:
                            return z.read(i)
            elif p.is_file() and f"{zlib.crc32(p.read_bytes()):08x}" == crc:
                return p.read_bytes()
        except (OSError, zipfile.BadZipFile):
            pass
        return None

    paths = [Path(args.bios)] if args.bios else []
    paths += [ROOT / "neogeo.zip", ROOT / "sfix.sfix", ROOT.parent / "neogeo.zip",
              Path(r"C:\MAME\roms\neogeo.zip"), Path(r"C:\MAME\roms\neogeo\sfix.sfix")]
    for p in paths:
        b = from_path(p)
        if b:
            say(f"BIOS   : {p}")
            return b
    while True:
        p = ask("Chemin de neogeo.zip (BIOS Neo Geo de MAME) ou de sfix.sfix ? (Entrée = annuler)",
                "Path to neogeo.zip (MAME Neo Geo BIOS) or sfix.sfix? (Enter = cancel)")
        if not p:
            raise SystemExit(1)
        b = from_path(Path(p))
        if b:
            return b
        say("  sfix.sfix introuvable dans ce fichier (CRC c2ea0cfd attendu)",
            "sfix.sfix not found in that file (CRC c2ea0cfd expected)")


# ---------------------------------------------------------------------------
# Étapes / steps

def run(work: Path, log: Path, script: str, *args: str, env: dict | None = None) -> None:
    with open(log, "a", encoding="utf-8", errors="replace") as f:
        f.write(f"\n===== {script} {' '.join(args)}\n")
        f.flush()
        r = subprocess.run([sys.executable, str(work / "tools" / script), *args], cwd=str(work),
                           env=dict(os.environ, PYTHONUTF8="1", **(env or {})),
                           stdout=f, stderr=subprocess.STDOUT)
    if r.returncode:
        tail = log.read_text(encoding="utf-8", errors="replace").splitlines()[-15:]
        print("\n".join(tail))
        fail(f"{script} a échoué (journal : {log})", f"{script} failed (log: {log})")


def write_zip(zpath: Path, base: Path, folder: Path) -> None:
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for f in sorted(folder.rglob("*")):
            if f.is_file():
                z.write(f, f.relative_to(base).as_posix())


def install_mame(mame_dir: Path, rom_dir: Path, xml_entry: str) -> None:
    hash_xml = mame_dir / "hash" / "neogeo.xml"
    if not hash_xml.is_file():
        fail(f"{hash_xml} introuvable", f"{hash_xml} not found")
    dest = mame_dir / "roms" / GAME
    dest.mkdir(parents=True, exist_ok=True)
    for f in rom_dir.iterdir():
        shutil.copyfile(f, dest / f.name)
    content = hash_xml.read_text(encoding="utf-8")
    pat = re.compile(rf'[ \t]*<software\s+name="{GAME}">.*?</software>\s*\n?', re.S)
    stripped = pat.sub("", content)
    idx = stripped.rfind("</softwarelist>")
    if idx < 0:
        fail("</softwarelist> introuvable dans neogeo.xml", "</softwarelist> not found in neogeo.xml")
    backup = hash_xml.with_name("neogeo.xml.bak_lotusneo")
    if not backup.exists():
        shutil.copy2(hash_xml, backup)
    hash_xml.write_text(stripped[:idx] + xml_entry + stripped[idx:], encoding="utf-8")
    say(f"  ROMs copiées dans {dest}", "ROMs copied")
    say(f"  Entrée « {GAME} » ajoutée à {hash_xml} (sauvegarde : {backup.name})", "entry added")
    say(f"  Lancer / run :  mame neogeo {GAME}   (ou / or: mame {GAME})")


def main() -> int:
    ap = argparse.ArgumentParser(description="Lotus Neo ROM builder")
    ap.add_argument("--disk1", help="Lotus III, disque 1 / disk 1 (.adf)")
    ap.add_argument("--disk2", help="Lotus III, disque 2 / disk 2 (.adf)")
    ap.add_argument("--bios", help="neogeo.zip (MAME) ou / or sfix.sfix")
    ap.add_argument("--out", default=str(ROOT / "output"))
    ap.add_argument("--install-mame", metavar="MAME_DIR", help="installe aussi dans MAME / also install into MAME")
    ap.add_argument("--no-install", action="store_true", help="ne pas proposer l'installation dans MAME")
    args = ap.parse_args()

    manifest = json.loads((DATA / "manifest.json").read_text(encoding="utf-8"))
    out = Path(args.out)
    work = out / "_work"
    t0 = time.time()
    say(f"Lotus Neo - version {manifest['version']}")

    # ------------------------------------------------------------------
    say("\n[1/6] Disquettes Lotus III et BIOS Neo Geo", "Lotus III disks and Neo Geo BIOS")
    disks = find_disks(manifest, args)
    for k in ("1", "2"):
        say(f"Disque {k} : {disks[k][0]}")
    sfix = find_sfix(manifest, args)

    if work.exists():
        shutil.rmtree(work)
    (work / "adf").mkdir(parents=True)
    (work / "build").mkdir()
    shutil.copytree(LIB / "tools", work / "tools")
    for k in ("1", "2"):
        (work / "adf" / f"lotus3_d{k}.adf").write_bytes(disks[k][1])
    (work / "sfix.sfix").write_bytes(sfix)
    log = work / "journal.txt"
    say("  OK")

    # ------------------------------------------------------------------
    say("\n[2/6] Extraction des fichiers des disquettes", "extracting the disk files")
    run(work, log, "amiga/lotus_files.py", "l3")
    ex = work / "extract"
    main_prog = (ex / "l3" / "d1_255.bin").read_bytes()
    if sha1(main_prog) != manifest["main_sha1"]:
        fail("programme principal inattendu", "unexpected main program")
    (ex / "l3_d1_255.bin").write_bytes(main_prog)
    # palettes des objets de chaque décor ($2D04 + 32 x décor dans le programme)
    for n in range(15):
        (ex / "l3" / f"pal_s{n:02d}.pal").write_bytes(main_prog[0x2D04 + 32 * n:0x2D04 + 32 * n + 32])
    say("  OK")

    # ------------------------------------------------------------------
    say("\n[3/6] Graphismes et circuits (C1, C2, S1) - environ 20 s",
        "graphics and tracks (C1, C2, S1) - about 20 s")
    run(work, log, "build_raster_test.py", env={"LN_SFIX": str(work / "sfix.sfix")})
    b = work / "build"
    shutil.copyfile(b / "s1_hud.bin", b / f"{GAME}-s1.s1")
    say("  OK")

    # ------------------------------------------------------------------
    say("\n[4/6] Musiques et bruitages (V1) - environ 30 s", "music and sound effects (V1) - about 30 s")
    run(work, log, "build_music.py", "build", env={"NGDK_DIR": str(LIB / "ngdk")})
    say("  OK")

    # ------------------------------------------------------------------
    say("\n[5/6] Programme (P1, M1)", "program ROMs")
    source = lnpatch.make_source(main_prog, (b / "road_data.c").read_text(encoding="utf-8"),
                                 (b / "road_data.h").read_text(encoding="utf-8"))
    try:
        p1 = lnpatch.swap16(lnpatch.apply(source, (DATA / "p1.patch").read_bytes()))
    except (ValueError, IndexError, zlib.error) as e:
        fail(f"application du patch impossible ({e})", f"cannot apply the patch ({e})")
    (b / f"{GAME}-p1.p1").write_bytes(p1)
    shutil.copyfile(DATA / "m1.bin", b / f"{GAME}-m1.m1")
    say("  OK")

    # ------------------------------------------------------------------
    say("\n[6/6] Contrôle et fichiers pour cartouches", "checking and exporting cartridge files")
    ok = True
    for k in ROMS:
        same = sha1((b / f"{GAME}-{k}.{k}").read_bytes()) == manifest["sha1"][k]
        if not same and k == "v1":
            say("  V1 : son légèrement différent de la version de référence (autre version de numpy ?) - "
                "jouable quand même", "V1 slightly differs from the reference (other numpy version?) - "
                "still playable")
        elif not same:
            say(f"  {k.upper()} : ERREUR, différente de la version de référence", f"{k.upper()}: ERROR")
            ok = False
        else:
            say(f"  {k.upper()} : identique à la version de référence", "identical to the reference")
    if not ok:
        say(f"Journal / log : {log}")
        return 1

    sys.path.insert(0, str(work / "tools"))
    import build_neo  # noqa: E402
    import export_carts  # noqa: E402
    neo = b / NEO_NAME
    build_neo.main_args(str(b), str(neo))
    export_carts.BUILD = b
    export_carts.NEO = neo
    export_carts.main()
    carts = b / "carts"
    out.mkdir(parents=True, exist_ok=True)
    for name in ("neosd_mister", "darksoft", "backbit"):
        dst = out / name
        if dst.exists():
            shutil.rmtree(dst)
        shutil.copytree(carts / name, dst)
    mame_dir = out / "mame" / GAME
    if mame_dir.exists():
        shutil.rmtree(mame_dir)
    mame_dir.mkdir(parents=True)
    for k in ROMS:
        shutil.copyfile(b / f"{GAME}-{k}.{k}", mame_dir / f"{GAME}-{k}.{k}")
    xml = (out / "backbit" / GAME / "neogeo.xml").read_text(encoding="utf-8")
    entry = xml.split("\n", 1)[1].rsplit("</softwarelist>", 1)[0]
    (out / "mame" / "neogeo.xml").write_text(xml, encoding="utf-8")
    shutil.rmtree(work)

    say(f"\nTerminé en {int(time.time() - t0)} s. Fichiers dans / files in : {out}")
    say(f"  neosd_mister\\{NEO_NAME} : NeoSD / MiSTer")
    say(f"  darksoft\\{GAME}       : Darksoft")
    say(f"  backbit\\{GAME}        : BackBit Platinum MVS")
    say(f"  mame\\{GAME}           : MAME (voir LISEZMOI / see README)")

    # ------------------------------------------------------------------
    mame = Path(args.install_mame) if args.install_mame else None
    if not mame and not args.no_install and Path(r"C:\MAME\hash\neogeo.xml").is_file() and sys.stdin.isatty():
        r = ask("\nInstaller aussi le jeu dans MAME (C:\\MAME) ? o/N", "Also install the game into MAME? y/N")
        if r.lower() in ("o", "oui", "y", "yes"):
            mame = Path(r"C:\MAME")
    if mame:
        say("\nInstallation dans MAME", "installing into MAME")
        install_mame(mame, mame_dir, entry)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
