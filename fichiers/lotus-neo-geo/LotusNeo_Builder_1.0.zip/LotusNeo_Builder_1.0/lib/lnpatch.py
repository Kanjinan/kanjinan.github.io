"""Patch de la ROM P de Lotus Neo / Lotus Neo P ROM patch.

La ROM P contient le code du portage (le mien) et des donnees tirees du jeu
original : programme principal de Lotus III (generateur de circuits RECS) et
tables generees a partir des disquettes (build/road_data.c). Le patch ne contient
QUE le code du portage : toutes les donnees du jeu original sont recopiees depuis
une « source » reconstruite chez l'utilisateur a partir de SES disquettes.

The P ROM holds the port's code (my own work) and data taken from the original
game. The patch holds ONLY the port's code: every piece of original data is
copied from a "source" rebuilt from the user's own disks.

Source = programme principal (extract/l3_d1_255.bin)
       + valeurs de road_data.c, serialisees comme les range gcc (68000, gros boutiste)
       + chaines de caracteres de road_data.c

Format du patch (compresse zlib) : b"LNP1", taille cible (u32), puis des operations
  0x01 COPY   varint(position dans la source) varint(longueur)
  0x02 INSERT varint(longueur) octets
  0x03 FILL   octet varint(longueur)
"""

from __future__ import annotations

import re
import zlib

MAGIC = b"LNP1"

# ---------------------------------------------------------------------------
# Serialisation de road_data.c (types du 68000 : short et pointeurs alignes sur 2)

SCALARS = {"u8": 1, "s8": 1, "char": 1, "u16": 2, "s16": 2, "u32": 4, "s32": 4}


def _defines(h: str) -> dict:
    out = {}
    for m in re.finditer(r"^#define\s+(\w+)\s+([^/\n]+)", h, re.M):
        expr = m.group(2).strip()
        try:
            out[m.group(1)] = int(eval(expr, {}, dict(out)))  # noqa: S307 (fichier genere par le projet)
        except Exception:  # noqa: BLE001
            pass
    return out


def _dim(expr: str, defs: dict) -> int:
    return int(eval(expr, {}, defs))  # noqa: S307


def _parse_fields(body: str, defs: dict, types: dict) -> list:
    fields = []
    for decl in body.split(";"):
        decl = decl.strip()
        if not decl:
            continue
        decl = decl.replace("const ", "")
        m = re.match(r"(\w+)\s+(.*)", decl)
        base, names = m.group(1), m.group(2)
        for nm in names.split(","):
            nm = nm.strip()
            if nm.startswith("*"):
                fields.append(("ptr",))
                continue
            t = types[base] if base in types else ("scalar", SCALARS[base])
            dims = re.findall(r"\[([^\]]*)\]", nm)
            for d in reversed(dims):
                t = ("array", t, _dim(d, defs))
            fields.append(t)
    return fields


def _align(t) -> int:
    if t[0] == "scalar":
        return min(t[1], 2)
    if t[0] == "ptr":
        return 2
    if t[0] == "array":
        return _align(t[1])
    return max([_align(f) for f in t[1]] + [1])


def _size(t) -> int:
    if t[0] == "scalar":
        return t[1]
    if t[0] == "ptr":
        return 4
    if t[0] == "array":
        return _size(t[1]) * t[2]
    off = 0
    for f in t[1]:
        a = _align(f)
        off = (off + a - 1) // a * a + _size(f)
    a = _align(t)
    return (off + a - 1) // a * a


_TOK = re.compile(r'\s*(\{|\}|,|"(?:[^"\\]|\\.)*"|-?0x[0-9a-fA-F]+[uUlL]*|-?\d+[uUlL]*|[A-Za-z_]\w*)')


def _tokens(s: str):
    pos = 0
    while True:
        m = _TOK.match(s, pos)
        if not m:
            if s[pos:].strip():
                raise ValueError(f"road_data.c : jeton inattendu {s[pos:pos + 20]!r}")
            return
        yield m.group(1)
        pos = m.end()


def _parse_init(toks: list, i: int):
    """Initialiseur -> (valeur, i) ; valeur = liste (accolades), int, str ou ('sym', nom)."""
    t = toks[i]
    if t == "{":
        out, i = [], i + 1
        while toks[i] != "}":
            v, i = _parse_init(toks, i)
            out.append(v)
            if toks[i] == ",":
                i += 1
        return out, i + 1
    if t.startswith('"'):
        return t[1:-1].encode("latin1").decode("unicode_escape").encode("latin1"), i + 1
    if t[0].isdigit() or t[0] == "-":
        return int(t.rstrip("uUlL"), 0), i + 1
    return ("sym", t), i + 1


def _ser(v, t, out: bytearray, strings: list) -> None:
    """Ecrit la valeur v de type t (zeros pour les elements absents)."""
    if t[0] == "scalar":
        n = t[1]
        x = 0 if v is None else v
        if isinstance(x, tuple):
            x = 0
        out += (x & ((1 << (8 * n)) - 1)).to_bytes(n, "big")
    elif t[0] == "ptr":
        if isinstance(v, bytes):
            strings.append(v)
        out += b"\0\0\0\0"
    elif t[0] == "array":
        if isinstance(v, bytes):          # char tab[n] = "..."
            out += v[:t[2]].ljust(t[2], b"\0")
            return
        items = v if isinstance(v, list) else []
        for k in range(t[2]):
            _ser(items[k] if k < len(items) else None, t[1], out, strings)
    else:
        start = len(out)
        items = v if isinstance(v, list) else []
        for k, f in enumerate(t[1]):
            a = _align(f)
            while (len(out) - start) % a:
                out.append(0)
            _ser(items[k] if k < len(items) else None, f, out, strings)
        a = _align(t)
        while (len(out) - start) % a:
            out.append(0)


def serialize_road_data(c_text: str, h_text: str) -> bytes:
    defs = _defines(h_text)
    types = {}
    for m in re.finditer(r"typedef struct \{(.*?)\}\s*(\w+);", h_text, re.S):
        body = re.sub(r"/\*.*?\*/", "", m.group(1), flags=re.S)
        types[m.group(2)] = ("struct", _parse_fields(body, defs, types))
    c_text = re.sub(r"/\*.*?\*/", "", c_text, flags=re.S)
    data, strings = bytearray(), []
    for m in re.finditer(r"^const (\w+)\s*(\*\s*const\s+)?(\w+)((?:\[[^\]]*\])*)\s*=\s*(.*?);\s*$",
                         c_text, re.M | re.S):
        base, is_ptr, _name, dims, init = m.groups()
        toks = list(_tokens(init))
        val, _ = _parse_init(toks, 0)
        t = ("ptr",) if is_ptr else (types[base] if base in types else ("scalar", SCALARS[base]))
        dl = re.findall(r"\[([^\]]*)\]", dims)
        for k, d in reversed(list(enumerate(dl))):
            if d.strip():
                n = _dim(d, defs)
            else:                       # dimension implicite : celle de l'initialiseur
                n = len(val) if k == 0 else 0
            t = ("array", t, n)
        _ser(val, t, data, strings)   # les chaines (champs pointeurs) vont dans strings
    return bytes(data) + b"".join(s + b"\0" for s in strings)


def make_source(main_prog: bytes, road_c: str, road_h: str) -> bytes:
    return main_prog + serialize_road_data(road_c, road_h)


# ---------------------------------------------------------------------------
# Patch

def _varint(n: int) -> bytes:
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            out.append(b | 0x80)
        else:
            out.append(b)
            return bytes(out)


def _read_varint(d: bytes, i: int):
    n = shift = 0
    while True:
        b = d[i]
        i += 1
        n |= (b & 0x7F) << shift
        shift += 7
        if not b & 0x80:
            return n, i


def apply(source: bytes, patch: bytes) -> bytes:
    d = zlib.decompress(patch)
    if d[:4] != MAGIC:
        raise ValueError("patch invalide / invalid patch")
    size = int.from_bytes(d[4:8], "big")
    out = bytearray()
    i = 8
    while i < len(d):
        op = d[i]
        i += 1
        if op == 1:
            src, i = _read_varint(d, i)
            n, i = _read_varint(d, i)
            if src + n > len(source):
                raise ValueError("source trop courte / source too short")
            out += source[src:src + n]
        elif op == 2:
            n, i = _read_varint(d, i)
            out += d[i:i + n]
            i += n
        elif op == 3:
            b = d[i]
            n, i = _read_varint(d, i + 1)
            out += bytes([b]) * n
        else:
            raise ValueError("patch invalide / invalid patch")
    if len(out) != size:
        raise ValueError("taille inattendue / unexpected size")
    return bytes(out)


def encode(target: bytes, source: bytes, k: int = 4, min_copy: int = 6, min_fill: int = 16):
    """Patch target <- source. Renvoie (patch, liste des plages inserees [(debut, fin)])."""
    index: dict = {}
    for p in range(len(source) - k + 1):
        lst = index.setdefault(source[p:p + k], [])
        if len(lst) < 256:
            lst.append(p)
    ops = bytearray(MAGIC + len(target).to_bytes(4, "big"))
    lit = bytearray()
    inserted = []

    def flush(at: int) -> None:
        nonlocal lit
        if lit:
            ops.extend(b"\x02" + _varint(len(lit)) + lit)
            inserted.append((at - len(lit), at))
            lit = bytearray()

    i, n = 0, len(target)
    while i < n:
        # suite d'octets identiques
        j = i
        while j < n and target[j] == target[i] and j - i < 1 << 20:
            j += 1
        if j - i >= min_fill:
            flush(i)
            ops.extend(b"\x03" + bytes([target[i]]) + _varint(j - i))
            i = j
            continue
        best_len, best_src = 0, 0
        for p in index.get(target[i:i + k], ()):
            m = k
            while i + m < n and p + m < len(source) and target[i + m] == source[p + m]:
                m += 1
            if m > best_len:
                best_len, best_src = m, p
        if best_len >= min_copy:
            flush(i)
            ops.extend(b"\x01" + _varint(best_src) + _varint(best_len))
            i += best_len
        else:
            lit.append(target[i])
            i += 1
    flush(n)
    return zlib.compress(bytes(ops), 9), inserted


def swap16(b: bytes) -> bytes:
    out = bytearray(len(b))
    out[0::2] = b[1::2]
    out[1::2] = b[0::2]
    return bytes(out)
