"""Donnees de la ROM de test raster (route par IRQ timer ligne a ligne).

Genere dans build/ :
  lotusneo-c1.c1 / lotusneo-c2.c2   tuiles (route source + voiture)
  road_data.h / road_data.c         tables C (tuiles, palettes, circuit, inverses)

Route source : image de ROAD_W x 512 lignes = ROAD_COLS colonnes de sprites x
32 tuiles. Ligne r (1-255) = coupe de route de demi-largeur 2r (jusqu'a 510 px :
les routes de Lotus III font 4 x largeur du decor en bas d'ecran, 448 px pour
futureworld), recadree a +-ROAD_CX (au-dela : hors ecran)
pixels (phase A), ligne 256 + r = meme largeur en phase B (bandes claires) ;
lignes 0 et 256 transparentes (ciel). La chaine (ROAD_W <= 512 - marge) ne
doit pas se replier sur elle-meme (X modulo 512). L'IRQ choisit la ligne affichee en deplacant le Y de la
chaine de sprites (cf. src/main.c).

Usage : .venv/Scripts/python.exe tools/build_raster_test.py [code_recs]
"""

from __future__ import annotations

import math
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(HERE, "amiga"))

import lotus2_track  # noqa: E402
import render_bank  # noqa: E402

BUILD = os.path.join(ROOT, "build")
GAME = "lotusneo"
ROAD_COLS = 30
ROAD_RMAX = 510      # demi-largeur max (coupe r = demi-largeur / 4)
ROAD_SLICES = 128    # coupes par phase (demi-largeur par pas de 4 px)
ROAD_PHASES = 4      # A, B (bandes), puis A, B des zones de depart / controle
START_PENS = ((11, 12), (13, 14))   # route / marquage des phases de depart (hors brouillard)
ROAD_W = ROAD_COLS * 16
ROAD_CX = ROAD_W // 2
CROM_SIZE = 0x100000

# Projection (doit rester coherent avec src/main.c)
PROJ_D = 128          # distance de projection
RECIP_Q = 12          # echelle = PROJ_D << RECIP_Q / dz
RECIP_STEP = 8        # pas de dz de la table d'inverses
RECIP_N = 4096
DZ_MIN = 64

# Couleurs (RGB)
ROAD_PAL = [(0x58, 0x58, 0x60), (0x68, 0x68, 0x70), (0xF0, 0xF0, 0xF0),
            (0xD8, 0x20, 0x20), (0xE8, 0xE8, 0xE8)]
GRASS = [(0x18, 0x88, 0x20), (0x28, 0xA0, 0x30)]
SKY_TOP, SKY_HORIZON = (0x20, 0x48, 0xC0), (0xA0, 0xC8, 0xF8)


def neo_color(rgb: tuple[int, int, int]) -> int:
    r, g, b = rgb
    word = ((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4)
    word |= (((r >> 3) & 1) << 14) | (((g >> 3) & 1) << 13) | (((b >> 3) & 1) << 12)
    return word


def encode_tile(pixels: list[int]) -> tuple[bytes, bytes]:
    """Tuile 16x16 -> (C1, C2) ; blocs 8x8 droite-haut, droite-bas, gauche-haut, gauche-bas."""
    c1, c2 = bytearray(64), bytearray(64)
    pos = 0
    for xo, yo in ((8, 0), (8, 8), (0, 0), (0, 8)):
        for row in range(8):
            p = [0, 0, 0, 0]
            for i in range(8):
                v = pixels[(yo + row) * 16 + xo + i]
                for k in range(4):
                    if (v >> k) & 1:
                        p[k] |= 1 << i
            c1[pos], c1[pos + 1] = p[0], p[1]
            c2[pos], c2[pos + 1] = p[2], p[3]
            pos += 2
    return bytes(c1), bytes(c2)


class TileBank:
    def __init__(self) -> None:
        self.tiles: list[tuple[int, ...]] = [tuple([0] * 256)]
        self.index = {self.tiles[0]: 0}

    def add(self, px: list[int]) -> int:
        key = tuple(px)
        if key not in self.index:
            self.index[key] = len(self.tiles)
            self.tiles.append(key)
        return self.index[key]

    def write(self, c1_path: str, c2_path: str) -> None:
        c1, c2 = bytearray(CROM_SIZE), bytearray(CROM_SIZE)
        for i, t in enumerate(self.tiles):
            a, b = encode_tile(list(t))
            c1[i * 64:i * 64 + 64], c2[i * 64:i * 64 + 64] = a, b
        open(c1_path, "wb").write(c1)
        open(c2_path, "wb").write(c2)


# Style de route par decor (captures du jeu, docs/ref/) : pas de rives
# rouges / blanches dans Lotus III ; l'encre « marquage » (3 / 6) dessine
#  - "lanes" : 3 voies de 0,6 demi-largeur, 4 lignes a +-0,3 et +-0,9 de la
#    demi-largeur, epaisses de 1/24 (mesure WinUAE : fog, wind) ;
#  - "fog" : idem, couleurs fondues vers le gris au loin ;
#  - "checker" : bandes pleines alternees (futureworld) ; les couleurs route /
#    marquage s'echangent d'une phase a l'autre ($6B3B4), d'ou le damier.
ROAD_STYLE = {2: "fog", 1: "fog_night", 7: "fog_storm", 11: "checker"}
# Paliers de distance ($78304, decors a3+1230 : nuit, brouillard, orage) : le
# copper prend l'entree du bloc (idx + niveau) de $6B3B4, niveau = profondeur
# >> 10 (0-8). Le portage garde 4 paliers par distance a l'horizon (FOG_DY,
# mesure WinUAE sur le brouillard) : palier k = niveau 2k.
FADE_BASE = {2: 13, 1: 22, 7: 40}
FADE_STYLE_DECOR = {"fog": 2, "fog_night": 1, "fog_storm": 7}
FOG_HWS = {}    # style -> demi-largeur monde de la route du decor (main)
LANE_LINES = (0.3, 0.9)
# Damier de futureworld (mesure sur docs/ref/l3_course_pwrwvwhnm-30_route.png et
# _depart.png, lignes Amiga 152-199) : colonnes de meme largeur, frontiere au
# centre de la route, 7,25 colonnes par demi-largeur (colonne la plus au bord
# partielle) ; colonnes de 12 px a l'horizon, 63 px en bas d'ecran. Meme taille
# de cases sur la route et dans les zones de depart / controle.
CHECKER_PER_HALF = 7.25
# Brouillard (decor 2, mesure WinUAE) : sol, route et marquage tendent vers le
# gris 666 de +1 par composante et par palier de distance, 4 paliers sous
# l'horizon. Paliers par distance a l'horizon (route plate, lignes Neo) :
FOG_DY = [20, 13, 6, 4]       # dy < FOG_DY[k - 1] -> palier k
FOG_HW = None                 # demi-largeur monde de la route du brouillard (main)
# encres du brouillard (palette 1, index 7-15) : palier -> (route A, route B,
# marquage A, marquage B)
# marquage B = route B (entrees $6B3B4 : pas de marquage en phase B, d'ou les tirets)
FOG_PENS = {1: (7, 8, 9, 8), 2: (10, 11, 12, 11), 3: (13, 13, 14, 13), 4: (15, 15, 15, 15)}


def fade_entry(decor: int, k: int) -> list[int]:
    """Palier k (0-4) : (herbe A, route A, marquage A, herbe B, route B,
    marquage B) du bloc FADE_BASE + 2k de $6B3B4."""
    t = main_words(0x6B3B4 + 64 * (FADE_BASE[decor] + 2 * k), 8)
    return [t[0], t[1], t[2], t[4], t[5], t[6]]


def fog_level(dy: float) -> int:
    return sum(1 for t in FOG_DY if dy < t)


def fog_fade(c: int, k: int) -> int:
    """Couleur Amiga 12 bits rapprochee du gris 666 de k par composante."""
    out = 0
    for sh in (8, 4, 0):
        v = (c >> sh) & 15
        v = min(v + k, 6) if v < 6 else max(v - k, 6)
        out |= v << sh
    return out


# Seconde image (chaine B) : coupes calees sur un bord, pour les lignes ou la
# route depasse l'image centree (demi-largeur > 240). Par phase : WIDE_K
# coupes calees a gauche (bord en colonne 0, route sur 320 colonnes) puis
# WIDE_K calees a droite (bord en colonne 479, route sur les 320 dernieres).
WIDE_K = 30        # coupes par jeu (4 jeux par phase, cf. build_road)
WIDE_H0 = 244      # demi-largeur de la coupe k = WIDE_H0 + WIDE_STEP k
WIDE_STEP = 8


def road_row(r: int, phase: int, style: str = "lanes", anchor: str = "c") -> list[int]:
    """Indices de couleur d'une coupe de route (1 = route A, 2 = route B,
    3 / 6 = marquage A / B, 0 = transparent : l'herbe est le fond).
    anchor : c = centree en ROAD_CX ; l / r = bord gauche / droit au bord de
    l'image, route limitee aux 320 colonnes de ce cote."""
    cx = ROAD_CX if anchor == "c" else (r if anchor in ("l", "L") else ROAD_W - r)
    row = [0] * ROAD_W
    if r == 0:
        return row
    pen_road, pen_line = (1, 3) if phase == 0 else (2, 6)
    if phase >= 2:
        # depart, arrivee, ligne de controle : entrees 6 / 7 de $6B3B4 (blanc
        # pour la plupart des decors ; damier pour futureworld)
        if style.startswith("fog"):
            pen_road = pen_line = 3      # route et marquage blancs (= marquage A)
        else:
            pen_road, pen_line = START_PENS[phase - 2]
    elif style.startswith("fog"):
        lv = fog_level(r * CAM_H / FOG_HWS[style])
        if lv:
            pa, pb, la, lb = FOG_PENS[lv]
            pen_road, pen_line = (pa, la) if phase == 0 else (pb, lb)
    lw = max(1, round(r / 24))           # largeur d'une ligne de voie
    for x in range(ROAD_W):
        # l / r : route limitee aux 320 colonnes du cote du bord (pas de
        # route dans les colonnes qui se replient) ; L / R : image complete
        if (anchor == "l" and x >= 320) or (anchor == "r" and x < ROAD_W - 320):
            continue
        u = x - cx + 0.5                  # position signee, en px
        d = abs(u)
        if d >= r:
            continue
        mark = False
        if style == "checker":
            # colonnes symetriques : a droite du centre route, a gauche marquage
            band = math.floor(u * CHECKER_PER_HALF / r)
            mark = band % 2 == 1
        else:
            mark = any(abs(d - k * r) < lw / 2 for k in LANE_LINES)
        row[x] = pen_line if mark else pen_road
    return row


def build_road(tiles: TileBank, style: str = "lanes", wide: bool = False) -> list[list[int]]:
    if wide:
        # par phase (128 coupes) : 3 vides (l'IRQ passe une ligne sur deux :
        # la suivante de la coupe vide doit l'etre aussi), puis 4 jeux (L, l,
        # R, r : calees a gauche complete / limitee, a droite complete /
        # limitee) d'une coupe vide et de WIDE_K coupes : coupe
        # 4 + jeu x (WIDE_K + 1) + k. La ligne qui precede la 1re ligne de la
        # chaine B affiche deja la coupe k - 1 avec le X de k : vide pour
        # k = 0 (sinon la derniere coupe du jeu precedent, dont les colonnes
        # repliees apparaissent a droite de l'ecran)
        def wrow(p, i):
            j = i - 3
            if j < 0 or j >= 4 * (WIDE_K + 1) or j % (WIDE_K + 1) == 0:
                return [0] * ROAD_W
            return road_row(WIDE_H0 + WIDE_STEP * (j % (WIDE_K + 1) - 1), p, style, "LlRr"[j // (WIDE_K + 1)])
        rows = [wrow(p, i) for p in range(ROAD_PHASES) for i in range(ROAD_SLICES)]
    else:
        rows = [road_row(4 * r, p, style) for p in range(ROAD_PHASES) for r in range(ROAD_SLICES)]
    cols = []
    for c in range(ROAD_COLS):
        col = []
        for t in range(ROAD_SLICES * ROAD_PHASES // 16):
            px = [rows[t * 16 + y][c * 16 + x] for y in range(16) for x in range(16)]
            col.append(tiles.add(px))
        cols.append(col)
    return cols


CAR_BANK = 143          # voiture du joueur, voiture 0 (table $74B86, decors courants)
CAR_ANGLES = 9          # images 0-8 : pleine taille, du virage a droite au virage a gauche
# Couleurs relevees dans le jeu (WinUAE, Esprit rouge en course) : carrosserie
# $A00, contours et ombres $600. La routine $74C4A fait de meme pour les 3
# livrees : carrosserie ccc / 040 / a00, ombre 444 / 222 / 600.
CAR_BODY = (0xAA, 0x00, 0x00)   # index 5 = carrosserie
CAR_TRIM = (0x66, 0x00, 0x00)   # index 4 = contours / ombres (version foncee)
# Adversaires : image centrale de chaque niveau d'echelle de la banque (9 angles
# en pleine taille, 5 angles x 4 echelles, puis 3 angles) = 17 niveaux, comme
# les objets. Pleine taille quand la demi-largeur de route vaut OPP_REF_HW px
# (celle de la route sous la voiture du joueur).
OPP_FRAMES = [4, 11, 16, 21, 26] + [30 + 3 * i for i in range(11)] + [62]
# variantes d'angle (meme echelle) : vers la droite (flanc gauche visible) et
# vers la gauche ; banques OPP_BANK + 0 (droite), + 1 (face), + 2 (gauche)
OPP_FRAMES_R = [2, 10, 15, 20, 25] + [29 + 3 * i for i in range(11)] + [62]
OPP_FRAMES_L = [6, 12, 17, 22, 27] + [31 + 3 * i for i in range(11)] + [62]
# Circulation en sens inverse (autoroute, $7AEF6) : banque $A1 = d2_161, voiture
# vue de face (3 angles par echelle : image centrale gardee)
TRAF_FILE = 0xA1
TRAF_FRAMES = [1 + 3 * i for i in range(16)] + [48]
OPP_REF_HW = None    # = SCALE_REF (pleine taille en bas d'ecran), cf. main()
# livrees (carrosserie, ombre) : index Amiga 5 et 4 -> index Neo 6 et 5
OPP_LIVERIES = [((0xCC, 0xCC, 0xCC), (0x44, 0x44, 0x44)),   # blanche (livree du jeu)
                ((0x00, 0x44, 0x00), (0x22, 0x22, 0x22)),   # verte (livree du jeu)
                ((0x22, 0x44, 0xCC), (0x11, 0x22, 0x55)),   # bleue
                ((0xDD, 0xBB, 0x11), (0x66, 0x55, 0x00)),   # jaune
                ((0x33, 0x33, 0x33), (0x11, 0x11, 0x11)),   # noire
                ((0xDD, 0x66, 0x11), (0x66, 0x22, 0x00))]   # orange


# Voitures du joueur (table $74B86, decors courants) : Esprit, Elan, M200 ; livree
# = carrosserie (index 5) + ombre (index 4, version foncee), cf. docs/amiga_notes.md
PLAYER_CARS = [
    ("ESPRIT TURBO SE", 143, (0xAA, 0x00, 0x00), (0x66, 0x00, 0x00)),
    ("ELAN SE", 142, (0xEE, 0xAA, 0x00), (0x88, 0x55, 0x00)),
    ("M200", 190, (0x22, 0x88, 0x22), (0x00, 0x44, 0x00)),
]


# Voitures du brouillard ($74B86 : d2_135 / 168 / 167, 5 plans) : memes images,
# carrosserie en 11 et ombre en 15 (livree, $74C4A), feux arriere allumes (7)
FOG_CARS = [135, 168, 167]
FOG_REMAP = {11: 5, 15: 4}


def build_car(tiles: TileBank, bank: int = CAR_BANK, body=CAR_BODY, trim=CAR_TRIM, premap=None):
    """Voiture du joueur : 9 angles en pleine taille d'une banque (Lotus III),
    palette commune pal_s00, index 4 et 5 remplaces par la livree. Chaque image est
    centree dans une boite commune (colonnes de 16 px, bas aligne)."""
    data = open(os.path.join(ROOT, "extract", "l3", f"d2_{bank:03d}.bin"), "rb").read()
    frames = render_bank.parse(data)[:CAR_ANGLES]
    n = render_bank.be(data, 0, 2)
    rgb = list(render_bank.palette("pal_s00"))
    rgb[5], rgb[4] = body, trim
    pxs = [render_bank.frame_pixels(data, f, n) for f in frames]
    if premap:
        pxs = [[[premap.get(v, v) for v in row] for row in px] for px in pxs]
    remap = {v: v + 1 for v in range(15)}          # meme numerotation pour toutes
    pal = [0x8000] + [neo_color(rgb[v]) for v in range(15)]
    bw = max(f["w"] for f in frames)
    bh = max(f["h"] for f in frames)
    tw, th = (bw + 15) // 16, (bh + 15) // 16
    out = []
    for f, px in zip(frames, pxs):
        ox = (tw * 16 - f["w"]) // 2
        oy = th * 16 - f["h"]
        cols = []
        for c in range(tw):
            col = []
            for t in range(th):
                tile = []
                for y in range(16):
                    for x in range(16):
                        X, Y = c * 16 + x - ox, t * 16 + y - oy
                        v = px[Y][X] if 0 <= X < f["w"] and 0 <= Y < f["h"] else -1
                        tile.append(remap.get(v, 15) if v >= 0 else 0)
                col.append(tiles.add(tile))
            cols.append(col)
        out.append(cols)
    return pal, out, tw * 16, th * 16


# Ecrans du menu (images SC 320 x 200, palette .pal) : sprites de 16 x 16 sur
# 320 x 224 (image a la ligne FE_Y), palettes de 15 couleurs par tuile.
FE_COLS, FE_ROWS, FE_Y = 20, 14, 12


def load_sc(name: str, pal: str | None = None):
    """Image SC 320 x 200 -> (index par pixel sur FE_ROWS x 16 lignes, image a
    la ligne FE_Y ; couleurs RGB de la palette .pal)."""
    L3d = os.path.join(ROOT, "extract", "l3")
    entry = next(l for l in open(os.path.join(L3d, "index.txt"), encoding="utf-8")
                 if l.startswith(name + " ")).split()
    n, psize = int(entry[5]), int(entry[8], 16)
    planes = open(os.path.join(L3d, f"{name}.bin"), "rb").read()
    p = open(os.path.join(L3d, f"{pal or name}.pal"), "rb").read()
    amiga = [int.from_bytes(p[i:i + 2], "big") for i in range(0, len(p), 2)]
    rgb = [amiga_rgb(c) for c in amiga]
    wb, h = 40, psize // 40
    img = [[0] * 320 for _ in range(FE_ROWS * 16)]
    for y in range(min(h, FE_ROWS * 16 - FE_Y)):
        for xb in range(wb):
            bs = [planes[k * psize + y * wb + xb] for k in range(n)]
            for b in range(8):
                img[FE_Y + y][xb * 8 + b] = sum(((bs[k] >> (7 - b)) & 1) << k for k in range(n))
    return img, rgb


# Intro de Lotus III (sequence relevee sous WinUAE, minutage du code $69D74) :
# route d2_084, credits (textes de d2_085, cf. credit_layer), Elan
# d2_086 (21 images, palette de d2_084 aux plans decales : plan 0 = plan 4),
# capot d2_081, ecusson d2_082 / d2_083, titre d1_023 construit par etapes.
INTRO_CAR_FRAMES = 21
TITLE_STAGES = [237, 258, 278, 298]   # LOTUS, I, II, III : colonnes visibles (< x)
TITLE_SUB_Y = 158                     # sous-titre (lignes de l'image >= )
# decalage a droite de chaque etape ($69E8C / $69EC4 / $69EDA / $69EF0 -> $69D20 :
# pointeurs de plans recules de d1 / 16 mots et BPLCON1 = d1 & 15) : le titre
# reste centre pendant qu'il s'allonge ; le titre complet est a 0
TITLE_SHIFT = [42, 20, 10, 0]


# Textes des credits : d2_085 (2 plans de 320 x 270, 15 lignes de texte de 18 px
# empilees). Ecran k : premiere ligne a l'ordonnee y0, une ligne de texte toutes
# les 23 lignes (releve sur les captures WinUAE). Couleurs 1 / 2 / 3 = $CCC / $888 / $000.
CREDIT_LINES = {0: (45, [5, 6, 7, 8, 9]),      # A GAME BY ANDREW MORRIS AND SHAUN SOUTHERN
                1: (68, [10, 6, 11]),          # LEVEL DESIGN BY PETER LIGGETT
                2: (68, [12, 6, 13]),          # MUSIC BY PATRICK PHELAN
                3: (45, [0, 1, 2, 3, 4])}      # COPYRIGHT 1992 ...
CREDIT_RGB = {1: (204, 204, 204), 2: (136, 136, 136), 3: (0, 0, 0)}


def credit_layer(k: int) -> dict:
    """{(x, y): (r, g, b)} des pixels du texte de l'ecran de credits k."""
    d = open(os.path.join(ROOT, "extract", "l3", "d2_085.bin"), "rb").read()
    w, h = 320, 270
    y0, lines = CREDIT_LINES[k]
    out = {}
    for i, line in enumerate(lines):
        for r in range(18):
            sy = line * 18 + r
            for x in range(w):
                o = sy * 40 + (x >> 3)
                v = ((d[o] >> (7 - (x & 7))) & 1) | (((d[w * h // 8 + o] >> (7 - (x & 7))) & 1) << 1)
                if v:
                    out[(x, y0 + i * 23 + r)] = CREDIT_RGB[v]
    return out


def intro_credit(k: int):
    img, rgb = load_sc("d2_084")
    layer = credit_layer(k)
    marked = set()
    extra = []
    for y in range(200):
        for x in range(320):
            c = layer.get((x, y))
            if c:
                # couleurs du texte : index propres (marques, fondus a part)
                if c not in extra:
                    extra.append(c)
                v = len(rgb) + extra.index(c)
                marked.add(v)
                img[FE_Y + y][x] = v
    return img, rgb + extra, marked


# Arrivee de l'Elan, d'apres le code du jeu ($6A09A, appele de $69E08 pour
# les ticks 1962-2081) : octet $6A222[tick - 1962] = image affichee (0-20 :
# d2_086 ; 21 capot d2_081, 22 / 23 ecussons d2_082 / d2_083), position en
# mots de 16 px $6A1CE[image] et ligne 255 - $6A1F8[image] du haut de l'image.
ELAN_T0 = 1962
ELAN_TICKS = 120


def elan_tables():
    import struct
    d = open(os.path.join(ROOT, "extract", "l3_d1_255.bin"), "rb").read()
    base = 0x682A0
    frames = list(d[0x6A222 - base:0x6A222 - base + ELAN_TICKS])
    xs = struct.unpack(">24h", d[0x6A1CE - base:0x6A1CE - base + 48])
    ys = struct.unpack(">24h", d[0x6A1F8 - base:0x6A1F8 - base + 48])
    return frames, [16 * x for x in xs], [255 - y for y in ys]


def intro_car(k: int):
    import json
    img, rgb = load_sc("d2_084")
    L3d = os.path.join(ROOT, "extract", "l3")
    fr = json.load(open(os.path.join(L3d, "d2_086.frames")))
    pl = open(os.path.join(L3d, "d2_086.bin"), "rb").read()
    o, w, h, n, _nib = fr[k]
    wb = ((w + 15) // 16) * 2
    bpp = wb * h
    d = pl[o:o + n * bpp]
    _frames, xs, ys = elan_tables()
    x0, y0 = xs[k], ys[k]
    for y in range(h):
        for x in range(w):
            v = sum(((d[p * bpp + y * wb + x // 8] >> (7 - (x & 7))) & 1) << p for p in range(n))
            X, Y = x0 + x, y0 + y
            if 0 <= X < 320 and 0 <= Y < 200:
                img[FE_Y + Y][X] = (v >> 1) | ((v & 1) << 4)
    return img, rgb, set()


def intro_car_ticks() -> list[int]:
    """Tick de la 1re apparition des images 0-23 (Elan, capot, ecussons)."""
    frames, _xs, _ys = elan_tables()
    return [ELAN_T0 + frames.index(k) for k in range(INTRO_CAR_FRAMES + 3)]


# Zoom du « MF » (ecran Magnetic Fields, $6A4B6) : d1_002 = 20 images d'un plan
# (8000 octets, 320 x 200), affichees en 1 plan ($74214, d0 = 1) une tous les 2
# ticks de 50 a 89 ; avant 50, aucun plan (noir) ; a 90 l'image d1_003 (3 plans,
# meme palette : couleur 1 = $FFF) et le jingle.
MF_ZOOM_FRAMES = 20


def mf_zoom(k: int):
    d = open(os.path.join(ROOT, "extract", "l3", "d1_002.bin"), "rb").read()[k * 8000:(k + 1) * 8000]
    _img, rgb = load_sc("d1_003")
    img = [[0] * 320 for _ in range(FE_ROWS * 16)]
    for y in range(min(200, FE_ROWS * 16 - FE_Y)):
        for x in range(320):
            img[FE_Y + y][x] = (d[y * 40 + x // 8] >> (7 - (x & 7))) & 1
    return img, rgb[:2], set()


def intro_badge_fade():
    """Ecusson sur fond vert : la couleur du fond est marquee (fondu au noir)."""
    img, rgb = load_sc("d2_083")
    bg = img[FE_Y][0]
    rgb = rgb + [rgb[bg]]
    v = len(rgb) - 1
    for row in img[FE_Y:FE_Y + 200]:
        for x in range(320):
            if row[x] == bg:
                row[x] = v
    return img, rgb, {v}


def title_stage(k):
    """Titre : k = 0..3 (LOTUS, I, II, III sans sous-titre) ; None = complet,
    sous-titre marque (fondu)."""
    img, rgb = load_sc("d1_023")
    marked = set()
    n = len(rgb)
    for y in range(200):
        row = img[FE_Y + y]
        for x in range(320):
            if k is not None and (y >= TITLE_SUB_Y or x >= TITLE_STAGES[k]):
                row[x] = 0
            elif k is None and y >= TITLE_SUB_Y and row[x]:
                row[x] += n
                marked.add(row[x])
        if k is not None and TITLE_SHIFT[k]:
            s = TITLE_SHIFT[k]
            row[:] = [0] * s + row[:320 - s] + row[320:]
    if k is None:
        rgb = rgb + rgb
    return img, rgb, marked


def panel(header: int, banner: int, preview: int | None = None):
    """Ecran du menu de Lotus III ($74586) : fond d1_018, titre header de d1_013
    (7 titres 160 x 21 a 2 plans : GAME OVER, HIGH SCORES, CURRENT SCORES,
    CHAMPIONSHIP TABLE, WELL DONE!, RACE RESULTS, NEXT RACE) en (80, 15), bandeau
    d1_0<banner> (19 = championnat, 20 = arcade ; 320 x 50, couleur 31 =
    transparente, $74642) ; NEXT RACE ($746D0) : apercu 160 x 100 du decor
    d2_0(28 + decor) en (80, 50). Chaque calque garde sa palette (le jeu change
    de palette par le copper)."""
    img, rgb = load_sc("d1_018")
    L3d = os.path.join(ROOT, "extract", "l3")
    d13 = open(os.path.join(L3d, "d1_013.bin"), "rb").read()
    for y in range(21):
        for x in range(160):
            o, b = header * 420 + y * 20 + x // 8, 7 - (x & 7)
            p0, p1 = (d13[o] >> b) & 1, (d13[2940 + o] >> b) & 1
            # $745FC : (0, 1) = transparent (le fond reste), sinon couleur
            # p0 | p1 << 1 (0 = noir : le liseré des lettres)
            if not (p1 and not p0):
                img[FE_Y + 15 + y][80 + x] = p0 | (p1 << 1)

    def planar_file(name, w, h):
        raw = open(os.path.join(L3d, f"{name}.bin"), "rb").read()
        pal = open(os.path.join(L3d, f"{name}.pal"), "rb").read()
        wb, ps = w // 8, (w // 8) * h
        px = [[sum(((raw[k * ps + y * wb + x // 8] >> (7 - (x & 7))) & 1) << k for k in range(5))
               for x in range(w)] for y in range(h)]
        return px, [amiga_rgb(int.from_bytes(pal[i:i + 2], "big")) for i in range(0, 64, 2)]

    bpx, brgb = planar_file(f"d1_{banner:03d}", 320, 50)
    base = len(rgb)
    rgb = rgb + brgb
    for y in range(50):
        for x in range(320):
            if bpx[y][x] != 31:
                img[FE_Y + y][x] = base + bpx[y][x]
    if preview is not None:
        ppx, prgb = planar_file(f"d2_{28 + preview:03d}", 160, 100)
        base = len(rgb)
        rgb = rgb + prgb
        for y in range(100):
            for x in range(160):
                img[FE_Y + 50 + y][80 + x] = base + ppx[y][x]
    # l'index 0 est transparent pour build_screen : couleurs 0 des calques -> noir
    for row in img:
        for i, v in enumerate(row):
            if v and rgb[v] == rgb[0]:
                row[i] = 0
    return img, rgb, set()


PANEL_SCREENS = ([("hiscore_c", lambda: panel(1, 19)), ("hiscore_a", lambda: panel(1, 20)),
                  ("gameover_c", lambda: panel(0, 19)), ("gameover_a", lambda: panel(0, 20)),
                  ("welldone", lambda: panel(4, 19)),
                  ("results_c", lambda: panel(5, 19)), ("results_a", lambda: panel(5, 20)),
                  ("table_c", lambda: panel(3, 19))]
                 + [(f"next{d}_{m}", (lambda d=d, b=b: panel(6, b, d)))
                    for m, b in (("c", 19), ("a", 20)) for d in range(13)])

FE_SCREENS = ([("gremlin", "d1_000"), ("magnetic", "d1_003"), ("title", lambda: title_stage(None)),
               ("car0", "d2_010"), ("car1", "d2_011"), ("car2", "d2_012"), ("track", "d1_021"),
               ("results", "d1_018"), ("iroad", "d2_084")]
              + [(f"icred{k}", (lambda k=k: intro_credit(k))) for k in range(4)]
              + [(f"icar{k}", (lambda k=k: intro_car(k))) for k in range(INTRO_CAR_FRAMES)]
              + [("ibonnet", "d2_081"), ("ibadge1", "d2_082"), ("ibadge2", intro_badge_fade)]
              + [(f"ititle{k}", (lambda k=k: title_stage(k))) for k in range(4)]
              + [(f"mfz{k}", (lambda k=k: mf_zoom(k))) for k in range(MF_ZOOM_FRAMES)]
              + PANEL_SCREENS)


# Menu principal de Lotus III (capture WinUAE docs/ref/l3_menu_principal.png) :
# boutons de d1_015 (SA 6 plans : plan 0 = masque, index 1 transparent, couleur
# = index >> 1 dans la palette de d1_018, le fond du menu), grille 3 x 5.
# (nom, images de d1_015 par etat, x, y Amiga)
MENU_ITEMS = [
    ("player1", [0], 0, 5), ("start", [21], 112, 5), ("player2", [14], 208, 5),
    ("gears1", [3, 4], 0, 44), ("game", [7, 8], 112, 44), ("gears2", [3, 4], 208, 44),
    ("accel1", [1, 2], 0, 83), ("course", [25, 26, 27, 28, 29], 96, 83), ("accel2", [1, 2], 208, 83),
    ("control1", [19], 0, 122), ("players", [5, 6], 112, 122), ("control2", [15, 16], 208, 122),
    ("recs", [20], 0, 161), ("code", [13], 112, 161), ("define", [17], 208, 161),
]
MENU_ROWS = 3   # tuiles de haut par bouton (34-42 lignes)
# Constructeur RECS (meme grille, boutons 15-29 des tables $70652-$70792, images
# de d1_016) : TYPE (circuit / sprint), EXIT, CODE, reglages en pourcentage,
# barre SCENARIO (13 decors) sur toute la largeur
RECS_ITEMS = [
    ("type", [2, 3], 0, 5), ("exit", [4], 112, 5), ("rcode", [5], 208, 5),
    ("curves", [6], 0, 44), ("hills", [7], 112, 44), ("scenery", [8], 208, 44),
    ("sharp", [9], 0, 83), ("steep", [10], 112, 83), ("scatter", [11], 208, 83),
    ("length", [12], 0, 122), ("diff", [13], 112, 122), ("obst", [14], 208, 122),
    ("scenario", [16], 0, 161),
]


def pack_images(tiles: TileBank, images, rgb):
    """Images (index de couleur, -1 = transparent ; largeur et hauteur multiples
    de 16) -> par image : tuiles colonne par colonne et palette relative de
    chaque tuile ; palettes communes de 15 couleurs (index 1-15)."""
    from collections import Counter
    cells = []
    for n, img in enumerate(images):
        h, w = len(img), len(img[0])
        for c in range(w // 16):
            for t in range(h // 16):
                px = [img[t * 16 + y][c * 16 + x] for y in range(16) for x in range(16)]
                cs = set(v for v in px if v >= 0)
                cells.append((n, c, t, px, cs))
    pals: list[set] = []
    assign = {}
    for i, (n, c, t, px, cs) in sorted(enumerate(cells), key=lambda e: -len(e[1][4])):
        if len(cs) > 15:
            keep = [v for v, _ in Counter(v for v in px if v >= 0).most_common(15)]
            cs = set(keep)
        best = None
        for j, ps in enumerate(pals):
            u = len(ps | cs)
            if u <= 15 and (best is None or u - len(ps) < best[1]):
                best = (j, u - len(ps))
        if best is None:
            pals.append(set(cs))
            best = (len(pals) - 1, 0)
        pals[best[0]] |= cs
        assign[i] = best[0]
    order = [sorted(ps) for ps in pals]

    def dist(a, b):
        return sum((x - y) ** 2 for x, y in zip(rgb[a], rgb[b]))

    out = [([], []) for _ in images]
    for i, (n, c, t, px, cs) in enumerate(cells):
        pi = assign[i]
        idx = {v: order[pi].index(v) + 1 for v in order[pi]}
        q = [0 if v < 0 else idx.get(v) or idx[min(order[pi], key=lambda k: dist(v, k))] for v in px]
        out[n][0].append(tiles.add(q))
        out[n][1].append(pi)
    neo_pals = [[0x8000] + [neo_color(rgb[v]) for v in o] + [0] * (15 - len(o)) for o in order]
    return out, neo_pals


def build_menu(tiles: TileBank):
    import json
    L3d = os.path.join(ROOT, "extract", "l3")
    sheets = {n: (json.load(open(os.path.join(L3d, f"{n}.frames"))), open(os.path.join(L3d, f"{n}.bin"), "rb").read())
              for n in ("d1_015", "d1_016")}
    p = open(os.path.join(L3d, "d1_018.pal"), "rb").read()
    rgb = [amiga_rgb(int.from_bytes(p[i:i + 2], "big")) for i in range(0, 64, 2)]
    rgb += [(0xAA, 0, 0)]                        # 32 : rouge du cadre de selection
    H = MENU_ROWS * 16

    def frame(k, sheet="d1_015", full=False):
        fr, pl = sheets[sheet]
        o, w, h, n, _ = fr[k]
        wb = ((w + 15) // 16) * 2
        bpp = wb * h
        d = pl[o:o + n * bpp]
        img = [[-1] * w for _ in range(h if full else H)]
        for y in range(h):
            for x in range(w):
                v = sum(((d[q * bpp + y * wb + x // 8] >> (7 - (x & 7))) & 1) << q for q in range(n))
                img[y][x] = -1 if v == 1 else v >> 1
        return img

    images, meta = [], []
    for sheet, name, ks, x, y in ([("d1_015",) + it for it in MENU_ITEMS] +
                                  [("d1_016",) + it for it in RECS_ITEMS]):
        first = len(images)
        for k in ks:
            images.append(frame(k, sheet))
        # cadre : 1 px rouge borde de noir, 4 px autour de l'image visible
        img = images[first]
        xs = [i for row in img for i, v in enumerate(row) if v >= 0]
        ys = [j for j, row in enumerate(img) if any(v >= 0 for v in row)]
        x0, x1, y0, y1 = min(xs) - 4, max(xs) + 4, min(ys) - 3, max(ys) + 2
        hx, hy = x + x0 - 1, y + y0 - 1          # origine du cadre (avec le noir)
        W, Hh = x1 - x0 + 3, y1 - y0 + 3
        Wp, Hp = (W + 15) // 16 * 16, (Hh + 15) // 16 * 16
        fr_img = [[-1] * Wp for _ in range(Hp)]
        for j in range(Hh):
            for i in range(W):
                edge = min(i, j, W - 1 - i, Hh - 1 - j)
                if edge == 1:
                    fr_img[j][i] = 32
                elif edge in (0, 2):
                    fr_img[j][i] = 0
        meta.append({"name": name, "x": x, "y": y, "cols": len(img[0]) // 16, "first": first,
                     "n": len(ks), "hl": fr_img, "hx": hx, "hy": hy})
    hl_first = len(images)
    for m in meta:
        images.append(m["hl"])
    # Constructeur RECS ($7139A) : rampe de 96 x 22 (image 30 : 2 rampes x 27
    # etats x 2 lignes : bord, puis motif repete 20 fois), pourcentage 32 x 9
    # (image 31, 27 valeurs) ; chiffres 16 x 17 de la difficulte (image 32)
    global RECS_RAMP0, RECS_PCT0, RECS_DIG0
    f30, f31, f32 = (frame(k, "d1_016", True) for k in (30, 31, 32))
    RECS_RAMP0 = len(images)
    for r in range(2):
        for st in range(27):
            e, m_ = f30[(r * 27 + st) * 2], f30[(r * 27 + st) * 2 + 1]
            img = [list(e)] + [list(m_) for _ in range(20)] + [list(e)]
            images.append(img + [[-1] * 96 for _ in range(32 - 22)])
    RECS_PCT0 = len(images)
    for v in range(27):
        img = [list(f31[v * 9 + y]) for y in range(9)]
        images.append(img + [[-1] * 32 for _ in range(16 - 9)])
    RECS_DIG0 = len(images)
    for v in range(10):
        img = [list(f32[v * 17 + y]) if v * 17 + y < len(f32) else [-1] * 16 for y in range(17)]
        images.append(img + [[-1] * 16 for _ in range(32 - 17)])
    packed, pals = pack_images(tiles, images, rgb)
    # SCENARIO : centre de chaque icone dans la barre (image 16, mesure sur
    # l'image ; scenario k = decor $6ECA6[k] : rally, futureworld, night...)
    scen = [17, 42, 67, 85, 112, 135, 158, 183, 208, 230, 253, 278, 302]
    global RECS_SCEN_X
    RECS_SCEN_X = scen
    print("  RECS : icones des decors en x =", scen)
    return meta, packed, pals, hl_first


def build_screen(tiles: TileBank, spec):
    """(tuiles colonne par colonne, palette relative de chaque tuile, palettes
    Neo, couleur de fond). L'index 0 est le fond (transparent). spec = nom de
    fichier SC ou fonction -> (image, couleurs, index marques) ; une couleur
    marquee porte le bit 15 (fondu a part, cf. fe_fade de main.c)."""
    if callable(spec):
        img, rgb, marked = spec()
    else:
        img, rgb = load_sc(spec)
        marked = set()

    def dist(a, b):
        return sum((x - y) ** 2 for x, y in zip(rgb[a], rgb[b]))

    # couleurs de chaque tuile (15 au plus : les plus rares remplacees)
    cells = []
    for c in range(FE_COLS):
        for t in range(FE_ROWS):
            from collections import Counter
            cnt = Counter(img[t * 16 + y][c * 16 + x] for y in range(16) for x in range(16))
            cnt.pop(0, None)
            keep = [v for v, _ in cnt.most_common(15)]
            sub = {v: (v if v in keep else min(keep, key=lambda k: dist(v, k))) for v in cnt}
            cells.append((c, t, set(keep), sub))
    # palettes : tuiles les plus colorees d'abord, union de 15 couleurs au plus
    pals: list[set] = []
    assign = {}
    for c, t, cs, _ in sorted(cells, key=lambda e: -len(e[2])):
        best = None
        for i, ps in enumerate(pals):
            u = len(ps | cs)
            if u <= 15 and (best is None or u - len(ps) < best[1]):
                best = (i, u - len(ps))
        if best is None:
            pals.append(set(cs))
            best = (len(pals) - 1, 0)
        pals[best[0]] |= cs
        assign[(c, t)] = best[0]
    order = [sorted(ps) for ps in pals]
    cols, attrs = [], []
    for c, t, cs, sub in cells:
        pi = assign[(c, t)]
        idx = {v: order[pi].index(v) + 1 for v in order[pi]}
        px = []
        for y in range(16):
            for x in range(16):
                v = img[t * 16 + y][c * 16 + x]
                px.append(idx[sub[v]] if v else 0)
        cols.append(tiles.add(px))
        attrs.append(pi)
    neo_pals = [[0x8000] + [neo_color(rgb[v]) | (0x8000 if v in marked else 0) for v in o]
                + [0] * (15 - len(o)) for o in order]
    build_screen.last = (order, rgb)
    return cols, attrs, neo_pals, neo_color(rgb[0])


# Ecran « Select a car » ($709AA) : la petite voiture de l'encadre tourne sur
# elle-meme. d2_006 / 007 / 008 (voiture 0 / 1 / 2) : 16 images de 96 x 24
# (5 plans de $1200 octets, 12 octets par ligne), image (compteur >> 2) & 15
# a chaque trame, copiee a l'octet 4010 de l'ecran : x 80, y 100 (+ FE_Y).
CAR_ANIM_C0, CAR_ANIM_COLS, CAR_ANIM_R0, CAR_ANIM_ROWS = 5, 6, 7, 2


def build_car_anim(tiles: TileBank, k: int, order, rgb, img):
    """-> (tuiles, palettes relatives) : 16 images x 12 tuiles (colonne par
    colonne), fond de l'ecran autour, palettes de l'ecran (la plus proche)."""
    planes = open(os.path.join(ROOT, "extract", "l3", f"d2_{6 + k:03d}.bin"), "rb").read()
    ps, wb = 0x1200, 12

    def dist(a, b):
        return sum((x - y) ** 2 for x, y in zip(rgb[a], rgb[b]))

    out_t, out_a = [], []
    for f in range(16):
        var = [list(r) for r in img]
        for y in range(24):
            for xb in range(wb):
                o = (f * 24 + y) * wb + xb
                bs = [planes[i * ps + o] if i * ps + o < len(planes) else 0 for i in range(5)]
                for b in range(8):
                    var[FE_Y + 100 + y][80 + xb * 8 + b] = sum(((bs[i] >> (7 - b)) & 1) << i for i in range(5))
        for c in range(CAR_ANIM_C0, CAR_ANIM_C0 + CAR_ANIM_COLS):
            for t in range(CAR_ANIM_R0, CAR_ANIM_R0 + CAR_ANIM_ROWS):
                vals = [var[t * 16 + y][c * 16 + x] for y in range(16) for x in range(16)]
                best = None
                for pi, o in enumerate(order):
                    err = sum(min(dist(v, w) for w in o) for v in set(vals) if v)
                    if best is None or err < best[0]:
                        best = (err, pi)
                o = order[best[1]]
                near = {v: o.index(min(o, key=lambda w: dist(v, w))) + 1 for v in set(vals) if v}
                out_t.append(tiles.add([near[v] if v else 0 for v in vals]))
                out_a.append(best[1])
    return out_t, out_a


CP_MAX = 15   # cases de la jauge des points de controle (table $77C44)


# HUD de Lotus III (couche fix, palette HUD_PAL) : planche d1_025 (chiffres 8 x 8,
# chiffres 16 x 16, paves 1ST-5TH, barre de regime en 46 etats) et panneau
# d1_014 (« . KMH . », cadre de la barre), dessines par $77A00-$77F44.
# Index de couleur du jeu : 8 noir, 11 rouge fonce, 13 blanc, 15 rouge vif.
HUD_TILE0 = 0x500
HUD_PAL_RGB = {8: (0, 0, 0), 11: (0x66, 0, 0), 13: (0xCC, 0xCC, 0xCC), 15: (0xAA, 0, 0)}


def fix_tile(px) -> bytes:
    """Tuile fix 8 x 8 (px[y][x], 4 bits) -> 32 octets de la ROM S."""
    out = bytearray(32)
    for g, x0 in ((0x10, 0), (0x18, 2), (0x00, 4), (0x08, 6)):
        for y in range(8):
            out[g + y] = (px[y][x0] & 15) | ((px[y][x0 + 1] & 15) << 4)
    return bytes(out)


def build_hud():
    """-> (tuiles 8 x 8, dictionnaire des index / tables pour road_data)."""
    d25 = open(os.path.join(ROOT, "extract", "l3", "d1_025.bin"), "rb").read()
    d14 = open(os.path.join(ROOT, "extract", "l3", "d1_014.bin"), "rb").read()

    def planar(d, off, wb, h, ps, rowb=None):
        rowb = wb if rowb is None else rowb
        img = [[sum(((d[off + k * ps + y * rowb + xb] >> (7 - b)) & 1) << k for k in range(4))
                for xb in range(wb) for b in range(8)] for y in range(h)]
        return [[0 if v == 9 else v for v in row] for row in img]   # 9 : halo = fond

    tiles, index = [], {}

    def add(px):
        key = tuple(tuple(r) for r in px)
        if key not in index:
            index[key] = HUD_TILE0 + len(tiles)
            tiles.append(key)
        return index[key]

    def cut(img, w, h):
        """image -> indices de tuiles, ligne par ligne"""
        img = [row + [0] * (w - len(row)) for row in img] + [[0] * w] * (h - len(img))
        return [add([img[ty * 8 + y][tx * 8:tx * 8 + 8] for y in range(8)])
                for ty in range(h // 8) for tx in range(w // 8)]

    blank = add([[0] * 8] * 8)
    small = [cut(planar(d25, i * 8, 1, 8, 80), 8, 8)[0] for i in range(10)]
    big = [cut(planar(d25, 320 + i * 32, 2, 16, 320), 16, 16) for i in range(10)]
    pos = [cut(planar(d25, 1600 + i * 64, 4, 16, 320), 32, 16) for i in range(5)]
    kmh = cut([row[24:64] for row in planar(d14, 0, 8, 8, 64)], 40, 8)
    box = planar(d14, 0x200, 6, 13, 78)
    bar = []
    for f in range(46):
        fill = planar(d25, 2880 + f * 6, 6, 1, 834, 0)[0]
        img = [list(r) for r in box]
        for y in range(1, 12):
            for x in range(48):
                if fill[x]:
                    img[y][x] = fill[x]
        bar.append(cut(img, 48, 16))
    # jauge : cases de 4 lignes (trait noir + 3 lignes), 2 cases par tuile ;
    # remplissage rouge vif de 0 a 14 px, cote gauche (x 1-7) ou droit (x 0-6)
    gauge = []
    for side in (0, 1):
        for up in range(8):
            for low in range(9):            # 8 : pas de seconde case
                px = [[0] * 8 for _ in range(8)]
                for y in range(8):
                    st = up if y < 4 else low
                    if st == 8 and y > 4:
                        continue
                    edge = 0 if side == 0 else 7
                    if y in (0, 4):
                        px[y] = [8] * 8
                        continue
                    px[y][edge] = 8
                    for i in range(st):
                        px[y][(1 + i) if side == 0 else i] = 15
                gauge.append(add(px))
    gauge_end = [add([[8] * 8] + [[0] * 8] * 7), add([[8] * 8] + [[0] * 8] * 7)]
    # neige / pluie ($7AA5E) sur la couche fix : un flocon (2 x 2) ou une goutte
    # (1 x 4) a chacune des 64 positions d'une tuile, couleur 14 (fixee par le
    # jeu selon le decor) ; tuiles contigues (pas de deduplication)
    flake0 = HUD_TILE0 + len(tiles)
    for kind in (0, 1):
        for p in range(64):
            px0, py0 = p & 7, p >> 3
            px = [[0] * 8 for _ in range(8)]
            for dy in range(2 if kind == 0 else 4):
                for dx in range(2 if kind == 0 else 1):
                    if px0 + dx < 8 and py0 + dy < 8:
                        px[py0 + dy][px0 + dx] = 14
            tiles.append(tuple(tuple(r) for r in px))
    # bandeaux de messages ($79F5A : d1_014 + $7E0, 168 octets x 9 lignes, masque
    # en +3024, plans en +0 et +1512) : OUT OF TIME, CHECKPOINT, PAUSED... ;
    # 2 tuiles fix par colonne de 8 px (lignes 0-7 puis 8-9) ; tuiles contigues
    msg0 = HUD_TILE0 + len(tiles)
    # le masque d'origine laisse voir le fond (couleur 0 sur Amiga) : lettres
    # blanches avec une ombre d'1 px en bas a droite, sans pave
    def mpx(x, y):
        if not (0 <= x < 168 * 8 and 0 <= y < 9):
            return 0
        o = 0x7E0 + y * 168 + x // 8
        return ((d14[o] >> (7 - (x & 7))) & 1) | ((d14[o + 1512] >> (7 - (x & 7))) & 1)
    for col in range(168):
        for tr in range(2):
            px = [[0] * 8 for _ in range(8)]
            for y in range(8):
                yy = tr * 8 + y
                if yy >= 10:
                    continue
                for x in range(8):
                    xx = col * 8 + x
                    if mpx(xx, yy):
                        px[y][x] = 13
                    elif mpx(xx - 1, yy - 1) or mpx(xx - 1, yy) or mpx(xx, yy - 1):
                        px[y][x] = 8   # ombre portee d'1 px (lisible sur un ciel clair)
            tiles.append(tuple(tuple(r) for r in px))
    info = {"msg0": msg0, "flake0": flake0, "blank": blank, "small": small, "big": big, "pos": pos, "kmh": kmh, "bar": bar,
            "gauge": gauge, "gauge_end": gauge_end[0]}
    return tiles, info


# Vignette du HUD ($79976 / $79A52) : d1_026 = 15 images de 48 x 64 a 3 plans
# (drapeau vert « GO! » qui se deroule 0-6, drapeau a damier 7-12, « NOW
# RE-FUELING » 13-14). Couleurs 0-7 de l'ecran de course (copper) non relevees :
# palette approchee.
FLAG_RGB = [0x000, 0xEEE, 0xC00, 0x080, 0x444, 0xEE0, 0x5AE, 0x888]


def build_flags(tiles: TileBank):
    d = open(os.path.join(ROOT, "extract", "l3", "d1_026.bin"), "rb").read()
    ps = 0x1680
    out = []
    for k in range(15):
        img = [[sum(((d[q * ps + k * 384 + y * 6 + x // 8] >> (7 - (x & 7))) & 1) << q for q in range(3))
                for x in range(48)] for y in range(64)]
        cols = []
        for c in range(3):
            for t in range(4):
                cols.append(tiles.add([img[t * 16 + y][c * 16 + x] + 1 for y in range(16) for x in range(16)]))
        out.append(cols)
    pal = [0x8000] + [neo_color(amiga_rgb(v)) for v in FLAG_RGB] + [0] * 7
    return out, pal


def write_s1(tiles, path):
    """S1 = sfix du BIOS (police ASCII de ng_text) + tuiles du HUD en HUD_TILE0."""
    sfix = os.environ.get("LN_SFIX", r"C:\MAME\roms\neogeo\sfix.sfix")
    rom = bytearray(open(sfix, "rb").read())
    # police systeme (ng_text, tuiles $20-$7F) : fond (couleur 2) transparent,
    # sauf une ombre d'1 px en bas a droite des lettres (couleur 1)
    for t in range(0x20, 0x80):
        b = rom[t * 32:t * 32 + 32]
        px = [[0] * 8 for _ in range(8)]
        for g, x0 in ((0x10, 0), (0x18, 2), (0x00, 4), (0x08, 6)):
            for y in range(8):
                px[y][x0], px[y][x0 + 1] = b[g + y] & 15, b[g + y] >> 4
        out = [[0] * 8 for _ in range(8)]
        for y in range(8):
            for x in range(8):
                if px[y][x] == 1:
                    out[y][x] = 1
                elif px[y][x] == 2 and any(0 <= y - dy < 8 and 0 <= x - dx < 8 and px[y - dy][x - dx] == 1
                                           for dx, dy in ((1, 1), (1, 0), (0, 1))):
                    out[y][x] = 2   # ombre portee d'1 px en bas a droite
                else:
                    out[y][x] = px[y][x] if px[y][x] not in (1, 2) else 0
        rom[t * 32:t * 32 + 32] = fix_tile(out)
    for i, t in enumerate(tiles):
        o = (HUD_TILE0 + i) * 32
        rom[o:o + 32] = fix_tile(t)
    open(path, "wb").write(rom)


def build_track(code: str):
    """(virages, relief, segments bruts 16 octets, decor) d'un circuit RECS. Le
    decor est celui que le generateur ecrit en a3+1066 ($7216E) : la table $6ECA6
    indexee par p0 >> 1 se trompe pour plusieurs circuits (fog, roadworks…)."""
    import recs
    rc = recs.Recs()
    trk = rc.generate(code)
    trk = trk[:16 * rc.length()]
    path = os.path.join(ROOT, "extract", "l3", "recs", f"{code}.bin")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "wb").write(trk)
    segs = lotus2_track.load16(path)
    # points de controle ($7341E, appele par le generateur) : a3+1064 = 1 pour
    # un circuit a n tours (a3+1052), 0 pour un sprint a n troncons ; positions
    # (segments) en a3+16006, temps alloues (s) en a3+16038
    n = min(rc.word(recs.A3 + 1052), CP_MAX)
    lapmode = 1 if rc.word(recs.A3 + 1064) else 0
    cps = [rc.word(recs.A3 + 16006 + 2 * i) for i in range(n + 1)]
    cpt = [rc.word(recs.A3 + 16038 + 2 * i) for i in range(n)]
    trk_info = {"lapmode": lapmode, "ncp": n, "cp": cps, "cpt": cpt}
    return [s["curve"] for s in segs], [s["hill"] for s in segs], trk, rc.word(recs.A3 + 1066), trk_info


MAIN_BASE = 0x682A0
SCREEN_H = 224
HORIZON = int(os.environ.get("LN_HORIZON", 163))  # ligne d'horizon (Lotus III : 73 % de la hauteur)
# Echelle du bas d'ecran (= CAM_H de main.c) : le jeu y est a l'echelle 4096 (image 0
# des objets a 100 %, route de 4 x largeur px de demi-largeur, octet lateral x 16 px)
CAM_H = 500
SC_BOT = (SCREEN_H - 1 - HORIZON) * 4096 / CAM_H     # echelle Neo du bas d'ecran
SCALE_REF = round(1400 * SC_BOT / 4096)              # ROAD_HW (1400) en px au bas d'ecran
OBJ_X_K = round(16 * 4096 / SC_BOT)                  # octet lateral -> monde
SCREEN_H = 224
PANO_W = 640


def main_words(addr: int, n: int) -> list[int]:
    m = open(os.path.join(ROOT, "extract", "l3_d1_255.bin"), "rb").read()
    o = addr - MAIN_BASE
    return [int.from_bytes(m[o + 2 * i:o + 2 * i + 2], "big") for i in range(n)]


def amiga_rgb(c: int) -> tuple[int, int, int]:
    return (((c >> 8) & 15) * 17, ((c >> 4) & 15) * 17, (c & 15) * 17)


def decor_colors(decor: int) -> dict:
    """Couleurs d'un decor Lotus III (cf. docs/amiga_notes.md, « Decor ») :
    - $6B3B4 + 64 * idx : entrees de 4 mots par ligne (herbe, route, marquage),
      0 / 1 = phases A / B ; idx = decor sauf 1 -> 22, 2 -> 13, 3 -> 31, 7 -> 40 ;
    - $6B174 : degrade de ciel, 24 couleurs lues a rebours (bloc du decor d en
      $6B174 + 48 (d - 1)), precedees de 50 lignes de la 1re couleur ;
    - $6AFA4 + 32 * decor : palette du panorama d2_(41 + decor) ; les index 0
      et 12 laissent voir le ciel (couleurs du copper)."""
    idx = {1: 22, 2: 13, 3: 31, 7: 40}.get(decor, decor)
    t = main_words(0x6B3B4 + 64 * idx, 32)
    grass = (t[0], t[4])
    road = (t[1], t[5])
    line = (t[2], t[6])
    mountain = decor == 12
    if mountain:
        # mountain (a3+1258) : tables de coupe remplies de 1 ($75084, $75176),
        # plans permutes : le vide hors route prend l'encre « route » ($CCC
        # uni), la chaussee l'encre « marquage » ($343 / $454), le marquage
        # l'encre « herbe » ($EEE / $454) ; releve sous WinUAE (sfxuxxxxp)
        grass, road, line = road, line, grass
    grad = main_words(0x6B174 + 48 * (decor - 1), 24)
    # $F0F = marqueur « couleur remplacee » (futureworld : 4 lignes au ras de
    # l'horizon, cachees par le panorama en 1 joueur) : couleur precedente
    for i in range(1, len(grad)):
        if grad[i] == 0xF0F:
            grad[i] = grad[i - 1]
    sky74 = [grad[0]] * 50 + grad
    pano_pal = main_words(0x6AFA4 + 32 * decor, 16)
    start = (t[25], t[26], t[29], t[30])   # entrees 6 / 7 : route, marquage
    # entrees 2 / 3 et 4 / 5 : surfaces 1 (tunnel, eau...) et 2 (turbo) du
    # quart de segment ; le copper de $78746 change herbe, route et marquage
    # a chaque ligne (entree x 8). Entree vide (000 partout) : surface normale.
    surf = []
    for e in (0, 2, 4):
        a, b = t[4 * e:4 * e + 3], t[4 * e + 4:4 * e + 7]
        if not any(a) and not any(b):
            a, b = t[0:3], t[4:7]
        surf.append((a, b))
    if mountain:
        surf = [((a[1], a[2], a[0]), (b[1], b[2], b[0])) for a, b in surf]
        start = (start[1], t[24], start[3], t[28])
    return {"grass": grass, "road": road, "line": line, "sky74": sky74, "pano_pal": pano_pal,
            "start": start, "surf": surf}


def build_pano(tiles: "TileBank", decor: int) -> tuple[list[list[int]], int]:
    """Panorama d'horizon d2_(41 + decor) : SP 4 plans, 640 px de large ;
    colonnes de 16 px (une par sprite), bas cale sur le bas de la derniere tuile."""
    name = f"d2_{41 + decor:03d}"
    entry = next(l for l in open(os.path.join(ROOT, "extract", "l3", "index.txt"), encoding="utf-8")
                 if l.startswith(name + " "))
    psize = int(entry.split()[8], 16)
    planes = open(os.path.join(ROOT, "extract", "l3", f"{name}.bin"), "rb").read()
    wb = PANO_W // 8
    h = psize // wb
    rows = (h + 15) // 16
    pad = rows * 16 - h          # lignes transparentes en haut
    px = [[0] * PANO_W for _ in range(rows * 16)]
    for y in range(h):
        for xb in range(wb):
            bs = [planes[k * psize + y * wb + xb] for k in range(4)]
            for b in range(8):
                v = sum(((bs[k] >> (7 - b)) & 1) << k for k in range(4))
                px[pad + y][xb * 8 + b] = 0 if v in (0, 12) else v
    cols = []
    for c in range(PANO_W // 16):
        col = []
        for t in range(rows):
            col.append(tiles.add([px[t * 16 + y][c * 16 + x] for y in range(16) for x in range(16)]))
        cols.append(col)
    return cols, h


def c_array(ctype: str, name: str, vals: list[int], per: int = 16) -> str:
    lines = []
    for i in range(0, len(vals), per):
        lines.append("    " + ", ".join(str(v) for v in vals[i:i + per]) + ",")
    return f"const {ctype} {name}[{len(vals)}] = {{\n" + "\n".join(lines) + "\n};\n"


def driver_names(n: int) -> list[str]:
    """Pilotes de Lotus III (noms parodiques, 18 x 20 caracteres en $6A8B4)."""
    m = open(os.path.join(ROOT, "extract", "l3_d1_255.bin"), "rb").read()
    o = 0x6A8B4 - MAIN_BASE
    return [m[o + 20 * i:o + 20 * i + 20].decode("latin1").strip().upper() for i in range(n)]


RECS_MAX = 1040      # segments max d'un circuit RECS (1024 + 16)

DECOR_NAMES = ["FOREST", "NIGHT", "FOG", "SNOW", "DESERT", "MOTORWAY", "MARSH", "STORM",
               "ROADWORKS", "RALLY", "WIND", "FUTUREWORLD", "MOUNTAIN"]
ROAD_STYLES = ["lanes", "checker", "fog", "fog_night", "fog_storm"]


def championship_codes(first: int, count: int) -> list[str]:
    """Codes RECS du championnat (table de 64 x 12 octets en $6AAE0)."""
    m = open(os.path.join(ROOT, "extract", "l3_d1_255.bin"), "rb").read()
    o = 0x6AAE0 - MAIN_BASE
    return [m[o + 12 * i:o + 12 * i + 12].split(b"\0")[0].decode() for i in range(first, first + count)]


def main() -> int:
    """Circuits : argv (codes RECS) ou LN_TRACKS, sinon les 7 courses du niveau 1
    du championnat (un decor different chacune)."""
    codes = sys.argv[1:] or (os.environ["LN_TRACKS"].split(",") if os.environ.get("LN_TRACKS")
                            else championship_codes(0, 7))
    os.makedirs(BUILD, exist_ok=True)
    tiles = TileBank()
    import build_objects
    tracks = []
    for code in codes:
        curve, hill, raw, decor, info = build_track(code)
        tracks.append({"code": code, "curve": curve, "hill": hill, "raw": raw, "info": info,
                       "decor": decor})
    # les 13 decors (un code RECS saisi en jeu peut tomber sur n'importe lequel) ;
    # index = numero du decor Lotus III
    decors = list(range(13))
    global FOG_HW
    FOG_HW = 4 * main_words(0x6C028, 13)[2] * 4096 / SC_BOT
    for st, dd in FADE_STYLE_DECOR.items():
        FOG_HWS[st] = 4 * main_words(0x6C028, 13)[dd] * 4096 / SC_BOT
    roads = [build_road(tiles, st) for st in ROAD_STYLES]
    roads_b = [build_road(tiles, st, True) for st in ROAD_STYLES]
    cars = [build_car(tiles, bank, body, trim) for _n, bank, body, trim in PLAYER_CARS]
    cars += [build_car(tiles, fb, body, trim, FOG_REMAP)
             for fb, (_n, _b, body, trim) in zip(FOG_CARS, PLAYER_CARS)]
    car_w, car_h = cars[0][2], cars[0][3]
    dinfo = []
    for d in decors:
        dc = decor_colors(d)
        pano, pano_h = build_pano(tiles, d)
        dinfo.append((d, dc, pano, pano_h))
    # objets de chaque decor : types que le generateur RECS y place ($6AE58,
    # 24 octets par decor), sous forme d'un faux circuit (un objet par segment)
    main_prog = open(os.path.join(ROOT, "extract", "l3_d1_255.bin"), "rb").read()
    fake = []
    for d in decors:
        types = [t for t in main_prog[0x6AE58 - MAIN_BASE + 24 * d:0x6AE58 - MAIN_BASE + 24 * d + 24] if t]
        # panneaux de virage ($726EA, table $7269E : type a gauche, a droite)
        sg = 0x7269E - MAIN_BASE + 4 * d
        types += [main_prog[sg], main_prog[sg + 2]]
        raw = b"".join(bytes([0, 0, t, 12]) + bytes(12) for t in types)
        fake.append((raw, len(types), d))
    build_objects.OBJ_REF_HW = SCALE_REF
    ob = build_objects.build_objects_multi(
        tiles, [(t["raw"], len(t["curve"]), t["decor"]) for t in tracks] + fake, neo_color,
        extra=[(CAR_BANK, OPP_FRAMES_R, SCALE_REF), (CAR_BANK, OPP_FRAMES, SCALE_REF),
               (CAR_BANK, OPP_FRAMES_L, SCALE_REF), (TRAF_FILE, TRAF_FRAMES, SCALE_REF)]
        # fumee de patinage d2_132 (8 images), gerbes d'eau d2_141 / de neige
        # d2_180 / de sable d2_188 (3 images) : une banque par image ($7A4D8)
        + [(132, [k], SCALE_REF) for k in range(8)]
        + [(f, [k], SCALE_REF) for f in (141, 180, 188) for k in range(3)])
    # poteau des portiques (genere) : 16 x 240, gris $666 (Amiga 1 -> Neo 2), bord
    # droit sombre $222 (Amiga 2 -> Neo 3) ; une seule image, zoom materiel
    pole_tile0 = len(ob["tile_idx"])
    for _r in range(15):
        ob["tile_idx"].append(tiles.add([(2 if x < 12 else 3) for _y in range(16) for x in range(16)]))
    ob["bank_first"].append(len(ob["frames"]))
    ob["bank_count"].append(1)
    ob["bank_ref"].append(16)
    ob["frames"].append((16, 240, 1, 15, pole_tile0))
    ob["pole_bank"] = len(ob["bank_first"]) - 1
    # lisses de la glissiere de montagne ($7B92C : lignes du blitter entre deux
    # poteaux $DF) : tuiles 16 x 16 d'une ligne d'1 px, encre 15 ($558 en montagne, releve WinUAE) ;
    # 0-16 : pente douce, montee de k px de (0, 15) a (15, 15 - k) ; 17-33 :
    # pente raide, de (0, 15) a (k, 0). Retournement horizontal pour l'autre sens.
    ob["rail_tile0"] = len(ob["tile_idx"])
    for k in range(17):
        px = [0] * 256
        for x in range(16):
            y = 15 - (x * k + 7) // 15 if k else 15
            px[max(0, y) * 16 + x] = 15
        ob["tile_idx"].append(tiles.add(px))
    for k in range(17):
        px = [0] * 256
        for y in range(16):
            x = ((15 - y) * k + 7) // 15
            px[y * 16 + min(15, x)] = 15
        ob["tile_idx"].append(tiles.add(px))
    screens, car_anim = [], []
    for _n, f in FE_SCREENS:
        screens.append(build_screen(tiles, f))
        if _n in ("car0", "car1", "car2"):
            order, rgb = build_screen.last
            car_anim.append(build_car_anim(tiles, int(_n[3]), order, rgb, load_sc(f)[0]))
    menu_meta, menu_packed, menu_pals, menu_hl_first = build_menu(tiles)
    hud_tiles, hud = build_hud()
    flags, flag_pal = build_flags(tiles)
    write_s1(hud_tiles, os.path.join(BUILD, "s1_hud.bin"))
    # C ROM : puissance de 2 (2 fichiers de 64 octets par tuile)
    global CROM_SIZE
    while len(tiles.tiles) * 64 > CROM_SIZE:
        CROM_SIZE *= 2
    tiles.write(os.path.join(BUILD, f"{GAME}-c1.c1"), os.path.join(BUILD, f"{GAME}-c2.c2"))

    recip = []
    for i in range(RECIP_N):
        dz = max(DZ_MIN, i * RECIP_STEP + RECIP_STEP // 2)
        recip.append((PROJ_D << RECIP_Q) // dz)
    pano_rows_max = max(len(p[0]) for _d, _dc, p, _h in dinfo)
    track_max = max([len(t["curve"]) for t in tracks] + [RECS_MAX])

    h = [
        "/* GENERE par tools/build_raster_test.py - ne pas editer. */",
        "#pragma once",
        "#include <ngdevkit/types.h>",
        f"#define ROAD_COLS {ROAD_COLS}",
        f"#define WIDE_K {WIDE_K}",
        f"#define WIDE_H0 {WIDE_H0}",
        f"#define WIDE_STEP {WIDE_STEP}",
        f"#define ROAD_CX {ROAD_CX}",
        f"#define HORIZON {HORIZON}",
        f"#define CAM_H {CAM_H}",
        f"#define OBJ_X_K {OBJ_X_K} /* octet lateral x 16 unites Amiga -> monde */",
        f"#define SCALE_REF {SCALE_REF} /* ROAD_HW en px au bas d'ecran (echelle 4096 du jeu) */",
        f"#define ROAD_RMAX {ROAD_RMAX}",
        f"#define ROAD_TILES {ROAD_SLICES * ROAD_PHASES // 16}",
        f"#define ROAD_STYLES {len(ROAD_STYLES)}",
        f"#define NCARS {len(PLAYER_CARS)}",
        f"#define CAR_FRAMES {len(cars[0][1])}",
        f"#define CAR_COLS {len(cars[0][1][0])}",
        f"#define CAR_ROWS {len(cars[0][1][0][0])}",
        f"#define CAR_W {car_w}",
        f"#define CAR_H {car_h}",
        f"#define NTRACKS {len(tracks)}",
        f"#define NDECORS {len(decors)}",
        f"#define TRACK_MAX {track_max}",
        f"#define RECIP_Q {RECIP_Q}",
        f"#define RECIP_STEP {RECIP_STEP}",
        f"#define RECIP_N {RECIP_N}",
        f"#define PANO_COLS {PANO_W // 16}",
        f"#define PANO_ROWS_MAX {pano_rows_max}",
        f"#define OBJ_BANKS {len(ob['bank_first'])}",
        f"#define OBJ_FRAMES {len(ob['frames'])}",
        f"#define OPP_BANK {ob['bank_extra'][0]}",
        f"#define TRAF_BANK {ob['bank_extra'][3]}",
        f"#define SMOKE_BANK {ob['bank_extra'][4]} /* + image 0-7 */",
        f"#define SPRAY_BANK {ob['bank_extra'][12]} /* eau, neige, sable : + 3 x type + image */",
        f"#define POLE_BANK {ob['pole_bank']} /* poteau des portiques (genere) */",
        f"#define RAIL_T0 {ob['rail_tile0']} /* lisses de montagne : 17 pentes douces puis 17 raides (obj_tiles) */",
        f"#define OPP_LIVERIES {len(OPP_LIVERIES)}",
        f"#define FE_SCREENS {len(screens)}",
        f"#define FE_COLS {FE_COLS}",
        f"#define FE_ROWS {FE_ROWS}",
        f"#define FE_Y {FE_Y}",
        f"#define FE_PALS {sum(len(sc[2]) for sc in screens)}",
        f"#define INTRO_CAR_FRAMES {INTRO_CAR_FRAMES}",
        f"#define MF_ZOOM_FRAMES {MF_ZOOM_FRAMES}",
        f"#define HUD_BLANK {hud['blank']}",
        f"#define MENU_ITEMS {len(MENU_ITEMS)}",
        f"#define RECS_ITEMS {len(RECS_ITEMS)}",
        f"#define RECS_ITEM0 {len(MENU_ITEMS)} /* boutons du constructeur RECS dans menu_items */",
        f"#define RECS_RAMP0 {RECS_RAMP0} /* images : rampe r x 27 + etat (6 x 2 tuiles) */",
        f"#define RECS_PCT0 {RECS_PCT0} /* pourcentages 0-26 (2 x 1 tuiles) */",
        f"#define RECS_DIG0 {RECS_DIG0} /* chiffres 0-9 (1 x 2 tuiles) */",
        "extern const s16 recs_scen_x[13]; /* centre de l'icone de chaque decor dans la barre SCENARIO */",
        f"#define MENU_ROWS {MENU_ROWS}",
        f"#define MENU_PALS {len(menu_pals)}",
        "typedef struct { s16 x, y; u8 cols, nvar; u16 first; s16 hx, hy; u8 hcols, hrows; u16 htile; } menu_item_t;",
        "extern const menu_item_t menu_items[MENU_ITEMS + RECS_ITEMS];",
        "extern const u16 menu_tiles[], menu_attr_ofs[];",
        "extern const u8 menu_attr[];",
        "extern const u16 menu_pals[MENU_PALS][16];",
        f"#define HUD_GAUGE_END {hud['gauge_end']}",
        f"#define FLAKE_TILE0 {hud['flake0']} /* 64 flocons puis 64 gouttes */",
        f"#define MSG_TILE0 {hud['msg0']} /* bandeaux de messages : 2 tuiles par colonne de 8 px */",
        "extern const u16 hud_pal[16], hud_small[10], hud_big[10][4], hud_pos[5][8], hud_kmh[5];",
        "extern const u16 hud_bar[46][12], hud_gauge[2][8][9];",
        "extern const u16 flag_tiles[15][12], flag_pal[16]; /* vignette du HUD (d1_026), colonnes de 4 tuiles */",
        "extern const u16 intro_car_tick[INTRO_CAR_FRAMES + 3]; /* apparition de chaque image, puis capot et ecussons (ticks 50 Hz, $6A222) */",
    ]
    h += [f"#define FE_{n.upper()} {i}" for i, (n, _f) in enumerate(FE_SCREENS)]
    h += [
        "typedef struct { u16 w; u8 h, cols, rows; u16 tile; } obj_frame_t;",
        f"#define CP_MAX {CP_MAX}",
        "/* lapmode : 1 = ncp tours, 0 = sprint de ncp troncons ; cp : positions des",
        " * points de controle (segments, ncp + 1) ; cpt : temps alloue a chaque troncon (s) */",
        "/* attr : surface de chaque quart de segment (4 quartets, quart 0 en poids fort) :",
        " * 3 = depart / arrivee / ligne de controle, 2 = turbo, 1 et 9 = tunnel */",
        "typedef struct { const char *code; const s8 *curve, *hill; const u16 *obj; const u16 *attr; u16 len; u8 decor;",
        "                 u8 lapmode, ncp; u16 cp[CP_MAX + 1]; u8 cpt[CP_MAX]; } track_t;",
        "/* fog : herbe par palier de brouillard [palier 0-4][phase] (NULL : sans) */",
        f"#define FOG_DY1 {FOG_DY[0]}",
        f"#define FOG_DY2 {FOG_DY[1]}",
        f"#define FOG_DY3 {FOG_DY[2]}",
        f"#define FOG_DY4 {FOG_DY[3]}",
        "typedef struct { const char *name; const u16 *road_pal, *obj_pal, *pano_pal, *sky, *pano_tiles, *fog;",
        "/* surf : par surface 0 / 1 / 2 / 3 (noir) / 4 (bandeau rouge), encres 1, 2, 3, 6 de la",
        " * route (raster.S), puis herbe A / B des surfaces 0-2 (mots 20-25) ; tunnel : surface 1 */",
        "                 u16 grass_a, grass_b; s16 road_hw, lane; u8 id, style, pano_rows; const u16 *surf; u8 tunnel; const u16 *flash; } decor_t;",
        "extern const track_t tracks[NTRACKS];",
        "extern const decor_t decors[NDECORS];",
        "extern const char *const car_names[NCARS];",
        "#define DRIVERS 18",
        "extern const char *const driver_names[DRIVERS];",
        "extern const u8 race_points[10]; /* points par place (Lotus III : $73CC8) */",
        "extern const u8 obj_type_bank[256];",
        "extern const u16 obj_bank_first[OBJ_BANKS];",
        "extern const u8 obj_bank_count[OBJ_BANKS];",
        "extern const u8 obj_bank_ref[OBJ_BANKS];",
        "extern const u16 opp_livery[OPP_LIVERIES * 2]; /* carrosserie, ombre */",
        "extern const obj_frame_t obj_frames[OBJ_FRAMES];",
        f"extern const u16 obj_tiles[{len(ob['tile_idx'])}];",
        "extern const u8 obj_frame_lut[OBJ_BANKS][256];",
        "/* inverses (divisions remplacees par des multiplications) : 32768 / n (n < 256),",
        " * 65536 / largeur de chaque image, largeur de l'image 0 x 4096 / reference de la banque */",
        "extern const u16 inv_den[256];",
        "extern const u16 obj_frame_invw[OBJ_FRAMES];",
        "extern const u16 obj_bank_k[OBJ_BANKS];",
        "extern const u16 road_tiles[ROAD_STYLES][ROAD_COLS * ROAD_TILES];",
        "extern const u16 road_tiles_b[ROAD_STYLES][ROAD_COLS * ROAD_TILES];",
        "extern const u16 car_tiles[2 * NCARS][CAR_FRAMES * CAR_COLS * CAR_ROWS]; /* + NCARS : brouillard */",
        "extern const u16 car_pal[2 * NCARS][16];",
        "extern const u16 recip[RECIP_N];",
        "extern const u16 fe_tiles[FE_SCREENS][FE_COLS * FE_ROWS];",
        "extern const u8 fe_attr[FE_SCREENS][FE_COLS * FE_ROWS];",
        f"#define CAR_ANIM_C0 {CAR_ANIM_C0} /* Select a car : animation, colonnes / rangees de l'ecran */",
        f"#define CAR_ANIM_COLS {CAR_ANIM_COLS}",
        f"#define CAR_ANIM_R0 {CAR_ANIM_R0}",
        f"#define CAR_ANIM_ROWS {CAR_ANIM_ROWS}",
        "extern const u16 car_anim_tiles[3][16 * CAR_ANIM_COLS * CAR_ANIM_ROWS];",
        "extern const u8 car_anim_attr[3][16 * CAR_ANIM_COLS * CAR_ANIM_ROWS];",
        "extern const u16 fe_pal_first[FE_SCREENS];",
        "extern const u8 fe_pal_count[FE_SCREENS];",
        "extern const u16 fe_pals[FE_PALS][16];",
        "extern const u16 fe_bg[FE_SCREENS];",
    ]
    open(os.path.join(BUILD, "road_data.h"), "w").write("\n".join(h) + "\n")

    c = ['#include "road_data.h"']

    def arr2(ctype, name, rows):
        body = ",\n".join("    {" + ", ".join(str(v) for v in r) + "}" for r in rows)
        return f"const {ctype} {name}[{len(rows)}][{len(rows[0])}] = {{\n{body}\n}};\n"

    c.append(arr2("u16", "road_tiles", [[t for col in r for t in col] for r in roads]))
    c.append(arr2("u16", "road_tiles_b", [[t for col in r for t in col] for r in roads_b]))
    c.append(arr2("u16", "car_tiles", [[t for fr in car[1] for col in fr for t in col] for car in cars]))
    c.append(arr2("u16", "car_pal", [car[0] for car in cars]))
    c.append("const char *const car_names[NCARS] = {" + ", ".join(f'"{n}"' for n, *_ in PLAYER_CARS) + "};\n")
    c.append(c_array("u16", "recip", recip))
    c.append("const char *const driver_names[DRIVERS] = {" +
             ", ".join(f'"{n}"' for n in driver_names(18)) + "};" + chr(10))
    c.append(c_array("u8", "race_points", [20, 15, 12, 10, 8, 6, 4, 3, 2, 1]))
    # decors
    for k, (d, dc, pano, pano_h) in enumerate(dinfo):
        ra, rb = (amiga_rgb(x) for x in dc["road"])
        la, lb = (amiga_rgb(x) for x in dc["line"])
        road_pal = [0x8000] + [neo_color(x) for x in (ra, rb, la, ROAD_PAL[3], ROAD_PAL[4], lb)]
        fading = str(ROAD_STYLE.get(d, "")).startswith("fog")
        if fading:
            fe = [fade_entry(d, k) for k in range(5)]
            # (route A, route B, marquage A) des paliers 1-2, (route A, marquage
            # A) du palier 3, route A du palier 4 : encres 7-15 (FOG_PENS)
            road_pal += [neo_color(amiga_rgb(fe[k][i]))
                         for k, ii in ((1, (1, 4, 2)), (2, (1, 4, 2)), (3, (1, 2)), (4, (1,)))
                         for i in ii]
            fog = [neo_color(amiga_rgb(fe[k][i])) for k in range(5) for i in (0, 3)]
            c.append(c_array("u16", f"dec{k}_fog", fog))
            dc["_fog"] = f"dec{k}_fog"
        road_pal += [0] * (16 - len(road_pal))
        if not fading:
            for (pr, pl_), (cr, cl) in zip(START_PENS, (dc["start"][0:2], dc["start"][2:4])):
                road_pal[pr] = neo_color(amiga_rgb(cr))
                road_pal[pl_] = neo_color(amiga_rgb(cl))
        grass_a, grass_b = (neo_color(amiga_rgb(x)) for x in dc["grass"])
        sky74 = dc["sky74"]
        sky = []
        for y in range(SCREEN_H):
            # copper de Lotus III : une entree du degrade toutes les 4 lignes, la
            # derniere (23) juste au-dessus de l'horizon (mesure WinUAE : desert,
            # futureworld) ; au-dessus, la 1re couleur
            kk = len(sky74) - 1 - (HORIZON - 2 - y) // 4
            # HORIZON - 1 : deja l'herbe (une IRQ toutes les 2 lignes : la couleur
            # deborde sur la ligne suivante, liseré sous le panorama sinon)
            if y < HORIZON - 1:
                sky.append(neo_color(amiga_rgb(sky74[max(0, kk)])))
            elif fading:   # au-dela d'une crete : palier par dy
                sky.append(neo_color(amiga_rgb(fade_entry(d, fog_level(y - HORIZON))[0])))
            else:
                sky.append(grass_a)
        pano_pal = [0x8000] + [neo_color(amiga_rgb(x)) for x in dc["pano_pal"][1:]]
        c.append(c_array("u16", f"dec{k}_road_pal", road_pal))
        c.append(c_array("u16", f"dec{k}_obj_pal", ob["pals"][d]))
        c.append(c_array("u16", f"dec{k}_pano_pal", pano_pal))
        c.append(c_array("u16", f"dec{k}_sky", sky))
        if d == 7:
            # orage ($6DBD6) : eclair = degrade du ciel remplace par $EEE (table de
            # 74 mots en a3+448, $6FA7E) ; le sol derriere une crete garde sa couleur
            c.append(c_array("u16", f"dec{k}_flash",
                             [neo_color(amiga_rgb(0xEEE)) if y < HORIZON - 1 else sky[y]
                              for y in range(SCREEN_H)]))
            dc["_flash"] = f"dec{k}_flash"
        c.append(c_array("u16", f"dec{k}_pano", [t for col in pano for t in col]))
        dc["_c"] = (grass_a, grass_b, len(pano[0]))
        sp = []
        for (a, b) in dc["surf"]:
            sp += [neo_color(amiga_rgb(x)) for x in (a[1], b[1], a[2], b[2])]
        if d == 2:   # brouillard : pas de surfaces speciales
            sp = [road_pal[1], road_pal[2], road_pal[3], road_pal[6]] * 3
        sp += [0, 0, 0, 0]   # surface 3 : noir (ouverture d'un tunnel)
        sp += [neo_color(amiga_rgb(0x600))] * 4   # surface 4 : bandeau rouge des portiques
        for (a, b) in dc["surf"]:
            sp += [neo_color(amiga_rgb(a[0])), neo_color(amiga_rgb(b[0]))]
        if d == 2:
            sp[20:] = [grass_a, grass_b] * 3
        c.append(c_array("u16", f"dec{k}_surf", sp))
        # tunnel : herbe de la surface 1 noire (futureworld, mountain)
        dc["_tun"] = int(dc["surf"][1][0][0] == 0 and dc["surf"][1][1][0] == 0 and dc["surf"][1] != dc["surf"][0])
    # largeur de route du decor ($6C028, a3+866) : demi-largeur a l'ecran =
    # echelle x largeur / 1024, soit 4 x largeur px en bas d'ecran (echelle 4095) ;
    # ici le bas d'ecran (dy = 73) a l'echelle 598 / 4096 : 27,4 x largeur (monde)
    widths = main_words(0x6C028, 13)
    c.append("const decor_t decors[NDECORS] = {")
    for k, (d, dc, pano, pano_h) in enumerate(dinfo):
        ga, gb, pr = dc["_c"]
        st = ROAD_STYLES.index(ROAD_STYLE.get(d, "lanes"))
        c.append(f'    {{"{DECOR_NAMES[d]}", dec{k}_road_pal, dec{k}_obj_pal, dec{k}_pano_pal, dec{k}_sky, '
                 f'dec{k}_pano, {dc.get("_fog", "0")}, {ga}u, {gb}u, {round(4 * widths[d] * 4096 / SC_BOT)}, {round(4 * widths[d] * 4096 / SC_BOT * 0.6)}, {d}, {st}, {pr}, dec{k}_surf, {dc["_tun"]}, {dc.get("_flash", "0")}}},')
    c.append("};\n")
    # circuits
    for i, (t, objs) in enumerate(zip(tracks, ob["objs"])):
        # courbure de signe oppose a l'original : positive = virage a droite a
        # l'ecran (proj.S : dx += virage). Lotus III : positive = virage a
        # gauche (force centrifuge $77520 vers +lateral = droite ; panneau
        # « << » pose a droite, $726EA)
        c.append(c_array("s8", f"trk{i}_curve", [-v for v in t["curve"]], 32))
        c.append(c_array("s8", f"trk{i}_hill", t["hill"], 32))
        c.append(c_array("u16", f"trk{i}_obj", objs))
        raw = t["raw"]
        # surface par quart de segment : octets +10 / +11 = 4 quartets (quart 0
        # en poids fort) ; 3 = depart / controle, 2 = turbo, 1 / 9 = tunnel
        c.append(c_array("u16", f"trk{i}_attr",
                         [(raw[16 * k + 10] << 8) | raw[16 * k + 11] for k in range(len(t["curve"]))], 16))
    c.append("const track_t tracks[NTRACKS] = {")
    for i, t in enumerate(tracks):
        inf = t["info"]
        c.append(f'    {{"{t["code"].upper()}", trk{i}_curve, trk{i}_hill, trk{i}_obj, trk{i}_attr, {len(t["curve"])}, '
                 f'{t["decor"]}, {inf["lapmode"]}, {inf["ncp"]}, '
                 f'{{{", ".join(map(str, inf["cp"]))}}}, {{{", ".join(map(str, inf["cpt"]))}}}}},')
    c.append("};\n")
    # objets
    c.append(c_array("u8", "obj_type_bank", ob["type_bank"]))
    c.append(c_array("u16", "obj_bank_first", ob["bank_first"]))
    c.append(c_array("u8", "obj_bank_count", ob["bank_count"]))
    c.append(c_array("u8", "obj_bank_ref", ob["bank_ref"]))
    c.append(c_array("u16", "opp_livery", [neo_color(x) for lv in OPP_LIVERIES for x in lv]))
    c.append("const obj_frame_t obj_frames[OBJ_FRAMES] = {\n" + "\n".join(
        f"    {{{w}, {hh}, {cl}, {rw}, {tt}}}," for w, hh, cl, rw, tt in ob["frames"]) + "\n};\n")
    c.append(c_array("u16", "obj_tiles", ob["tile_idx"]))
    lut = []
    for b, (first, count) in enumerate(zip(ob["bank_first"], ob["bank_count"])):
        ws = [ob["frames"][first + i][0] for i in range(count)]
        for tw in range(256):
            fi = count - 1
            while fi > 0 and ws[fi] < tw:
                fi -= 1
            lut.append(fi)
    rows = ["    {" + ",".join(str(v) for v in lut[i:i + 256]) + "}" for i in range(0, len(lut), 256)]
    c.append("const u8 obj_frame_lut[OBJ_BANKS][256] = {\n" + ",\n".join(rows) + "\n};\n")
    c.append(c_array("u16", "inv_den", [32767] + [min(32767, (32768 + n // 2) // n) for n in range(1, 256)]))
    c.append(c_array("u16", "obj_frame_invw", [min(65535, 65536 // max(1, f[0])) for f in ob["frames"]]))
    c.append(c_array("u16", "obj_bank_k", [min(65535, round(ob["frames"][first][0] * 4096 / ref))
                                           for first, ref in zip(ob["bank_first"], ob["bank_ref"])]))
    # ecrans du menu
    c.append(arr2("u16", "fe_tiles", [sc[0] for sc in screens]))
    c.append(arr2("u16", "car_anim_tiles", [a[0] for a in car_anim]))
    c.append(arr2("u8", "car_anim_attr", [a[1] for a in car_anim]))
    c.append(arr2("u8", "fe_attr", [sc[1] for sc in screens]))
    firsts, n = [], 0
    for sc in screens:
        firsts.append(n)
        n += len(sc[2])
    c.append(c_array("u16", "fe_pal_first", firsts))
    c.append(c_array("u8", "fe_pal_count", [len(sc[2]) for sc in screens]))
    c.append(arr2("u16", "fe_pals", [p for sc in screens for p in sc[2]]))
    c.append(c_array("u16", "fe_bg", [sc[3] for sc in screens]))
    c.append(c_array("u16", "intro_car_tick", intro_car_ticks()))
    c.append(c_array("u16", "hud_pal", [0x8000] + [neo_color(HUD_PAL_RGB[i]) if i in HUD_PAL_RGB else 0
                                             for i in range(1, 16)]))
    # menu : tuiles et palettes de toutes les images, a la suite
    mt, ma, mofs = [], [], []
    for tl, at in menu_packed:
        mofs.append(len(mt))
        mt += tl
        ma += at
    c.append(c_array("u16", "menu_tiles", mt))
    c.append(c_array("u8", "menu_attr", ma))
    c.append(c_array("u16", "menu_attr_ofs", mofs))
    c.append(arr2("u16", "menu_pals", menu_pals))
    rows = []
    for i, m in enumerate(menu_meta):
        hl = m["hl"]
        rows.append(f"    {{{m['x']}, {m['y']}, {m['cols']}, {m['n']}, {m['first']}, {m['hx']}, {m['hy']}, "
                    f"{len(hl[0]) // 16}, {len(hl) // 16}, {menu_hl_first + i}}},")
    c.append("const menu_item_t menu_items[MENU_ITEMS + RECS_ITEMS] = {\n" + "\n".join(rows) + "\n};\n")
    c.append(c_array("s16", "recs_scen_x", RECS_SCEN_X))
    print(f"  menu : {len(menu_pals)} palettes")
    c.append(arr2("u16", "flag_tiles", flags))
    c.append(c_array("u16", "flag_pal", flag_pal))
    c.append(c_array("u16", "hud_small", hud["small"]))
    c.append(arr2("u16", "hud_big", hud["big"]))
    c.append(arr2("u16", "hud_pos", hud["pos"]))
    c.append(c_array("u16", "hud_kmh", hud["kmh"]))
    c.append(arr2("u16", "hud_bar", hud["bar"]))
    g = hud["gauge"]
    c.append("const u16 hud_gauge[2][8][9] = {" + ",".join(
        "{" + ",".join("{" + ",".join(str(g[s * 72 + u * 9 + l]) for l in range(9)) + "}" for u in range(8)) + "}"
        for s in range(2)) + "};\n")
    print(f"  HUD : {len(hud_tiles)} tuiles fix")
    open(os.path.join(BUILD, "road_data.c"), "w").write("\n".join(c))
    open(os.path.join(BUILD, "decors.txt"), "w").write(" ".join(str(d) for d in decors) + "\n")
    for t in tracks:
        print(f"  {t['code']} : {DECOR_NAMES[t['decor']].lower()}, {len(t['curve'])} segments")
    print(f"  ecrans : {', '.join(f'{n} {len(sc[2])} pal.' for (n, _f), sc in zip(FE_SCREENS, screens))}")
    print(f"  {len(tiles.tiles)} tuiles (C ROM {2 * CROM_SIZE // 1024} Ko), {len(ob['frames'])} images d'objets")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
