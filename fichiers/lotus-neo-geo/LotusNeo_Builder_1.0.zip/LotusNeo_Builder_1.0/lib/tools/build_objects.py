"""Objets de bord de route (Lotus III) pour la ROM raster.

Correspondances (cf. docs/amiga_notes.md, « Objets de bord de route ») :
  - objets d'un segment : 4 mots en +2/+4/+6/+8 (octet haut = type, octet bas
    = position laterale signee, en 1/16 de demi-largeur de route) ;
  - type -> banque de sprites = fichier d2_<type> ; au-dela du dernier
    fichier (239), d2_<type - $40> (types $F0+) ; $FC/$FD et 0 ignores ;
  - decor = table $6ECA6[p0 >> 1] (p0 = 1er parametre RECS) ;
    palette des objets = 16 couleurs en $2D04 + 32 * decor (pal_sNN).

Chaque banque garde ses images pre-zoomees (17 en general) : le jeu prend la
plus petite image plus grande que la taille voulue, le zoom Neo Geo fait le
reste.
"""

from __future__ import annotations

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(HERE, "amiga"))

import render_bank  # noqa: E402

L3 = os.path.join(ROOT, "extract", "l3")
MAIN = os.path.join(ROOT, "extract", "l3_d1_255.bin")
MAIN_BASE = 0x682A0
DECOR_TABLE = 0x6ECA6
PAL_TABLE = 0x2D04       # offset dans le programme principal (pal_sNN)
LAST_FILE = 239


# Types $F0-$F6 : copie en miroir horizontal d'une autre banque, faite au
# chargement ($74A42 : table $7496E, octets aux bits inverses en $748AE) ; ex.
# $F0 = panneau « >> » (miroir de $80 « << »). Banque codee MIRROR + fichier.
MIRROR = 1000
MIRROR_SRC = (0x80, 0xA5, 0xB1, 0xBA, 0xBD, 0xC0, 0xD8)


def type_file(t: int) -> int | None:
    if t == 0 or t in (0xFC, 0xFD):
        return None
    if 0xF0 <= t <= 0xF6:
        src = type_file(MIRROR_SRC[t - 0xF0])
        return None if src is None else MIRROR + src
    f = t if t <= LAST_FILE else t - 0x40
    # banques de sprites : d2_128-d2_239 ; les types 109/112/113 (sons : tonnerre,
    # vent du desert, pluie) sont declenches par le circuit, sans image
    if f < 128:
        return None
    return f if os.path.exists(os.path.join(L3, f"d2_{f:03d}.bin")) else None


def decor_of(p0: int) -> int:
    main = open(MAIN, "rb").read()
    return main[DECOR_TABLE - MAIN_BASE + (p0 >> 1)]


def decor_palette(decor: int, neo_color) -> tuple[list[int], list[int]]:
    """(palette Neo Geo 16 mots, remap index Amiga 0-15 -> index Neo 1-15)."""
    main = open(MAIN, "rb").read()
    o = PAL_TABLE + 32 * decor
    amiga = [int.from_bytes(main[o + 2 * i:o + 2 * i + 2], "big") for i in range(16)]
    rgb = [(((c >> 8) & 15) * 17, ((c >> 4) & 15) * 17, (c & 15) * 17) for c in amiga]
    # 16 couleurs opaques pour 15 places. L'index 12 est la couleur que le copper
    # remplace par le ciel ($F0F en memoire) : aucun objet ne l'utilise (verifie
    # sur les 13 decors), il cede sa place a l'index 15. Neo 1-12 = Amiga 0-11,
    # Neo 13-15 = Amiga 13-15 : meme numerotation pour tous les decors.
    remap = [v + 1 for v in range(12)] + [13, 13, 14, 15]
    pal = [0x8000] + [neo_color(rgb[i]) for i in range(12)] + [neo_color(rgb[i]) for i in (13, 14, 15)]
    return pal, remap


OBJ_REF_HW = 204   # echelle (px de ROAD_HW) ou l'image 0 est a 100 % : bas d'ecran (comme le jeu)


def build_objects(tiles, segs16: bytes, nseg: int, decor: int, neo_color,
                  extra: list[tuple[int, list[int], int]] = ()) -> dict:
    """Un seul circuit (compatibilite) : cf. build_objects_multi."""
    r = build_objects_multi(tiles, [(segs16, nseg, decor)], neo_color, extra)
    r["objs"] = r["objs"][0]
    r["pal"] = r["pals"][decor]
    return r


def build_objects_multi(tiles, tracks: list[tuple[bytes, int, int]], neo_color,
                        extra: list[tuple[int, list[int], int]] = ()) -> dict:
    """Banques d'objets communes a plusieurs circuits (segs16, nseg, decor).
    Chaque banque est recoloree avec le decor du 1er circuit qui l'utilise (seul
    l'index Amiga 15 depend du decor). extra : banques supplementaires (fichier,
    images gardees, demi-largeur de reference), placees apres (bank_extra[i])."""
    pals, remaps = {}, {}
    objs_all = []
    used = {}          # fichier -> index de banque
    file_decor = {}    # fichier -> decor de recoloration
    for segs16, nseg, decor in tracks:
        if decor not in pals:
            pals[decor], remaps[decor] = decor_palette(decor, neo_color)
        objs = []
        for i in range(nseg):
            r = segs16[16 * i:16 * i + 16]
            for k in range(4):
                w = int.from_bytes(r[2 + 2 * k:4 + 2 * k], "big")
                f = type_file(w >> 8)
                if f is None:
                    objs.append(0)
                    continue
                used.setdefault(f, len(used))
                file_decor.setdefault(f, decor)
                objs.append(w)
        objs_all.append(objs)
    first_decor = tracks[0][2]
    # banques : index par fichier ; type -> banque + 1 (0 = rien)
    type_bank = [0] * 256
    for t in range(256):
        f = type_file(t)
        if f is not None and f in used:
            type_bank[t] = used[f] + 1
    frames, tile_idx = [], []
    bank_first, bank_count = [], []
    bank_ref, bank_extra = [], []
    jobs = [(f, None, OBJ_REF_HW) for f, _ in sorted(used.items(), key=lambda kv: kv[1])]
    jobs += [(f, list(k), ref) for f, k, ref in extra]
    for f, keep_list, ref in jobs:
        remap = remaps[file_decor.get(f, first_decor)]
        mirror = f >= MIRROR
        data = open(os.path.join(L3, f"d2_{f % MIRROR:03d}.bin"), "rb").read()
        n = render_bank.be(data, 0, 2)
        fr = render_bank.parse(data)
        if keep_list is not None:
            keep = keep_list
            bank_extra.append(len(bank_first))
        else:
            order = sorted(range(len(fr)), key=lambda j: -fr[j]["w"] * fr[j]["h"])
            # images de largeur strictement decroissante (niveaux de zoom)
            keep, last_w = [], 1 << 30
            for j in order:
                if fr[j]["w"] < last_w:
                    keep.append(j)
                    last_w = fr[j]["w"]
        bank_ref.append(ref)
        bank_first.append(len(frames))
        bank_count.append(len(keep))
        for j in keep:
            fm = fr[j]
            px = render_bank.frame_pixels(data, fm, n)
            w, h = fm["w"], fm["h"]
            if mirror:
                # miroir ($748AE) sur la largeur visible : sur la largeur stockee
                # (multiple de 16, ex. 64 pour 51), des colonnes sortaient de
                # l'image (panneaux tronques)
                px = [list(reversed(r[:w])) for r in px]
            cols, rows = (w + 15) // 16, (h + 15) // 16
            frames.append((w, h, cols, rows, len(tile_idx)))
            for c in range(cols):
                for t in range(rows):
                    tile = []
                    for y in range(16):
                        for x in range(16):
                            X, Y = c * 16 + x, t * 16 + y
                            v = px[Y][X] if X < w and Y < h else -1
                            tile.append(remap[v] if v >= 0 else 0)
                    tile_idx.append(tiles.add(tile))
    return {"pals": pals, "objs": objs_all, "type_bank": type_bank, "frames": frames,
            "tile_idx": tile_idx, "bank_first": bank_first, "bank_count": bank_count,
            "bank_ref": bank_ref, "bank_extra": bank_extra,
            "files": sorted(used, key=lambda f: used[f])}
