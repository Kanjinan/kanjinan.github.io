"""Musiques de Lotus III : modules ProTracker reconstitues, rendus en WAV, puis
ADPCM-B pour la ROM V1 (driver Z80 src/z80/m1.s).

Format (cf. docs/amiga_notes.md, « Musique ») :
  - d1_054 + n : module ProTracker sans echantillons (titre, 31 instruments,
    ordre, motifs), n = morceau (0-12 decors, 13 intro, 14 game over,
    15 complete, 16 resultats, 17-22 autoradio) ;
  - table $7D16A (32 octets par morceau) : echantillon de chaque instrument
    (octet k + 1 = instrument k ; $FF = aucun), charge comme fichier 256 + n ;
  - d1_252 : archive des 76 echantillons (blocs SQ bout a bout, dans l'ordre).

Usage : python tools/build_music.py <dossier_build> <morceau>   (Python avec numpy)
        python tools/build_music.py --mods                     (export .mod seul)
Sorties : extract/l3/mod/*.mod ; <build>/lotusneo-v1.v1, sound.inc,
          sound_jmptable.inc (Z80), sound_ids.h (68000) ; cache <build>/sound/
"""

from __future__ import annotations

import os
import struct
import subprocess
import sys
import wave

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(HERE, "amiga"))

L3 = os.path.join(ROOT, "extract", "l3")
MAIN = os.path.join(ROOT, "extract", "l3_d1_255.bin")
MAIN_BASE = 0x682A0
SAMPLE_TABLE = 0x7D16A
NGDK = os.environ.get("NGDK_DIR", os.path.join(ROOT, "..", "NEO_GAME", "tools", "ngdevkit"))
ADPCMTOOL = os.path.join(NGDK, "local", "bin", "adpcmtool.py")

PAULA = 3546895          # horloge Paula PAL (Hz x periode)
RATE = 22050             # rendu et ADPCM-B
YM2610_CLOCK_RATE = 55555
MUSIC_CMD_BASE = 5
VROM_MIN = 0x200000
SONGS = 23


# ---------------------------------------------------------------------------
# Reconstitution des modules

def samples_bank() -> list[bytes]:
    """Les 76 echantillons de l'archive d1_252 (8 bits signes)."""
    import lotus_files
    import lotus_pack
    raw = next(data for name, _pos, data in lotus_files.files_l3() if name == "d1_252")
    out, o = [], 0
    while o + 10 <= len(raw) and raw[o:o + 2] == b"SQ":
        nl = lotus_pack.be32(raw, o + 6) & 0xFFFFFF
        plen = 10 + nl * 4
        out.append(lotus_pack.unpack_sq(raw[o:o + plen]))
        o += plen
    return out


def module(song: int, bank: list[bytes]) -> bytes:
    """Module ProTracker complet (M.K.) du morceau."""
    mod = bytearray(open(os.path.join(L3, f"d1_{54 + song:03d}.bin"), "rb").read())
    main = open(MAIN, "rb").read()
    table = main[SAMPLE_TABLE - MAIN_BASE + 32 * song:SAMPLE_TABLE - MAIN_BASE + 32 * song + 32]
    npat = max(mod[952:952 + 128]) + 1
    body = mod[:1084 + npat * 1024]
    body[1080:1084] = b"M.K."
    data = bytearray()
    for k in range(31):
        h = 20 + 30 * k
        length = struct.unpack(">H", body[h + 22:h + 24])[0] * 2
        n = table[k + 1] if k + 1 < 32 else 0xFF
        smp = bank[n] if n != 0xFF and n < len(bank) and length else b""
        smp = (smp + bytes(length))[:length]
        data += smp
    return bytes(body) + bytes(data)


def song_name(song: int) -> str:
    d = open(os.path.join(L3, f"d1_{54 + song:03d}.bin"), "rb").read(20)
    return d.split(b"\0")[0].decode("latin1").replace("l3_", "")


# ---------------------------------------------------------------------------
# Lecteur ProTracker (rendu mono)

PERIODS = [856, 808, 762, 720, 678, 640, 604, 570, 538, 508, 480, 453,
           428, 404, 381, 360, 339, 320, 302, 285, 269, 254, 240, 226,
           214, 202, 190, 180, 170, 160, 151, 143, 135, 127, 120, 113]
SINE = [0, 24, 49, 74, 97, 120, 141, 161, 180, 197, 212, 224, 235, 244, 250, 253,
        255, 253, 250, 244, 235, 224, 212, 197, 180, 161, 141, 120, 97, 74, 49, 24]


class Chan:
    def __init__(self):
        self.smp = None
        self.pos = 0.0
        self.period = 0
        self.vol = 0
        self.target = 0
        self.porta_speed = 0
        self.vib_pos = self.vib_speed = self.vib_depth = 0
        self.trem_pos = self.trem_speed = self.trem_depth = 0
        self.loop_row = self.loop_count = 0
        self.offset = 0
        self.on = False


def render_mod(data: bytes):
    import numpy as np
    insts = []
    npat = max(data[952:952 + 128]) + 1
    o = 1084 + npat * 1024
    for k in range(31):
        h = 20 + 30 * k
        ln, ft, vol, rs, rl = struct.unpack(">HBBHH", data[h + 22:h + 30])
        ln, rs, rl = ln * 2, rs * 2, rl * 2
        s = np.frombuffer(data[o:o + ln], dtype=np.int8).astype(np.float32)
        o += ln
        loop = (rs, rs + rl) if rl > 2 and rs + rl <= ln else None
        insts.append({"data": s, "len": ln, "vol": vol, "loop": loop, "ft": ft & 15})
    song_len = data[950]
    order = data[952:952 + song_len]
    chans = [Chan() for _ in range(4)]
    speed, tempo = 6, 125
    out = []
    visited = set()
    pos, row = 0, 0
    pat_delay = 0
    empty = {p for p in range(npat) if not any(data[1084 + p * 1024:1084 + p * 1024 + 1024])}

    def last_note_row(p: int) -> int:
        last = -1
        for r in range(64):
            for c in range(4):
                b = data[1084 + p * 1024 + r * 16 + c * 4:1084 + p * 1024 + r * 16 + c * 4 + 4]
                if ((b[0] & 15) << 8) | b[1]:
                    last = r
        return last

    while pos < song_len:
        if row == 0 and order[pos] in empty:
            break  # fin utile : la suite de l'ordre ne pointe que des motifs vides
        # dernier motif avant les motifs vides : coupe apres sa derniere note,
        # arrondie a 8 lignes (boucle sans silence)
        if pos + 1 < song_len and order[pos + 1] in empty and row == ((last_note_row(order[pos]) + 8) & ~7):
            break
        key = (pos, row)
        if key in visited:
            break  # boucle du morceau : un passage suffit (lecture en boucle)
        visited.add(key)
        pat = order[pos]
        base = 1084 + pat * 1024 + row * 16
        jump = brk = None
        loop_to = None
        notes = []
        for c in range(4):
            b0, b1, b2, b3 = data[base + 4 * c:base + 4 * c + 4]
            notes.append(((b0 & 0xF0) | (b2 >> 4), ((b0 & 0x0F) << 8) | b1, b2 & 0x0F, b3))
        # premier tick : notes et effets « tick 0 »
        for c, (ins, per, fx, prm) in enumerate(notes):
            ch = chans[c]
            if ins:
                ch.smp = insts[ins - 1]
                ch.vol = ch.smp["vol"]
            if per and ch.smp is not None:
                if fx in (3, 5):
                    ch.target = per
                else:
                    ch.period = per
                    ch.pos = 0.0
                    ch.on = True
                    ch.vib_pos = 0
                    if fx == 9:
                        if prm:
                            ch.offset = prm * 256
                        ch.pos = float(ch.offset)
            if fx == 0xC:
                ch.vol = min(prm, 64)
            elif fx == 0xF and prm:
                if prm < 32:
                    speed = prm
                else:
                    tempo = prm
            elif fx == 0xB:
                jump = prm
            elif fx == 0xD:
                brk = (prm >> 4) * 10 + (prm & 15)
            elif fx == 0xE:
                sub, v = prm >> 4, prm & 15
                if sub == 1:
                    ch.period = max(113, ch.period - v)
                elif sub == 2:
                    ch.period = min(856, ch.period + v)
                elif sub == 0xA:
                    ch.vol = min(64, ch.vol + v)
                elif sub == 0xB:
                    ch.vol = max(0, ch.vol - v)
                elif sub == 6:
                    if v == 0:
                        ch.loop_row = row
                    elif ch.loop_count == 0:
                        ch.loop_count = v
                        loop_to = ch.loop_row
                    else:
                        ch.loop_count -= 1
                        if ch.loop_count:
                            loop_to = ch.loop_row
                elif sub == 0xE:
                    pat_delay = v
            if fx == 3 and prm:
                ch.porta_speed = prm
            if fx == 4:
                if prm >> 4:
                    ch.vib_speed = prm >> 4
                if prm & 15:
                    ch.vib_depth = prm & 15
            if fx == 7:
                if prm >> 4:
                    ch.trem_speed = prm >> 4
                if prm & 15:
                    ch.trem_depth = prm & 15
        ticks = speed * (1 + pat_delay)
        pat_delay = 0
        tick_len = int(RATE * 2.5 / tempo)
        for t in range(ticks):
            mix = np.zeros(tick_len, dtype=np.float32)
            for c, (ins, per, fx, prm) in enumerate(notes):
                ch = chans[c]
                tt = t % speed
                period = ch.period
                vol = ch.vol
                if tt:
                    if fx == 1:
                        ch.period = period = max(113, ch.period - prm)
                    elif fx == 2:
                        ch.period = period = min(856, ch.period + prm)
                    elif fx in (3, 5) and ch.target:
                        if ch.period < ch.target:
                            ch.period = min(ch.target, ch.period + ch.porta_speed)
                        else:
                            ch.period = max(ch.target, ch.period - ch.porta_speed)
                        period = ch.period
                    if fx in (5, 6, 0xA):
                        up, dn = prm >> 4, prm & 15
                        ch.vol = min(64, ch.vol + up) if up else max(0, ch.vol - dn)
                        vol = ch.vol
                    if fx in (4, 6):
                        ch.vib_pos = (ch.vib_pos + ch.vib_speed) & 63
                    if fx == 7:
                        ch.trem_pos = (ch.trem_pos + ch.trem_speed) & 63
                    if fx == 0xE and prm >> 4 == 0xC and tt == (prm & 15):
                        ch.vol = vol = 0
                    if fx == 0xE and prm >> 4 == 9 and (prm & 15) and tt % (prm & 15) == 0:
                        ch.pos = 0.0
                if fx in (4, 6):
                    d = SINE[ch.vib_pos & 31] * ch.vib_depth // 128
                    period = period + (d if ch.vib_pos < 32 else -d)
                if fx == 7:
                    d = SINE[ch.trem_pos & 31] * ch.trem_depth // 64
                    vol = max(0, min(64, vol + (d if ch.trem_pos < 32 else -d)))
                if fx == 0 and prm:
                    k = (0, prm >> 4, prm & 15)[tt % 3]
                    if k and period:
                        # periode decalee de k demi-tons
                        period = int(period / (2 ** (k / 12)))
                if fx == 0xE and prm >> 4 == 0xD and tt < (prm & 15):
                    continue  # note retardee
                if not ch.on or ch.smp is None or not period or not vol:
                    continue
                smp = ch.smp
                step = PAULA / period / RATE
                idx = ch.pos + step * np.arange(tick_len, dtype=np.float64)
                if smp["loop"]:
                    ls, le = smp["loop"]
                    over = idx >= le
                    idx[over] = ls + np.mod(idx[over] - ls, le - ls)
                    ch.pos = ch.pos + step * tick_len
                    if ch.pos >= le:
                        ch.pos = ls + (ch.pos - ls) % (le - ls)
                else:
                    valid = idx < smp["len"]
                    idx = idx[valid]
                    ch.pos += step * tick_len
                    if ch.pos >= smp["len"]:
                        ch.on = False
                if len(idx):
                    mix[:len(idx)] += smp["data"][idx.astype(np.int64)] * (vol / 64.0)
            out.append(mix)
        # ligne suivante
        if loop_to is not None:
            row = loop_to
            visited = {k for k in visited if k[0] != pos}
            continue
        if jump is not None:
            if jump <= pos and brk is None:
                pos = song_len  # retour en arriere : fin du passage
                break
            pos, row = jump, 0
            if brk is not None:
                row = brk
            continue
        if brk is not None:
            pos, row = pos + 1, brk
            continue
        row += 1
        if row >= 64:
            row, pos = 0, pos + 1
    pcm = np.concatenate(out) if out else np.zeros(1, dtype=np.float32)
    peak = float(np.max(np.abs(pcm))) or 1.0
    return (pcm * (30000.0 / peak)).astype(np.int16)


def write_wav(path: str, pcm) -> None:
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(pcm.tobytes())


def export_mods() -> list[str]:
    bank = samples_bank()
    out_dir = os.path.join(L3, "mod")
    os.makedirs(out_dir, exist_ok=True)
    paths = []
    for s in range(SONGS):
        p = os.path.join(out_dir, f"{s:02d}_{song_name(s)}.mod")
        open(p, "wb").write(module(s, bank))
        paths.append(p)
    return paths


# ---------------------------------------------------------------------------
# Bruitages (ADPCM-A, frequence fixe) : echantillons SQ d1_096-d1_118 /
# d2_109-113, joues par $6DF84 avec le numero du fichier. En-tete de 14 octets :
# longueur (mots), periode Paula, volume, longueur de boucle (= longueur si le son
# boucle), deux durees, priorite ($3E7 pour les sons en boucle).

SFX_RATE = 18518          # ADPCM-A : 8 MHz / 432
SFX_RATE_EXACT = 8e6 / 432
SFX_CMD_BASE = MUSIC_CMD_BASE + 1
ENGINE_FILE = 96          # boucle du moteur ($6D94C)
ENGINE_ECHO_FILE = 97     # moteur dans un tunnel (segment mure, a3+2058 : $6DA66)
# Moteur ($6DA16) : periode Paula = 1035322 / regime (>= 124), regime a3+2066
# (1000-7999), y compris a l'arret. L'ADPCM-A n'a pas de reglage de hauteur :
# hauteurs pre-calculees, segments relances par le VBlank du 68000.
# - d1_096 / d1_097 = 10 pulsations du moteur (1958 octets, periode 195,8) ;
# - segment = 5632 echantillons = 11 blocs de 512 = 18 trames Neo Geo EXACTEMENT
#   (8 MHz / 432 x 101376 / 6 MHz x 18), ou 11264 (36 trames) a bas regime ;
#   nombre entier de pulsations : relance a la fin du segment sans trou ni
#   claquement ; changement de hauteur en debut de pulsation (cf. main.c).
ENGINE_PULSE = 195.8      # octets de l'echantillon Paula par pulsation
ENGINE_RPM = (1000, 8000)
ENGINE_RATIO = 1.08       # ecart de hauteur entre deux pas
ENGINE_SEG = 5632         # echantillons de 18 trames
ENGINE_FRAMES = 18
ENGINE_STEPS_TAB: list[tuple[int, int, int]] = []  # (regime nominal, pulsations, trames)


def engine_steps():
    """[(regime nominal, pulsations par segment, trames du segment)]."""
    if ENGINE_STEPS_TAB:
        return ENGINE_STEPS_TAB
    import math
    out = []
    rpm = ENGINE_RPM[0]
    while rpm <= ENGINE_RPM[1] * 1.02:
        rate = PAULA * rpm / 1035322
        pulse = ENGINE_PULSE * SFX_RATE_EXACT / rate    # echantillons par pulsation
        # 36 trames a bas regime (hauteur a 1 pulsation pres sur 2 x plus long)
        fr = 2 * ENGINE_FRAMES if 2 * ENGINE_SEG / pulse < 40 else ENGINE_FRAMES
        nc = max(1, round(ENGINE_SEG * fr / ENGINE_FRAMES / pulse))
        rpm_eff = round(nc * ENGINE_PULSE * SFX_RATE_EXACT / (ENGINE_SEG * fr / ENGINE_FRAMES) * 1035322 / PAULA)
        if not out or (out[-1][1], out[-1][2]) != (nc, fr):
            out.append((rpm_eff, nc, fr))
        rpm *= ENGINE_RATIO
    ENGINE_STEPS_TAB.extend(out)
    return out
# (nom, fichier, canal, volume 0-31, duree max en s pour un son en boucle, hauteur)
SFX = [
    # volumes = volume Paula de l'en-tete SQ (0-64) ramene a 0-31 ; le moteur
    # (volume 64) est au maximum : il doit dominer les bruitages
    ("bump", 98, 1, 23, 0, 1.0),     # choc entre voitures ($76DD2), volume 48
    ("crash", 100, 1, 16, 0, 1.0),   # choc contre le decor ($76B58, $7716E), volume 32
    ("skid", 108, 2, 24, 0.35, 1.0), # crissement ($77492, boucle)
    ("pass", 110, 3, 20, 0, 1.0),    # klaxon : voiture 3-4 segments devant, meme voie ($76F30)
    ("beep", 102, 4, 28, 0, 1.0),    # bip (compte a rebours)
    ("go", 102, 4, 31, 0, 1.5),      # depart : bip plus aigu
    # ambiances ($6D984-$6D994 : lancees au depart selon le decor), en boucle ;
    # le 68000 relance le segment (SND_FX_<nom>_FRAMES)
    ("desert", 112, 5, 16, 2.0, 1.0),  # vent de sable (decor desert)
    ("rain", 113, 5, 18, 2.0, 1.0),    # pluie (decor storm)
    ("wind", 116, 5, 18, 2.0, 1.0),    # vent (decor wind)
    ("thunder", 109, 4, 31, 0, 1.0),   # tonnerre ($6DC00, aleatoire en orage)
    # chocs contre les objets : son de la table $6CF84 (octet 3, par type)
    ("obj99", 99, 1, 31, 0, 1.0),
    ("obj101", 101, 1, 31, 0, 1.0),
    ("obj105", 105, 1, 23, 0, 1.0),
    ("obj106", 106, 1, 23, 0, 1.0),
    ("obj107", 107, 1, 31, 0, 1.0),
    ("jump", 114, 1, 23, 0, 1.0),     # saut sur un tremplin ($76C24)
    ("turbo", 117, 3, 31, 0, 1.0),    # entree en zone turbo ($767EA)
    ("scrape", 104, 1, 23, 0, 1.0),   # frottement contre un mur ($7689C)
    ("tick", 111, 4, 23, 0, 1.0),     # tic : bonus d'arrivee ($76088), moins de 9 s ($6DC32)
    ("arrow", 118, 3, 31, 0, 1.0),    # fleches $D2 / $D5 de futureworld ($769BC)
    ("slam", 115, 1, 23, 0, 1.0),     # machine $DB de futureworld ($7691E)
    ("rumble", 103, 2, 16, 0, 1.0),   # grondement hors piste / terre-plein ($6DDAA, $6DE6A)
]
SFX_SEG_FRAMES: dict[str, int] = {}


def sq_sample(num: int):
    """(echantillon float32, frequence Amiga, volume 0-64, boucle ?) d'un fichier SQ."""
    import numpy as np
    for d in ("d1", "d2"):
        path = os.path.join(L3, f"{d}_{num:03d}.bin")
        if os.path.exists(path):
            break
    raw = open(path, "rb").read()
    ln, per, vol, loop = struct.unpack(">HHHH", raw[:8])
    data = np.frombuffer(raw[14:14 + ln * 2], dtype=np.int8).astype(np.float32)
    return data, PAULA / per, vol, loop == ln


def resample(data, src_rate: float, dst_rate: float, length: int | None = None, loop: bool = False):
    import numpy as np
    step = src_rate / dst_rate
    n = length if length is not None else int(len(data) / step)
    pos = np.arange(n, dtype=np.float64) * step
    if loop:
        pos = np.mod(pos, len(data))
    else:
        pos = pos[pos < len(data) - 1]
    i = pos.astype(np.int64)
    f = (pos - i).astype(np.float32)
    j = np.minimum(i + 1, len(data) - 1) if not loop else (i + 1) % len(data)
    return data[i] * (1 - f) + data[j] * f


def encode_a(name: str, pcm, cache: str) -> bytes:
    import numpy as np
    wav = os.path.join(cache, f"fx_{name}.wav")
    enc = os.path.join(cache, f"fx_{name}.adpcma")
    if not os.path.exists(enc) or os.path.getmtime(enc) < os.path.getmtime(__file__):
        peak = float(np.max(np.abs(pcm))) or 1.0
        out = (pcm * (28000.0 / peak)).astype(np.int16)
        with wave.open(wav, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(SFX_RATE)
            w.writeframes(out.tobytes())
        subprocess.run([sys.executable, ADPCMTOOL, "-a", "-e", wav, "-o", enc], check=True)
    return open(enc, "rb").read()


def build_sfx(cache: str):
    """[(nom, donnees ADPCM-A, canal, volume)] : moteur en ENGINE_STEPS hauteurs
    (segments d'un nombre entier de boucles, pour enchainer sans claquement),
    puis les bruitages de SFX."""
    import numpy as np
    out = []
    # 4 jeux de ENGINE_STEPS hauteurs, dans cet ordre (cf. SND_ENGINE_*) :
    # moteur et echo du joueur 1 (canal 0), puis du joueur 2 (canal 5, 2 joueurs)
    # joueur 2 (canal 5) : memes donnees (nom de la source a la place des donnees)
    for prefix, num, ch, src in (("engine", ENGINE_FILE, 0, None), ("engineecho", ENGINE_ECHO_FILE, 0, None),
                                 ("engine2_", ENGINE_FILE, 5, "engine"), ("engine2echo", ENGINE_ECHO_FILE, 5, "engineecho")):
        data, _rate, _vol, _loop = sq_sample(num)
        for k, (_rpm, nc, fr) in enumerate(engine_steps()):
            name = f"{prefix.rstrip('_') if prefix.endswith('echo') else prefix}{k}"
            if src:
                out.append((name, f"{src}{k}", ch, 31))
                continue
            n = ENGINE_SEG * fr // ENGINE_FRAMES
            # nc pulsations exactement sur n echantillons
            src_rate = nc * ENGINE_PULSE * SFX_RATE_EXACT / n
            pcm = resample(data, src_rate, SFX_RATE_EXACT, n, loop=True)
            out.append((name, encode_a(f"{prefix}{k}_{nc}_{fr}", pcm, cache), ch, 31))
    for name, num, ch, vol, dur, pitch in SFX:
        data, rate, _v, loop = sq_sample(num)
        n = None
        if loop and dur:
            # nombre entier de boucles (relance sans claquement)
            loop_len = len(data) / (rate * pitch) * SFX_RATE
            n = int(max(1, round(dur * SFX_RATE / loop_len)) * loop_len)
            SFX_SEG_FRAMES[name] = n * 60 // SFX_RATE
        pcm = resample(data, rate * pitch, SFX_RATE, n, loop=loop and bool(dur))
        out.append((name, encode_a(name, pcm, cache), ch, vol))
    # jingle de l'ecran Magnetic Fields : d1_004 (8 bits signes, decompresse
    # par $7D44A en $4D1A8), lance par $6A4B6 au tick 90 de l'ecran sur les 4
    # voies a la periode 334, volume 64, joue une fois (au tick 110 les voies
    # sont rebouclees sur un tampon vide)
    data = np.frombuffer(open(os.path.join(L3, "d1_004.bin"), "rb").read(), dtype=np.int8).astype(np.float32)
    out.append(("mf", encode_a("mf", resample(data, PAULA / 334, SFX_RATE), cache), 0, 31))
    return out


SONG_INTRO, SONG_RESULTS = 13, 16
SONG_GAMEOVER, SONG_COMPLETE = 14, 15   # $742DC / $7430A
SONG_CDS = list(range(17, 23))   # autoradio : cd1-breathless ... cd6-shamrip


def song_adpcm(song: int, mods: list[str], cache: str) -> bytes:
    name = song_name(song)
    wav = os.path.join(cache, f"{song:02d}_{name}.wav")
    enc = os.path.join(cache, f"{song:02d}_{name}.adpcmb")
    if not os.path.exists(enc) or os.path.getmtime(enc) < os.path.getmtime(__file__):
        print(f"  rendu de {name} ({RATE} Hz) et encodage ADPCM-B...")
        write_wav(wav, render_mod(open(mods[song], "rb").read()))
        subprocess.run([sys.executable, ADPCMTOOL, "-b", "-e", wav, "-o", enc], check=True)
    data = open(enc, "rb").read()
    return data + bytes((-len(data)) % 256)


def main() -> int:
    """Musiques : intro, decors des circuits (<build>/decors.txt ou argv), resultats."""
    if sys.argv[1:] == ["--mods"]:
        for p in export_mods():
            print(" ", os.path.relpath(p, ROOT))
        return 0
    build = sys.argv[1]
    if len(sys.argv) > 2:
        decor_songs = [int(a) for a in sys.argv[2:]]
    else:
        decor_songs = [int(x) for x in open(os.path.join(build, "decors.txt")).read().split()]
    cache = os.path.join(build, "sound")
    os.makedirs(cache, exist_ok=True)
    mods = export_mods()
    songs = [SONG_INTRO] + decor_songs + [SONG_RESULTS, SONG_GAMEOVER, SONG_COMPLETE] + SONG_CDS
    vrom = bytearray()
    music = []
    for sg in songs:
        data = song_adpcm(sg, mods, cache)
        music.append((sg, len(vrom), len(vrom) + len(data) - 1))
        vrom += data
    sfx_base = MUSIC_CMD_BASE + len(songs)
    fx = []
    where = {}
    for fname, fdata, ch, vol in build_sfx(cache):
        if isinstance(fdata, str):
            st, en = where[fdata]
            fx.append((fname, st, en, ch, vol))
            continue
        if fname.startswith("engine") and len(fdata) % 256:
            raise SystemExit(f"{fname} : {len(fdata)} octets, pas un multiple de 256")
        fdata += bytes((-len(fdata)) % 256)
        # l'ADPCM-A ne lit pas un echantillon qui franchit une frontiere de 1 Mo
        if len(vrom) >> 20 != (len(vrom) + len(fdata) - 1) >> 20:
            vrom += bytes((-len(vrom)) % 0x100000)
        fx.append((fname, len(vrom), len(vrom) + len(fdata) - 1, ch, vol))
        where[fname] = (len(vrom), len(vrom) + len(fdata) - 1)
        vrom += fdata
    if len(vrom) > 0x1000000:
        raise SystemExit("V1 : plus de 16 Mo")
    size = VROM_MIN
    while size < len(vrom):
        size *= 2
    vrom += bytes(size - len(vrom))
    open(os.path.join(build, "lotusneo-v1.v1"), "wb").write(vrom)
    delta = RATE * 65536 // YM2610_CLOCK_RATE
    inc = ["; Genere par tools/build_music.py - ne pas modifier",
           "; Musiques ADPCM-B : debut, fin (/256), Delta-N, panoramique, volume"]
    jmp = ["; Genere par tools/build_music.py - commandes a partir de 05"]
    h = ["/* Genere par tools/build_music.py - ne pas modifier */", "#pragma once",
         "#define SND_STOP_MUSIC 4"]
    decor_cmd = [0] * 13
    est = engine_steps()
    NSTEP = len(est)
    for k, (sg, st, en) in enumerate(music):
        nm = song_name(sg).replace("-", "_")
        s_, e_ = st >> 8, en >> 8
        inc += [f"music_{k}::",
                f"        .db     0x{s_ & 0xFF:02x}, 0x{s_ >> 8:02x}, 0x{e_ & 0xFF:02x}, 0x{e_ >> 8:02x}, "
                f"0x{delta & 0xFF:02x}, 0x{delta >> 8:02x}, 0xc0, 0xff",
                f"snd_command_music_{k}::                  ; {nm}",
                "        push    ix",
                f"        ld      ix, #music_{k}",
                "        call    snd_adpcm_b_play_loop_exclusive",
                "        pop     ix",
                "        ret"]
        jmp.append(f"        jp      snd_command_music_{k}")
        if sg == SONG_INTRO:
            h.append(f"#define SND_MUSIC_INTRO {MUSIC_CMD_BASE + k}")
        elif sg == SONG_RESULTS:
            h.append(f"#define SND_MUSIC_RESULTS {MUSIC_CMD_BASE + k}")
        elif sg == SONG_GAMEOVER:
            h.append(f"#define SND_MUSIC_GAMEOVER {MUSIC_CMD_BASE + k}")
        elif sg == SONG_COMPLETE:
            h.append(f"#define SND_MUSIC_COMPLETE {MUSIC_CMD_BASE + k}")
        elif sg in SONG_CDS:
            h.append(f"#define SND_MUSIC_CD{sg - SONG_CDS[0]} {MUSIC_CMD_BASE + k}")
        else:
            decor_cmd[sg] = MUSIC_CMD_BASE + k
    h += ["/* musique de chaque decor Lotus III (0 = absente de la ROM) */",
          "static const u8 snd_decor_music[13] = {" + ", ".join(str(v) for v in decor_cmd) + "};",
          f"#define SND_ENGINE {sfx_base}       /* + hauteur 0..SND_ENGINE_STEPS-1 */",
          f"#define SND_ENGINE_ECHO {sfx_base + NSTEP}   /* dans un tunnel (d1_097) */",
          f"#define SND_ENGINE2 {sfx_base + 2 * NSTEP}   /* joueur 2 (canal 5) */",
          f"#define SND_ENGINE2_ECHO {sfx_base + 3 * NSTEP}",
          f"#define SND_ENGINE_STEPS {NSTEP}",
          "/* par hauteur : regime de bascule vers la suivante (milieu geometrique),",
          " * pulsations par segment, trames du segment (18 ou 36, exactes) */",
          "static const u16 snd_eng_rpm_hi[SND_ENGINE_STEPS] = {"
          + ", ".join(str(round((est[k][0] * est[k + 1][0]) ** 0.5)) if k + 1 < NSTEP else "65535"
                      for k in range(NSTEP)) + "};",
          "static const u8 snd_eng_nc[SND_ENGINE_STEPS] = {" + ", ".join(str(x[1]) for x in est) + "};",
          "static const u8 snd_eng_fr[SND_ENGINE_STEPS] = {" + ", ".join(str(x[2]) for x in est) + "};"]
    inc.append("; Bruitages ADPCM-A : debut, fin (/256), canal, pan/volume, bit du canal")
    for n, (fname, st, en, ch, vol) in enumerate(fx):
        a, b = st >> 8, en >> 8
        inc += [f"fx_{fname}::",
                f"        .db     0x{a & 0xFF:02x}, 0x{a >> 8:02x}, 0x{b & 0xFF:02x}, 0x{b >> 8:02x}, "
                f"{ch}, 0x{0xC0 | vol:02x}, 0x{1 << ch:02x}",
                f"snd_command_fx_{fname}::",
                "        push    ix",
                f"        ld      ix, #fx_{fname}",
                "        call    snd_adpcm_a_play",
                "        pop     ix",
                "        ret"]
        jmp.append(f"        jp      snd_command_fx_{fname}")
        if not fname.startswith("engine"):
            h.append(f"#define SND_FX_{fname.upper()} {sfx_base + n}")
            if fname in SFX_SEG_FRAMES:
                h.append(f"#define SND_FX_{fname.upper()}_FRAMES {SFX_SEG_FRAMES[fname]}")
    # derniere commande : tout couper (pause ; routine dans src/z80/m1.s)
    jmp.append("        jp      snd_command_stop_all")
    h.append(f"#define SND_STOP_ALL {sfx_base + len(fx)}")
    if sfx_base + len(fx) + 1 > 256:
        raise SystemExit("trop de commandes son")
    open(os.path.join(build, "sound.inc"), "w", encoding="ascii").write(chr(10).join(inc) + chr(10))
    open(os.path.join(build, "sound_jmptable.inc"), "w", encoding="ascii").write(chr(10).join(jmp) + chr(10))
    open(os.path.join(build, "sound_ids.h"), "w", encoding="ascii").write(chr(10).join(h) + chr(10))
    print(f"  V1 : {size // 1024} Ko, {len(music)} musiques, {len(fx)} bruitages")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
