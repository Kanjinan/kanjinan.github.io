"""Planche PNG d'une banque de sprites de Lotus III (fichier SF decompresse).

Format (= SA Lotus III une fois decode en memoire, cf. lotus_pack.unpack_sa_l3) :
  word n ; long offset de chaque image (nb = (offset[0]-2)/4) ;
  image : word largeur, word hauteur, word octets_par_plan, long nibbles,
          puis p plans contigus (p = taille / octets_par_plan) : masque, puis
          plans de couleur ; nibble i du plan affiche i : 0-6 = plan stocke v+1,
          7 = vide, >= 8 = masque (plein sur la zone opaque).

Usage : python tools/amiga/render_bank.py <nom> [nom_palette]   (ex. d2_128)
        python tools/amiga/render_bank.py --all
Sortie : extract/l3/png/<nom>_bank.png
"""

from __future__ import annotations

import os
import sys

from PIL import Image

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
L3 = os.path.join(ROOT, "extract", "l3")


def be(b: bytes, i: int, n: int) -> int:
    return int.from_bytes(b[i:i + n], "big")


def parse(data: bytes) -> list[dict] | None:
    """Liste des images, ou None si ce n'est pas une banque."""
    if len(data) < 16:
        return None
    first = be(data, 2, 4)
    if first < 6 or (first - 2) % 4 or first > len(data):
        return None
    nfr = (first - 2) // 4
    offs = [be(data, 2 + 4 * i, 4) for i in range(nfr)] + [len(data)]
    frames = []
    for i in range(nfr):
        o = offs[i]
        if not (o <= offs[i + 1] <= len(data)):
            return None
        w, h, bpp, nib = be(data, o, 2), be(data, o + 2, 2), be(data, o + 4, 2), be(data, o + 6, 4)
        if not w or not h or bpp != ((w + 15) // 16) * 2 * h:
            return None
        p = (offs[i + 1] - o - 10) // bpp
        frames.append({"w": w, "h": h, "bpp": bpp, "nib": nib, "p": min(p, 6), "data": o + 10})
    return frames


def palette(pal_name: str | None) -> list[tuple[int, int, int]]:
    if pal_name:
        p = open(os.path.join(L3, f"{pal_name}.pal"), "rb").read()
        pal = [be(p, i, 2) for i in range(0, len(p), 2)]
        return [(((c >> 8) & 15) * 17, ((c >> 4) & 15) * 17, (c & 15) * 17) for c in pal]
    # palette provisoire 16 couleurs bien distinctes
    return [(0, 0, 0), (255, 255, 255), (200, 0, 0), (0, 160, 0), (0, 0, 200), (230, 200, 0),
            (0, 200, 200), (200, 0, 200), (120, 120, 120), (255, 140, 0), (120, 60, 0),
            (140, 200, 255), (255, 160, 160), (60, 100, 60), (190, 190, 190), (80, 80, 160)]


def frame_pixels(data: bytes, f: dict, n: int) -> list[list[int]]:
    """Indices de couleur (n-1 plans affiches), -1 = transparent.

    Plans stockes : le masque (plan 0) puis p-1 plans de couleur.
    Nibble i (plan affiche i) : v = 0-6 -> plan stocke v+1, 7 = vide, >= 8 = masque.
    """
    w, h, bpp, p = f["w"], f["h"], f["bpp"], f["p"]
    wb = bpp // h

    def bit(k: int, x: int, y: int) -> int:
        return (data[f["data"] + k * bpp + y * wb + x // 8] >> (7 - (x & 7))) & 1

    sel = [(f["nib"] >> (4 * i)) & 15 for i in range(n - 1)]
    rows = []
    for y in range(h):
        row = []
        for x in range(w):
            if not bit(0, x, y):
                row.append(-1)
                continue
            v = 0
            for i, s in enumerate(sel):
                if s >= 8 or (s < 7 and bit(s + 1, x, y)):
                    v |= 1 << i
            row.append(v)
        rows.append(row)
    return rows


def frame_image(data: bytes, f: dict, rgb, n: int) -> Image.Image:
    img = Image.new("RGB", (f["w"], f["h"]))
    px = img.load()
    for y, row in enumerate(frame_pixels(data, f, n)):
        for x, v in enumerate(row):
            px[x, y] = (40, 0, 40) if v < 0 else rgb[v % len(rgb)]
    return img


def bank(name: str, pal_name: str | None = None) -> str | None:
    data = open(os.path.join(L3, f"{name}.bin"), "rb").read()
    frames = parse(data)
    if not frames:
        return None
    rgb = palette(pal_name)
    n = be(data, 0, 2)
    ims = [frame_image(data, f, rgb, n) for f in frames]
    W = max(640, max(i.width for i in ims))
    x = y = rowh = 0
    pos = []
    for im in ims:
        if x + im.width > W:
            x, y, rowh = 0, y + rowh + 4, 0
        pos.append((x, y))
        x += im.width + 4
        rowh = max(rowh, im.height)
    out = Image.new("RGB", (W, y + rowh + 1), (70, 70, 90))
    for im, p in zip(ims, pos):
        out.paste(im, p)
    os.makedirs(os.path.join(L3, "png"), exist_ok=True)
    path = os.path.join(L3, "png", f"{name}_bank.png")
    out.save(path)
    return path


if __name__ == "__main__":
    if "--all" in sys.argv:
        for f in sorted(os.listdir(L3)):
            if f.endswith(".bin"):
                r = bank(f[:-4])
                if r:
                    fr = parse(open(os.path.join(L3, f), "rb").read())
                    print(f[:-4], len(fr), "images,", "plans", sorted({x["p"] for x in fr}),
                          "max", max(x["w"] for x in fr), "x", max(x["h"] for x in fr))
    else:
        print(bank(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None))
