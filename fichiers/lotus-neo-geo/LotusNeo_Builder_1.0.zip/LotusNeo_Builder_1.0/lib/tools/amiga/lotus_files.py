"""Extraction des fichiers de Lotus Turbo Challenge 2 et Lotus III (ADF crackes).

Lotus 2 (crack CPY, 1 disque) : repertoire dans le programme principal
  (extract/l2_main_50000.bin, cf. gremlin_pack.py) : $2C4 = 257 offsets
  virtuels, $6C8 = index du fichier suivant ; position ADF = offset - $10964.
Lotus III (crack FLT, 2 disques) : repertoire sur chaque disque en $400 :
  'LFC1'/'LFC2', 257 offsets, 256 index suivants ; position = offset - $2C00,
  et au-dela de $DC000 : - $48000 (loader $488).

Usage : python tools/amiga/lotus_files.py l2|l3   (depuis n'importe ou)
Sortie : extract/l2/NNN.* ou extract/l3/dD_NNN.* + index.txt
  .bin decompresse, .raw tel que sur disque, .pal palette SC, .extra annexe SA (L2),
  .frames table JSON des images SA (L3) : [offset, largeur, hauteur, plans, nibbles]
"""

from __future__ import annotations

import json
import os
import sys

sys.path.insert(0, os.path.dirname(__file__))
from lotus_pack import be32, unpack  # noqa: E402

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
EXTRACT = os.path.join(ROOT, "extract")


def _entries(offs: list[int], nxt: bytes):
    for i in range(256):
        if not offs[i]:
            continue
        j = 256 if nxt[i] == 255 else nxt[i]
        size = offs[j] - offs[i]
        if size <= 0:
            size = offs[256] - offs[i]
        yield i, offs[i], size


def files_l2():
    adf = open(os.path.join(ROOT, "adf", "lotus2.adf"), "rb").read()
    low = open(os.path.join(EXTRACT, "l2_main_50000.bin"), "rb").read()[:0x1800]
    offs = [be32(low, 0x2C4 - 0x200 + 4 * i) for i in range(257)]
    nxt = low[0x6C8 - 0x200:0x6C8 - 0x200 + 256]
    for i, off, size in _entries(offs, nxt):
        if off < 0x10964:
            continue  # 255 : programme principal (deja en memoire)
        pos = off - 0x10964
        yield f"{i:03d}", pos, adf[pos:pos + size]


def files_l3():
    disks = {d: open(os.path.join(ROOT, "adf", f"lotus3_d{d}.adf"), "rb").read() for d in (1, 2)}
    end = 0xDC000
    for d in (1, 2):
        adf = disks[d]
        dr = adf[0x400:0x400 + 0x508]
        offs = [be32(dr, 4 + 4 * i) for i in range(257)]
        nxt = dr[4 + 1028:4 + 1028 + 256]
        for i, off, size in _entries(offs, nxt):
            pos = off - 0x2C00
            if d == 1:
                raw = adf[pos:pos + size]
            elif pos >= end:
                # au-dela de la fin du disque 2 : suite rangee sur le disque 1
                raw = disks[1][pos - 0x48000:pos - 0x48000 + size]
            else:
                first = min(size, end - pos)
                raw = adf[pos:pos + first] + disks[1][end - 0x48000:end - 0x48000 + size - first]
            yield f"d{d}_{i:03d}", pos, raw


def main() -> int:
    game = sys.argv[1] if len(sys.argv) > 1 else "l2"
    out = os.path.join(EXTRACT, game)
    os.makedirs(out, exist_ok=True)
    index = []
    for name, pos, raw in (files_l2() if game == "l2" else files_l3()):
        open(os.path.join(out, f"{name}.raw"), "wb").write(raw)
        try:
            fmt, data, info = unpack(raw, game == "l3")
            desc = f"{fmt:4s} {len(data):#07x}"
            if info.get("frames"):
                json.dump(info["frames"], open(os.path.join(out, f"{name}.frames"), "w"))
                desc = f"{fmt:4s} {info['n']} plans, {len(info['frames'])} images"
            elif info:
                desc = f"{fmt:4s} {info['n']} plans x {info['psize']:#06x}"
                if info["palette"]:
                    open(os.path.join(out, f"{name}.pal"), "wb").write(
                        b"".join(c.to_bytes(2, "big") for c in info["palette"]))
                if info["extra"]:
                    open(os.path.join(out, f"{name}.extra"), "wb").write(info["extra"])
                    desc += f" + annexe {len(info['extra']):#x}"
        except Exception as e:  # noqa: BLE001
            data, desc = raw, f"ERREUR {raw[:2]!r} {e}"
        open(os.path.join(out, f"{name}.bin"), "wb").write(data)
        index.append(f"{name}  adf ${pos:06X}  {len(raw):#07x}  {desc}")
        print(index[-1])
    open(os.path.join(out, "index.txt"), "w", encoding="utf-8").write("\n".join(index) + "\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
