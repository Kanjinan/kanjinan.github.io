"""Generateur de circuits RECS de Lotus III, execute sur le vrai code 68000 (Unicorn).

Le programme principal (extract/l3_d1_255.bin) est charge en $682A0, avec
a3 = $88000 (base des variables, $690EA). Sequence du jeu ($6EEC0, $6FB70) :
  $715F6  code texte (9 lettres + '-NN') -> 10 parametres en a3+616
  $7214C  parametres -> reglages + graine du generateur aleatoire ($72100)
  $6F7C2  drapeaux et tables du decor (jusqu'a $6F92A, dont a3+866 ; la suite charge le decor)
Contexte : a3+1984 = mode 0-2 (menu, 2 au demarrage $69172), choisit la table d'objets $7327E.
  $71FA8  generation : vide le circuit puis pipeline $72090 (11 routines)
Resultat : a3+19546 ($8CC5A), 1024 segments de 16 octets.

Usage : python tools/amiga/recs.py <code> [...]     ex. pwrwvwhnm-30
        python tools/amiga/recs.py --championship     (codes du jeu, $6AAE0)
Sortie : extract/l3/recs/<code>.bin (16 Ko) + resume ; --png pour un trace
"""

from __future__ import annotations

import os
import sys

from unicorn import UC_ARCH_M68K, UC_HOOK_MEM_READ_UNMAPPED, UC_HOOK_MEM_WRITE_UNMAPPED, \
    UC_MODE_BIG_ENDIAN, Uc, UcError
from unicorn.m68k_const import UC_CPU_M68K_M68000, UC_M68K_REG_A0, UC_M68K_REG_A1, \
    UC_M68K_REG_A3, UC_M68K_REG_A7, UC_M68K_REG_PC, UC_M68K_REG_SR

sys.path.insert(0, os.path.dirname(__file__))
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
MAIN = os.path.join(ROOT, "extract", "l3_d1_255.bin")
OUT = os.path.join(ROOT, "extract", "l3", "recs")

BASE, A3 = 0x682A0, 0x88000
TRACK = A3 + 19546
PARAMS = A3 + 616
RET = 0xFFF00          # adresse de retour sentinelle
STACK = 0xFF000
STR = 0xFE000
CODES_TABLE, CODES_N = 0x6AAE0, 64


class Recs:
    def __init__(self) -> None:
        self.main = open(MAIN, "rb").read()
        self.uc = None

    def _reset(self) -> None:
        uc = Uc(UC_ARCH_M68K, UC_MODE_BIG_ENDIAN)
        uc.ctl_set_cpu_model(UC_CPU_M68K_M68000)
        uc.mem_map(0, 0x100000)
        uc.mem_map(0xBF0000, 0x10000)   # CIA (ecritures ignorees)
        uc.mem_map(0xDF0000, 0x10000)   # registres custom
        uc.mem_write(BASE, self.main)
        uc.mem_write(0x7E39C, A3.to_bytes(4, "big"))
        uc.mem_write(0x7D0D4, (A3 - 0x8000).to_bytes(4, "big"))
        uc.mem_write(RET, b"\x4e\x71" * 8)  # nop
        self.bad: list[str] = []

        def unmapped(uc_, access, addr, size, value, data):
            self.bad.append(f"acces hors memoire ${addr:X} (PC ${uc_.reg_read(UC_M68K_REG_PC):X})")
            return False

        uc.hook_add(UC_HOOK_MEM_READ_UNMAPPED | UC_HOOK_MEM_WRITE_UNMAPPED, unmapped)
        self.uc = uc

    def call(self, addr: int, a0: int = 0, a1: int = 0, until: int = RET) -> None:
        uc = self.uc
        sp = STACK - 4
        uc.mem_write(sp, RET.to_bytes(4, "big"))
        uc.reg_write(UC_M68K_REG_SR, 0x2700)  # avant A7 : le passage superviseur change de pile
        uc.reg_write(UC_M68K_REG_A7, sp)
        uc.reg_write(UC_M68K_REG_A3, A3)
        uc.reg_write(UC_M68K_REG_A0, a0)
        uc.reg_write(UC_M68K_REG_A1, a1)
        try:
            uc.emu_start(addr, until, count=200_000_000)
        except UcError as e:
            pc = uc.reg_read(UC_M68K_REG_PC)
            raise RuntimeError(f"${addr:X} : {e} a PC ${pc:X} ; {self.bad[:3]}") from e
        pc = uc.reg_read(UC_M68K_REG_PC)
        if pc != until:
            raise RuntimeError(f"${addr:X} : arret a PC ${pc:X} (boucle infinie ?)")

    def word(self, addr: int) -> int:
        return int.from_bytes(self.uc.mem_read(addr, 2), "big")

    def length(self) -> int:
        """Nombre de segments ($720DA) : fin + 8, + 8 de plus pour un circuit sans boucle."""
        n = self.word(A3 + 1054) + 8
        if not self.word(A3 + 1064):
            n += 8
        return n

    def checkpoints(self) -> int:
        return self.word(A3 + 1052)

    def params(self) -> list[int]:
        b = self.uc.mem_read(PARAMS, 20)
        return [int.from_bytes(b[2 * i:2 * i + 2], "big") for i in range(10)]

    def generate(self, code: str, mode: int = 2) -> bytes:
        self._reset()
        self.uc.mem_write(A3 + 1984, mode.to_bytes(2, "big"))
        s = code.lower().encode("latin-1").ljust(12, b"0") + b"\0" * 4
        self.uc.mem_write(STR, s)
        self.call(0x715F6, a0=STR, a1=PARAMS)
        self.call(0x7214C)
        self.call(0x6F7C2, until=0x6F92A)  # drapeaux et tables du decor (la suite charge des fichiers)
        self.call(0x71FA8)
        return bytes(self.uc.mem_read(TRACK, 0x4000))

    def championship_codes(self) -> list[str]:
        codes = []
        for i in range(CODES_N):
            raw = self.main[CODES_TABLE - BASE + 12 * i:CODES_TABLE - BASE + 12 * i + 12]
            codes.append(raw.decode("latin-1"))
        return codes


def summary(trk: bytes, n: int) -> str:
    curves = hills = 0
    for i in range(n):
        r = trk[16 * i:16 * i + 16]
        curves += r[0] != 0
        hills += r[1] != 0
    return f"{n} segments, {curves} en virage, {hills} en relief"


def main() -> int:
    os.makedirs(OUT, exist_ok=True)
    rc = Recs()
    codes = [a for a in sys.argv[1:] if not a.startswith("--")]
    if "--championship" in sys.argv:
        codes = [c for c in rc.championship_codes() if c[0].isalpha()]
    for code in codes:
        trk = rc.generate(code)
        n = rc.length()
        trk = trk[:16 * n]
        name = code.replace(" ", "_")
        open(os.path.join(OUT, f"{name}.bin"), "wb").write(trk)
        print(f"{code:12s} params {rc.params()}  {summary(trk, n)}, {rc.checkpoints()} checkpoints")
        for b in rc.bad[:3]:
            print("   ", b)
        if "--png" in sys.argv:
            import lotus2_track as lt
            lt.render(0, lt.load16(os.path.join(OUT, f"{name}.bin")),
                      os.path.join(OUT, f"{name}.png"), title=code)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
