"""Parcours de Lotus Turbo Challenge 2 (fichiers 024-031, SF de $3000 octets).

Format sur disque : jusqu'a 1024 segments de 12 octets (charges en a3-7800,
fichier = 24 + numero de parcours, $76E86) :
  +0  byte  virage (signe)          +1  byte  relief (signe)
  +2  word  objet 1 : octet haut = type, octet bas = position laterale signee
  +4  word  objet 2   +6 word objet 3   +8 word objet 4
  +10 word  attributs (quartets, masque $7777 ; bit 15 pose si objet1 = $FC..)
Fin du parcours : objet 1 de type $79 ($76EAC, longueur = index + 8).
En memoire ($77116) : 16 octets/segment, +12/+13 = cumuls virage/relief ($771F8).

Usage : python tools/amiga/lotus2_track.py [num]   (defaut : les 8)
Sortie : extract/l2/track/NNN.txt (segments) + NNN.png (vue de dessus + profil)
"""

from __future__ import annotations

import collections
import math
import os
import sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
L2 = os.path.join(ROOT, "extract", "l2")
OUT = os.path.join(L2, "track")
NAMES = ["forest", "night", "fog", "snow", "desert", "motorway", "marsh", "storm"]


def s8(v: int) -> int:
    return v - 256 if v & 0x80 else v


def load(num: int) -> list[dict]:
    d = open(os.path.join(L2, f"{num:03d}.bin"), "rb").read()
    segs = []
    for i in range(len(d) // 12):
        r = d[12 * i:12 * i + 12]
        objs = [int.from_bytes(r[2 + 2 * k:4 + 2 * k], "big") for k in range(4)]
        segs.append({"curve": s8(r[0]), "hill": s8(r[1]), "objs": objs,
                     "attr": int.from_bytes(r[10:12], "big")})
        if objs[0] >> 8 == 0x79:
            break
    return segs


def geometry(segs: list[dict]) -> tuple[list[tuple[float, float]], list[int]]:
    """Trace vu de dessus (direction = cumul des virages, 256 = un tour) et altitude
    (pente = cumul du relief, altitude = cumul de la pente)."""
    x = y = 0.0
    ang = alt = slope = 0
    pts, alts = [(x, y)], [0]
    for s in segs:
        ang = (ang + s["curve"]) & 0xFF
        slope += s["hill"]
        alt += slope
        a = ang * 2 * math.pi / 256
        x += math.sin(a)
        y -= math.cos(a)
        pts.append((x, y))
        alts.append(alt)
    return pts, alts


def load16(path: str) -> list[dict]:
    """Circuit au format memoire (16 octets/segment : Lotus 2 en jeu, Lotus III RECS)."""
    d = open(path, "rb").read()
    segs = []
    for i in range(len(d) // 16):
        r = d[16 * i:16 * i + 16]
        objs = [int.from_bytes(r[2 + 2 * k:4 + 2 * k], "big") for k in range(4)]
        segs.append({"curve": s8(r[0]), "hill": s8(r[1]), "objs": objs,
                     "attr": int.from_bytes(r[10:12], "big")})
    return segs


def render(num, segs: list[dict], path: str, title: str | None = None) -> None:
    from PIL import Image, ImageDraw
    pts, alts = geometry(segs)
    W, H, PH = 600, 600, 140
    img = Image.new("RGB", (W, H + PH), (20, 24, 32))
    dr = ImageDraw.Draw(img)
    xs, ys = [p[0] for p in pts], [p[1] for p in pts]
    sc = min((W - 40) / max(1, max(xs) - min(xs)), (H - 40) / max(1, max(ys) - min(ys)))
    tr = [(20 + (px - min(xs)) * sc, 20 + (py - min(ys)) * sc) for px, py in pts]
    for i in range(len(tr) - 1):
        c = (255, 80, 80) if segs[i]["curve"] else (220, 220, 220)
        dr.line([tr[i], tr[i + 1]], fill=c, width=3)
    dr.ellipse([tr[0][0] - 5, tr[0][1] - 5, tr[0][0] + 5, tr[0][1] + 5], fill=(0, 255, 0))
    dr.ellipse([tr[-1][0] - 5, tr[-1][1] - 5, tr[-1][0] + 5, tr[-1][1] + 5], fill=(255, 255, 0))
    lo, hi = min(alts), max(alts)
    prof = [(i * W / len(alts), H + PH - 10 - (a - lo) * (PH - 20) / max(1, hi - lo))
            for i, a in enumerate(alts)]
    dr.line(prof, fill=(120, 200, 255), width=2)
    title = title or f"{num:03d} {NAMES[num - 24]}"
    dr.text((8, H + 4), f"{title} : {len(segs)} segments, relief {lo}..{hi}", fill=(255, 255, 0))
    img.save(path)


def main() -> int:
    os.makedirs(OUT, exist_ok=True)
    nums = [int(a) for a in sys.argv[1:]] or list(range(24, 32))
    types = collections.Counter()
    for num in nums:
        segs = load(num)
        with open(os.path.join(OUT, f"{num:03d}.txt"), "w", encoding="utf-8") as f:
            for i, s in enumerate(segs):
                ob = " ".join(f"{o >> 8:02X}:{s8(o & 255):+4d}" if o else "  ----  " for o in s["objs"])
                f.write(f"{i:4d}  c{s['curve']:+3d} h{s['hill']:+3d}  {ob}  attr {s['attr']:04X}\n")
                for o in s["objs"]:
                    if o:
                        types[o >> 8] += 1
        render(num, segs, os.path.join(OUT, f"{num:03d}.png"))
        print(f"{num:03d} {NAMES[num - 24]:9s} {len(segs)} segments")
    print("types d'objets :", " ".join(f"{t:02X}x{n}" for t, n in sorted(types.items())))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
