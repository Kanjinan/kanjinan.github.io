"""Decompresseurs des fichiers Gremlin (Lotus Turbo Challenge 2 et Lotus III).

Formats (loader L2 $11BC, L3 $7D5C6) :
  'SF' : LZ octet par octet lu a l'envers
  'SA' / 'SP' / 'SC' : image n plans (RLE + LZ fenetre 16 Ko, flux de bits
        a l'envers) puis chunky -> planar ; 'SC' : palette, 'SA' : annexe
        (table des images : offset, largeur, hauteur)
  'SQ' : echantillons audio (Lotus III, $7DC8C) : largeur de bits adaptative,
        zigzag, puis delta selon le mode
"""

from __future__ import annotations

M32 = 0xFFFFFFFF


def be16(b: bytes, i: int) -> int:
    return (b[i] << 8) | b[i + 1]


def be32(b: bytes, i: int) -> int:
    return int.from_bytes(b[i:i + 4], "big")


# table $120E du loader : longueurs de base (copie, repetition) selon le nombre de plans
_LEN_TABLE = {0x120C: 0x4E, 0x120D: 0x75, 0x120E: 7, 0x120F: 5, 0x1210: 4, 0x1211: 4,
              0x1212: 4, 0x1213: 4, 0x1214: 3, 0x1215: 3}


def be16(b: bytes, i: int) -> int:
    return (b[i] << 8) | b[i + 1]


def be32(b: bytes, i: int) -> int:
    return int.from_bytes(b[i:i + 4], "big")


class BitsL:
    """Flux de bits lu a l'envers par longs, bit de poids fort d'abord, sentinelle."""

    def __init__(self, data: bytes, end: int):
        self.d = data
        self.p = end - 4
        self.v = be32(data, self.p)

    def bit(self) -> int:
        c = self.v >> 31
        self.v = (self.v << 1) & M32
        if self.v == 0:
            self.p -= 4
            w = be32(self.d, self.p)
            c = w >> 31
            self.v = ((w << 1) & M32) | 1
        return c

    def bits(self, n: int) -> int:
        v = 0
        for _ in range(n):
            v = (v << 1) | self.bit()
        return v


class BitsB:
    """Idem par octets (format SF)."""

    def __init__(self, data: bytes, end: int):
        self.d = data
        self.p = end - 1
        self.v = data[self.p]

    def bit(self) -> int:
        c = self.v >> 7
        self.v = (self.v << 1) & 0xFF
        if self.v == 0:
            self.p -= 1
            w = self.d[self.p]
            c = w >> 7
            self.v = ((w << 1) & 0xFF) | 1
        return c

    def bits(self, n: int) -> int:
        v = 0
        for _ in range(n):
            v = (v << 1) | self.bit()
        return v


def unpack_sf(src: bytes) -> bytes:
    size = be32(src, 2)
    plen = be32(src, 6)
    data = src[10:10 + plen]
    out = bytearray(size)
    w = size
    bs = BitsB(data, plen)

    def varlen(start: int) -> int:
        d2, d3, acc = 1, 1, start
        while True:
            v = bs.bits(d2)
            acc += v
            if v != d3:
                return acc
            d2 += 1
            d3 = d3 * 2 + 1

    while w > 0:
        if not bs.bit():
            n = varlen(1)
            for _ in range(n):
                bs.p -= 1
                w -= 1
                out[w] = data[bs.p]
            continue
        if not bs.bit():
            obits, n = 9, 2
        elif not bs.bit():
            obits, n = 10, 3
        elif not bs.bit():
            obits, n = 12, 4
        else:
            obits = 9 if bs.bit() else 14
            n = varlen(5)
        off = bs.bits(obits)
        src_i = w + off
        for _ in range(n):
            src_i -= 1
            w -= 1
            out[w] = out[src_i]
    return bytes(out)


class PixelStream:
    """Flux de pixels des formats image (L2 $1222, L3 $7D63E/$7D7CE).

    Les pixels sortent dans l'ordre de decodage (de la fin de l'image vers le
    debut). Valeur = n bits dans les bits de poids fort de l'octet.
    l3 : les copies lisent 1 bit de plus (0 : distance 9 bits, 1 : 14 bits).
    """

    COPY_EXTRA = {6: (1, 6), 7: (1, 8), 8: (2, 10), 9: (3, 14), 10: (5, 22), 11: (8, 54)}

    def __init__(self, src: bytes, end: int, n: int, l3: bool):
        self.bs = BitsL(src, end)
        self.n = n
        self.l3 = l3
        self.base_copy = _LEN_TABLE[0x120E + n - 3]
        self.base_run = _LEN_TABLE[0x120F + n]
        self.ring = bytearray(0x4000)
        self.d4 = 0x4000
        self.pending: list[int] = []

    def _pixel(self) -> int:
        # roxr.b : n bits entres dans le bit 7
        v = 0
        for _ in range(self.n):
            v = (v >> 1) | (self.bs.bit() << 7)
        return v

    def _put(self, v: int) -> None:
        self.d4 = (self.d4 - 1) & 0x3FFF
        self.ring[self.d4] = v
        self.pending.append(v)

    def _command(self) -> None:
        bs = self.bs
        cmd = bs.bits(4)
        if cmd <= 11:
            if cmd <= 5:
                cnt = cmd
            else:
                nb, add = self.COPY_EXTRA[cmd]
                cnt = bs.bits(nb) + add
            cnt += self.base_copy
            obits = (14 if bs.bit() else 9) if self.l3 else 14
            d3 = (bs.bits(obits) + self.d4) & 0x3FFF
            for _ in range(cnt):
                d3 = (d3 - 1) & 0x3FFF
                self._put(self.ring[d3])
        elif cmd in (12, 13):
            cnt = (bs.bits(4) if cmd == 12 else bs.bits(8) + 16) + self.base_run
            v = self._pixel()
            for _ in range(cnt):
                self._put(v)
        else:
            cnt = 1 if cmd == 14 else bs.bits(3) + 2
            for _ in range(cnt):
                self._put(self._pixel())

    def take(self, count: int) -> list[int]:
        """count pixels dans l'ordre de decodage ; l'excedent sert a l'image suivante."""
        while len(self.pending) < count:
            self._command()
        out, self.pending = self.pending[:count], self.pending[count:]
        return out


def planarize(decoded: list[int], nplanes: int, psize: int) -> bytes:
    """Pixels dans l'ordre de decodage -> plans contigus ; plan k = bit (7-k)."""
    planes = bytearray(psize * nplanes)
    total = psize * 8
    for j, v in enumerate(decoded):
        if not v:
            continue
        byte, bit = divmod(total - 1 - j, 8)
        for k in range(nplanes):
            if v & (0x80 >> k):
                planes[k * psize + byte] |= 0x80 >> bit
    return bytes(planes)


def unpack_pic(src: bytes, l3: bool = False) -> dict:
    """SA/SP/SC (Lotus 2) et SP/SC (Lotus III).
    Retourne planes (plans contigus), n, psize, palette, extra (annexe SA L2)."""
    magic = src[:2]
    if l3 and magic == b"SA":
        return unpack_sa_l3(src)
    n = be16(src, 2)
    psize = be32(src, 4)
    plen = be32(src, 8)
    p = 12
    pal = None
    if magic == b"SC":
        pal = [be16(src, p + 2 * i) for i in range(1 << n)]
        p += 2 << n
    end = p + plen
    extra = b""
    if magic == b"SA":
        el = be32(src, end + 8) + 8
        extra = src[end:end + el]
    ps = PixelStream(src, end, n, l3)
    planes = planarize(ps.take(psize * 8), n, psize)
    return {"magic": magic.decode(), "n": n, "psize": psize, "planes": planes,
            "palette": pal, "extra": extra}


def unpack_sa_l3(src: bytes) -> dict:
    """SA de Lotus III ($7D63E) : planche d'images, chacune avec ses propres plans.

    En-tete : 'SA', word n, word nb_images, long taille_sortie, long taille_flux,
    puis nb_images x (word largeur, word hauteur, long nibbles), puis le flux.
    Images decodees de la derniere a la premiere, flux continu. Nombre de plans
    d'une image = max(nibbles < 7 parmi les n-1 premiers) + 2 ($7D794).
    Sortie : planes = images concatenees (plans contigus par image),
    frames = [(offset, largeur, hauteur, plans, nibbles)].
    """
    n = be16(src, 2)
    nfr = be16(src, 4)
    plen = be32(src, 10)
    tab = 14
    end = tab + nfr * 8 + plen
    ps = PixelStream(src, end, n, True)
    decoded = {}
    for k in reversed(range(nfr)):
        w, h, nib = be16(src, tab + 8 * k), be16(src, tab + 8 * k + 2), be32(src, tab + 8 * k + 4)
        bpp = ((w + 15) >> 4) * h * 2
        m, v = -1, nib
        for _ in range(n - 1):
            x = v & 15
            if x < 7 and x > m:
                m = x
            v >>= 4
        np_ = m + 2
        decoded[k] = (w, h, nib, np_, planarize(ps.take(bpp * 8), np_, bpp))
    out = bytearray()
    frames = []
    for k in range(nfr):
        w, h, nib, np_, pl = decoded[k]
        frames.append((len(out), w, h, np_, nib))
        out += pl
    return {"magic": "SA", "n": n, "psize": 0, "planes": bytes(out),
            "palette": None, "extra": b"", "frames": frames}


def unpack_sq(src: bytes) -> bytes:
    """Echantillons 8 bits signes (Lotus III $7DC8C)."""
    size = be32(src, 2)
    w = be32(src, 6)
    nlongs, mode = w & 0xFFFFFF, w >> 24
    end = 10 + nlongs * 4
    bs = BitsL(src, end)
    total = (size + 7) & ~7
    out = bytearray(total)
    p = total
    width = bs.bits(3) + 1
    while p > 0:
        for _ in range(8):
            p -= 1
            out[p] = bs.bits(width) & 0xFF
        ones = 0
        while bs.bit():
            ones += 1
        d4 = ones + 1
        d4 = (d4 >> 1) if d4 & 1 else -(d4 >> 1)
        width -= d4
    out = out[:size]

    def zz(b: int) -> int:
        return (-(b >> 1) - 1) & 0xFF if b & 1 else b >> 1

    if mode == 1:
        return bytes(zz(b) for b in out)
    res = bytearray(size)
    d4 = d5 = 0
    for i, b in enumerate(out):
        d4 = (d4 + zz(b)) & 0xFF
        if mode == 3:
            d5 = (d5 + d4) & 0xFF
            res[i] = d5
        else:
            res[i] = d4
    return bytes(res)


def unpack(raw: bytes, l3: bool = False) -> tuple[str, bytes, dict]:
    """Decompresse selon la signature : (format, donnees, infos)."""
    m = raw[:2]
    if m == b"SF":
        return "SF", unpack_sf(raw), {}
    if m == b"SQ":
        return "SQ", unpack_sq(raw), {}
    if m in (b"SA", b"SP", b"SC"):
        pic = unpack_pic(raw, l3)
        return pic["magic"], pic["planes"], pic
    return "brut", raw, {}
